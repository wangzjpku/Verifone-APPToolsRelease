#ifndef __USER_TYPE__
#define __USER_TYPE__
typedef unsigned long  ulint;
typedef long           lint;
typedef unsigned short usint;
typedef short          sint;
typedef short		       boolean;	
typedef unsigned char  byte;
typedef unsigned short Ushort;
#endif
