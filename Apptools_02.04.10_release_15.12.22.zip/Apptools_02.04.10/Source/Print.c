/****************************************************************************
* FILE NAME:   Print.c                            *
* MODULE NAME: Print                            *
* PROGRAMMER:  luqr                             *
* DESCRIPTION: ��ӡģ��                           *
* REVISION:    01.00 08/18/10                       *
****************************************************************************/

/*==========================================*
*         I N T R O D U C T I O N          *
*==========================================*/

/* void */

/*==========================================*
*             I N C L U D E S              *
*==========================================*/

#include "AppTools.h"

/*==========================================*
*        P R I V A T E  DEFINE              *
*===========================================*/
#define PRN_LINE_SIZE  42
#define DNLD_TO		3

#define Print_CheckPrinterStatus( status ) {if( (status == PRINT_NOHANDLE) || (status == PRINT_NOPAPER) ) return status;}

extern int isGbkFont12(void);


/*==========================================*
*        P R I V A T E  D A T A            *
*==========================================*/
static open_block_t stprinter_parm;
static int inPrint_iSprocketDotMode;					// ��ʽ��ӡ����ӡ����ģʽ:360��180
static int inPrint_iPrinterHandle;
static int inPrint_iInitStatus;
static int inPrint_iFontSize;							// ��ӡ����: 24x24, 16x16
static int inPrint_iUIScheme;							// ����ӡ��ȱֽ��ʱ��atools���Ƿ���Ҫ��ʾȱֽ���ȴ�����
// Added by laikey_20151209 -->
static int inPrint_iDownloadEnglishFontFlag;			// Ӣ�ĵ��������Ƿ��Ѿ��������
static unsigned char inPrint_bNewSprocketMode=0;		// =1:����ӡģʽ
static char inPrint_cHZCasheString_16x16[ 2048 ]= {0};	// �Ѿ����صĺ��ֻ���16x16����
static char inPrint_cHZCasheString_24x24[ 2048 ]= {0};	// �Ѿ����صĺ��ֻ���16x16����
static char inPrint_NoTshzString[ 512 ]= {0};			// ����Ҫת��ֱ�����صĺ��ֻ���

/*=====================================================*
*   I N C L U D E  P R I V A T E  F U N C T I O N S   *
*=====================================================*/
static char inPrint_IsChinese(char *s);
static int inPrint_SearchHZ(char *str, int *totalhz);
static int inPrint_DownloadHZ(int printer_h , unsigned char *str, int totalhz);
static int inPrint_GetPrnCacheString( void );
static void inPrint_WriteStr(int hdl, unsigned char *pcString );
static void inPrint_Compress_16x16_h_only( unsigned char* buf_zip, unsigned char* buf_pft);
static void inPrint_Compress_16x16_hv( unsigned char* buf_zip, unsigned char* buf_pft);
static void inPrint_Print_English( unsigned char attrib, unsigned char *txtenglish );
static int inPrint_Download_EnglishFont_8x14(void);
static int inPrint_CheckNotshzCasheString( char *str );
static int inPrint_GetNNotshzCacheString( void );
static int inPrint_Download_Hz_font(char Tab_id, char Ch_id, unsigned char *buf_pft, int buf_length );
static void inPrint_Print_Hz( char *str, unsigned char attrib );
static int inPrint_p3700_print( short h_comm_port, unsigned char *pPrintString );
static short inPrint_p3700_select_font( short h_comm_port, short font_size, short font_table);
static short inPrint_p3700_dnld_graphic_file(short h_comm_port, short h_graphic_file );
static int inPrint_OpenDevice( void );
static int inPrint_CloseDev( void );
static int inPrint_CheckPrintAutoOpenStatus( void );
static int inPrint_CheckReadlyStatus( int iWaitFlag, int *piRetPrinterStatus );
static void inPrint_Feed_Vx805( int flag, int length );
static int inPrint_Print_Str_12_Vx805(char *str, unsigned char attrib);
static int inPrint_GetGB2312Offset(unsigned char h, unsigned char l);
static int inPrint_GetGBKOffset(unsigned char h, unsigned char l);
static char inPrint_IsChinese(char *s);
static int inPrint_SearchHZ(char *str, int *totalhz);
static int inPrint_CheckStatus( int iStatus );
static int inPrint_GetFontSize( void );
static void inPrint_Log( int iLine, char *pString, ... );
static int inPrint_GetUIScheme( void );
static int inPrint_CheckNoPaper( int iPrinterStatus );
static int inPrint_Bitmap(int handle, int offset, char *filename);
static int inPrint_GetStatus( void );  // Added by laikey_20151209 -->

/*=========================================*
*   P U B L I C     F U N C T I O N S     *
*=========================================*/

void Print_InitPrm( void )
{
    inPrint_iPrinterHandle = 0;
    inPrint_iInitStatus = 0;
    inPrint_bNewSprocketMode = 0;
    inPrint_iFontSize = 16;
    inPrint_iSprocketDotMode = MODE_180_DOTS;
    inPrint_iUIScheme = 0;
    inPrint_iDownloadEnglishFontFlag = 0; // Added by laikey_20151209 -->
    memset( inPrint_cHZCasheString_16x16, 0, sizeof( inPrint_cHZCasheString_16x16 ) );
    memset( inPrint_cHZCasheString_24x24, 0, sizeof( inPrint_cHZCasheString_24x24 ) );
    memset( inPrint_NoTshzString, 0, sizeof( inPrint_NoTshzString ) );
    return;
}


/* --------------------------------------------------------------------------
* FUNCTION NAME: Print_Init.
* DESCRIPTION:   ��ʼ����ӡ��
* PARAMETERS:
* RETURN:
*   PRINT_NOHANDLE/PRINT_OK
* NOTES:
* ------------------------------------------------------------------------ */
int Print_Init(void)
{
    inPrint_Log( __LINE__, "Print_Init......" );

    inPrint_iPrinterHandle = Device_GetHandle( DEV_COM4 );
    if ( inPrint_iPrinterHandle < 0 )
    {
        // LOG_PRINTF_LIB( "Print_Init, DEV_COM4 can't be used,handle=[%d]", inPrint_iPrinterHandle );
        return PRINT_NOHANDLE;
    }

    memset(&stprinter_parm, 0, sizeof(stprinter_parm));
    stprinter_parm.rate      = Rt_19200;
    stprinter_parm.format    = Fmt_A8N1 | Fmt_DTR | Fmt_RTS | Fmt_auto;	//Fmt_A8N1 | Fmt_AFC | Fmt_DTR;
    stprinter_parm.protocol  = P_char_mode;
    stprinter_parm.parameter = 0;

    inPrint_bNewSprocketMode = 0;
    inPrint_iUIScheme = 0;

    if ( MmiUtil_GetPrinterType() == SPROCKET_PRINTER)
    {
        if( MmiUtil_GetTerminalType() == _VX520S || MmiUtil_GetTerminalType() == _VX805 )
        {
            inPrint_bNewSprocketMode = 1;

            inPrint_Log( __LINE__, "printer for new fast printing mode!" );
        }

        // cx 141107 start
        if( inPrint_iSprocketDotMode == MODE_360_DOTS)
        {
            //add by 2014.10.10
            // set 360-dot mode
            stprinter_parm.trailer.bytes.b[0] = 1;

            // do home-position-seek after every 10 left+right passes
            stprinter_parm.trailer.bytes.b[1] = 20;//20141205 Set 20 or even more instead of 10.

            // shift printing area on 3 dot to left
            //stprinter_parm.trailer.bytes.b[2] = (signed char)-3;
            //end
        }
        // cx 141107 end
    }

    set_opn_blk( inPrint_iPrinterHandle, &stprinter_parm );
    SVC_WAIT( 200 );

    inPrint_p3700_print( inPrint_iPrinterHandle, (unsigned char *)"\x18");

    p3700_init( inPrint_iPrinterHandle, 6 );
    SVC_WAIT( 100 );

    // Added by laikey_20151209 -->
    switch( inPrint_GetStatus() )
    {
    case PRINT_MERCHFAIL:
        MmiUtil_Warning( "��ӡ������" );
        break;
    case PRINT_WRITEFAIL:
        break;
    case PRINT_READFAIL:
        break;
    case PRINT_NOPAPER:
        MmiUtil_Warning( "��ӡ��ȱֽ" );
        break;
    case PRINT_NOHANDLE:
        MmiUtil_Warning( "��ӡ����ʧ��" );
        break;
    }
    // <--
    //ɾ����ӡ��ʱ�ļ�
//  _remove(PRNCACHE_16X16);

    if( inPrint_iInitStatus < 100 )
    {
        inPrint_iInitStatus = 100;

        if( inPrint_bNewSprocketMode == 1 )
        {
            // ����Ӣ�ĵ����ֿ�(������Ƶ�ѹ���ֿ�)
            inPrint_Download_EnglishFont_8x14();

            //��ȡ����Ҫ��ѹ��������
            inPrint_GetNNotshzCacheString( );
        }
    }

    return PRINT_OK;
}


/* --------------------------------------------------------------------------
* FUNCTION NAME: Print_Open.
* DESCRIPTION:   �򿪴�ӡ��
* PARAMETERS:
* RETURN:
*   PRINT_NOHANDLE/PRINT_OK
* NOTES:
*	Added by @laikey_20130111
* ------------------------------------------------------------------------ */
int Print_Open( void )
{
    open_block_t parm;

    if ( inPrint_CheckPrintAutoOpenStatus( ) == 1 )
        return PRINT_OK;

    if ( inPrint_OpenDevice( ) != TRUE )
        return PRINT_NOHANDLE;

    inPrint_iPrinterHandle = Device_GetHandle( DEV_COM4 );
    if ( inPrint_iPrinterHandle < 0 )
        return PRINT_NOHANDLE;

    memset(&parm, 0, sizeof(parm));
    parm.rate      = Rt_19200;
    parm.format    = Fmt_A8N1 | Fmt_auto | Fmt_RTS;
    parm.protocol  = P_char_mode;
    parm.parameter = 0;

    set_opn_blk( inPrint_iPrinterHandle, &parm );
    SVC_WAIT( 200 );

    inPrint_p3700_print( inPrint_iPrinterHandle, (unsigned char *)"\x18");	// clear print buffer

    p3700_init( inPrint_iPrinterHandle, 6 );
    SVC_WAIT( 100 );

    return PRINT_OK;
}


/* --------------------------------------------------------------------------
* FUNCTION NAME: Print_Close.
* DESCRIPTION:   �رմ�ӡ��
* PARAMETERS:
* RETURN:
*   PRINT_NOHANDLE/PRINT_OK
* NOTES:
*	Added by @laikey_20130111
* ------------------------------------------------------------------------ */
int Print_Close( void )
{
    int iRet;

    if ( inPrint_CheckPrintAutoOpenStatus( ) == 1 )
        return PRINT_OK;

    iRet = p3700_close( inPrint_iPrinterHandle );
    if ( iRet < 0 )
    {
        SVC_WAIT( 50 );

        iRet = p3700_close( inPrint_iPrinterHandle );
    }

    inPrint_iPrinterHandle = 0;
    iRet = inPrint_CloseDev( );

    if ( iRet == TRUE )
        return PRINT_OK;
    else
        return PRINT_FAIL;
}


/* --------------------------------------------------------------------------
* FUNCTION NAME: Print_DelCache.
* DESCRIPTION:   ɾ����ӡ��ʱ�ļ�
* PARAMETERS:	None
* RETURN:		Return value of _remove()
* NOTES:		Should be called once in MainApp
* ------------------------------------------------------------------------ */
int Print_DelCache(void)
{
    inPrint_Log( __LINE__, "Print_DelCache" );

    memset( inPrint_cHZCasheString_16x16, 0, sizeof( inPrint_cHZCasheString_16x16 ) );
    memset( inPrint_cHZCasheString_24x24, 0, sizeof( inPrint_cHZCasheString_24x24 ) );

    _remove( PRNCACHE_16X16 );
    _remove( PRNCACHE_24X24 );

    return PRINT_OK;
}

/* --------------------------------------------------------------------------
* FUNCTION NAME: Print_PreLoadFont.
* DESCRIPTION:   ����16x16�����ֿ⣬��Print_init��ִ��
* PARAMETERS:
* RETURN:
* NOTES:
* ------------------------------------------------------------------------ */
void Print_PreLoadFont(void)
{
    int fp;
    int i;
    unsigned long lMaxCnt;
    int Ch_id;

    if((fp = open( PRNCACHE_16X16, O_RDONLY)) > 0)
    {
        lMaxCnt = lseek(fp, 0L, SEEK_END);

        if( lMaxCnt > sizeof(inPrint_cHZCasheString_16x16))
            lMaxCnt = sizeof(inPrint_cHZCasheString_16x16);

        lseek( fp, 0L, SEEK_SET);
        read( fp, inPrint_cHZCasheString_16x16, lMaxCnt );
        close( fp );

        inPrint_Log( __LINE__, "sting cache 16x16:%s", inPrint_cHZCasheString_16x16 );

        for( Ch_id = 0, i = 0; i < lMaxCnt; i += 2 )
        {
            inPrint_DownloadHZ( inPrint_iPrinterHandle, (unsigned char *)&inPrint_cHZCasheString_16x16[ i ], Ch_id );

            inPrint_Log( __LINE__, "download hz:%2.2s-%d", &inPrint_cHZCasheString_16x16[ i ], Ch_id );

            Ch_id++;
        }
    }

    if((fp = open( PRNCACHE_24X24, O_RDONLY)) > 0)
    {
        lMaxCnt = lseek(fp, 0L, SEEK_END);

        if( lMaxCnt > sizeof(inPrint_cHZCasheString_24x24))
            lMaxCnt = sizeof(inPrint_cHZCasheString_24x24);

        lseek( fp, 0L, SEEK_SET);
        read( fp, inPrint_cHZCasheString_24x24, lMaxCnt );
        close( fp );

        inPrint_Log( __LINE__, "sting cache 24x24:%s", inPrint_cHZCasheString_24x24 );

        for( Ch_id = 0, i = 0; i < lMaxCnt; i += 2 )
        {
            inPrint_DownloadHZ( inPrint_iPrinterHandle, (unsigned char *)&inPrint_cHZCasheString_24x24[ i ], Ch_id );

            inPrint_Log( __LINE__, "download hz:%2.2s-%d", &inPrint_cHZCasheString_24x24[ i ], Ch_id );

            Ch_id ++;
        }
    }
    return;
}


int Print_Str(char *str, unsigned char attrib)
{
    int i;
    int offset;
    int head;
    int tail;
    int len;
    int hzmode = 0;
    int p_status = 0;
    char buf[1024];

    // ����ӡ��״̬
    inPrint_Log( __LINE__, "Print_Str=" );
    p_status = inPrint_CheckStatus( 0 );
    Print_CheckPrinterStatus( p_status );

    inPrint_GetPrnCacheString( );

    inPrint_Log( __LINE__, "string=%s", str );

    len = strlen( str );

    for( i = 0; i < len; i ++ )
    {
        if( inPrint_IsChinese( &str[ i ] ) )
        {
            head = inPrint_SearchHZ( &str[i], &offset );
            if( head < 0 )
            {
                inPrint_DownloadHZ( inPrint_iPrinterHandle, (unsigned char *)&str[ i ], offset );

                inPrint_Log( __LINE__, "download hz:%2.2s-%d", &str[i], offset );
            }
            else
            {
                inPrint_Log( __LINE__, "search hz:%2.2s-%d", &str[i], head );
            }

            i++;
        }
    }

    hzmode = inPrint_IsChinese( str );

    for(head = tail = 0; tail < len; tail ++)
    {
        if( hzmode == 0 )
        {
            if( inPrint_IsChinese( str + tail))
            {
                hzmode = 1;
                memcpy( buf, str + head, tail - head);
                buf[tail-head] = 0;

                head = tail++; // Chinese has 2 bytes
                inPrint_Print_English( attrib, (unsigned char *)buf );
            }
        }
        else
        {
            if(inPrint_IsChinese(str + tail))
            {
                tail++; // Chinese has 2 bytes
            }
            else
            {
                hzmode = 0;
                memcpy(buf, str + head, tail - head);
                buf[ tail-head] = 0;

                head = tail;

                inPrint_Print_Hz( buf, attrib );
            }
        }
    }

    if( head < len )
    {
        memcpy(buf, str + head, tail - head);
        buf[tail-head] = 0;

        if( hzmode )
            inPrint_Print_Hz( buf, attrib );
        else
            inPrint_Print_English( attrib, (unsigned char *)buf );
    }

    if( inPrint_bNewSprocketMode == 0 )
    {
        if( strchr( str, '\n' ) )
            SVC_WAIT( 10 );
    }

    return 0;
}

/* --------------------------------------------------------------------------
* FUNCTION NAME:  Print_StrStr
* DESCRIPTION:    ��ͬһ�д�ӡ2��buffer with/without justification
* PARAMETERS:
*   cLStr (in) -- �����ַ���
*   cRStr (in) -- �Ҳ���ַ���
*   form (in)  -- ��ӡ��ʽ���ο�TFormat���壩
* RETURN:         none
* NOTES:
*  1.left string can be overwritten by right one, if the strings too long
*  2.form=FORMAT_PRINT   causes left/right-justification of the strings ;
*    form=WITHOUT_FORMAT cause string's concatenation and printing as
*                        single string.
*    form=LEFT_BOLD      causes left/right justification like in the case
*                        of FORMAT_PRINT, left-justified part will be
*                        printed by Bold font.
* ------------------------------------------------------------------------ */
void Print_StrStr(char *cLStr, char *cRStr, TFormat form)
{
    BOOL bIsTotalASCIIFlag;
    BOOL bIsTotalASCIIFlag_R;
    sint i, siPrintSize;
    char tmp[64];

    siPrintSize = PRN_LINE_SIZE;
    bIsTotalASCIIFlag = FALSE;
    bIsTotalASCIIFlag_R = FALSE;

    for (i = 0; i < strlen(cLStr); i++)
    {
        if (!isascii(cLStr[i]))
        {
            bIsTotalASCIIFlag = TRUE;
            break;
        }
    }

    for (i = 0; i < strlen(cRStr); i++)
    {
        if (!isascii(cRStr[i]))
        {
            bIsTotalASCIIFlag = TRUE;
            bIsTotalASCIIFlag_R = TRUE;
            break;
        }
    }

    if( !bIsTotalASCIIFlag_R )
    {
        if( inPrint_iSprocketDotMode == 1 )
            siPrintSize = 40;
        else
            siPrintSize -= 1;
    }
    else if (!bIsTotalASCIIFlag)
    {
        siPrintSize -= 1;
    }

    switch (form)
    {
    case FORMAT_PRINT:
        i = siPrintSize - strlen(cRStr);
        Print_Str(cLStr, NORMAL);

        if ((siPrintSize - strlen(cLStr)) <= strlen(cRStr))
        {
            Print_Str("\n", NORMAL);
        }
        else
        {
            i -= strlen(cLStr);
        }

        if (i > 0)
        {
            memset(tmp, 0, sizeof(tmp));
            memset(tmp, ' ', i);
            Print_Str(tmp, NORMAL);
        }

        Print_Str(cRStr, NORMAL);
        Print_Str("\n", NORMAL);
        break;
    case FORMAT_LBOLD:
        Print_Str(cLStr, DH | DW);

        if ((siPrintSize - strlen(cLStr)*2) < strlen(cRStr))
        {
            Print_Str("\n", NORMAL);
            i = siPrintSize - strlen(cRStr);
        }
        else
        {
            i = siPrintSize - strlen(cLStr) * 2 - strlen(cRStr);
        }

        if (i > 0)
        {
            memset(tmp, 0, sizeof(tmp));
            memset(tmp, ' ', i);
            Print_Str(tmp, NORMAL);
        }

        Print_Str(cRStr, NORMAL);
        Print_Str("\n", NORMAL);
        break;
    case FORMAT_RBOLD:
        Print_Str(cLStr, NORMAL);

        if ((siPrintSize - strlen(cLStr)) < strlen(cRStr)*2)
        {
            Print_Str("\n", NORMAL);
            i = siPrintSize - strlen(cRStr) * 2;
        }
        else
        {
            i = siPrintSize - strlen(cLStr) - strlen(cRStr) * 2;
        }

        if (i > 0)
        {
            memset(tmp, 0, sizeof(tmp));
            memset(tmp, ' ', i);
            Print_Str(tmp, NORMAL);
        }

        Print_Str(cRStr, DW);
        Print_Str("\n", NORMAL);
        break;
    case FORMAT_BOLD:
        Print_Str(cLStr, DH | DW);

        if ((siPrintSize - strlen(cLStr)*2) < strlen(cRStr)*2)
        {
            Print_Str("\n", NORMAL);
            i = siPrintSize - strlen(cRStr) * 2;
        }
        else
        {
            i = siPrintSize - strlen(cLStr) * 2 - strlen(cRStr) * 2;
        }

        if (i > 0)
        {
            memset(tmp, 0, sizeof(tmp));
            memset(tmp, ' ', i);
            Print_Str(tmp, NORMAL);
        }

        Print_Str(cRStr, DH | DW);
        Print_Str("\n", NORMAL);
        break;
    default:
        break;
    }

}

/* --------------------------------------------------------------------------
* FUNCTION NAME: Print_logo.
* DESCRIPTION:   ��ӡlgoͼƬ
* PARAMETERS:
*   Offset ��in��-- ͼƬ��ߵĿհ�
*   LogoFile ��in��-- ͼƬ�ļ����ƣ���׺.lgo��
* RETURN:
*   PRINT_OK/PRINT_NOHANDLE/PRINT_NOPAPER/PRINT_FAIL
* NOTES:
* ------------------------------------------------------------------------ */
int Print_logo(short offset, char *LogoFile)
{
    int  font_file_h;
    int  ret;
    int  i;
    int  p_status = 0;
//    static int dnld_graphic_flag;
//    static char cLogoFileName[ 126 ];

    // ����ӡ��״̬
    p_status = inPrint_CheckStatus( 1 );
    Print_CheckPrinterStatus( p_status );

    if (LogoFile == NULL)
        return PRINT_OK;

//   if( !strstr( cLogoFileName, LogoFile ) )
    {
        // ����LOGO�ļ�
        if ((font_file_h = File_Open(LogoFile, O_RDONLY)) < 0)
        {
            return PRINT_OPENFAIL;
        }

        i = 3;

        while ( i > 0 )
        {
            ret = inPrint_p3700_dnld_graphic_file(inPrint_iPrinterHandle, font_file_h);
            if (ret == 0)
                break;

            SVC_WAIT( 1000 );
            i--;
        }

        File_Close(font_file_h);

//        sprintf( cLogoFileName, "%s", LogoFile );
    }

    // ��ӡLOGO�ļ�
    ret = p3700_print_graphic( inPrint_iPrinterHandle, 0, offset);

    if (ret <= 0)
        return PRINT_FAIL;

    return p_status;
}

/* --------------------------------------------------------------------------
* FUNCTION NAME: Print_bitmap.
* DESCRIPTION:   ��ӡbitmap�ļ�
* PARAMETERS:
*   Offset ��in��-- ͼƬ��ߵĿհ�
*   BmpFile ��in��-- ͼƬ�ļ����ƣ���׺.bmp��
* RETURN:
*   PRINT_OK/PRINT_NOHANDLE/PRINT_NOPAPER/PRINT_FAIL
* NOTES:��ӡ��bmp֮�󣬴�ӡ����handle���ر��ˡ���Ҫ���´򿪴�ӡ���豸����ʼ����
* ------------------------------------------------------------------------ */
int Print_bitmap(short offset, char *BmpFile)
{
    int  iRet;
    int  p_status = 0;

    if (BmpFile == NULL)
        return PRINT_OK;

    // ����ӡ��״̬
    p_status = inPrint_CheckStatus( 1 );
    Print_CheckPrinterStatus( p_status );

    inPrint_Log( __LINE__, "Print_bitmap, printer handle=[%d]", inPrint_iPrinterHandle );

    //ret = print_image(offset, BmpFile);
    iRet = inPrint_Bitmap( inPrint_iPrinterHandle, offset, BmpFile);

    inPrint_Log( __LINE__, "Print_bitmap ret=[%d]", iRet );

    return iRet;
}

/* --------------------------------------------------------------------------
* FUNCTION NAME: Print_English.
* DESCRIPTION:   ��ӡӢ���ַ���
* PARAMETERS:
*   english_str (in) -- Ӣ���ַ���
*   font_size (in) -- 0x02, 0x03, 0x04
* RETURN:
*   PRINT_OK/PRINT_NOHANDLE/PRINT_NOPAPER/PRINT_FAIL
* NOTES:
*   ����������ӡ��
*   0x02���壬һ�пɴ�ӡ24���ַ�
*   0x03���壬һ�пɴ�ӡ32���ַ�
*   0x04���壬һ�пɴ�ӡ42���ַ�
*   ������ʽ��ӡ��
*   0x02���壬һ�пɴ�ӡ30���ַ�
*   0x03���壬һ�пɴ�ӡ15���ַ�
*   0x04���壬һ�пɴ�ӡ20���ַ�
* ------------------------------------------------------------------------ */
int Print_English(char *english_str, short font_size)
{
    int  p_status = 0;

    // ����ӡ��״̬
    p_status = inPrint_CheckStatus( 0 );
    Print_CheckPrinterStatus( p_status );

    if( inPrint_bNewSprocketMode == 1 )
    {
        inPrint_Print_English( NORMAL, (unsigned char *)english_str );
        return PRINT_OK;
    }

    // ESC=0x1B, a22=�����и߶�22
    //inPrint_p3700_print( inPrint_iPrinterHandle, (unsigned char *)"\x1B""a22;");

    inPrint_p3700_select_font( inPrint_iPrinterHandle, font_size, 0);
    inPrint_p3700_print( inPrint_iPrinterHandle, (unsigned char *)english_str);

    return p_status;
}

/* --------------------------------------------------------------------------
* FUNCTION NAME: Print_EngSmall.
* DESCRIPTION:   ��ӡӢ���ַ���
* PARAMETERS:
*   english_str ��in��-- Ӣ���ַ���
* RETURN:
*   PRINT_OK/PRINT_NOHANDLE/PRINT_NOPAPER/PRINT_FAIL
* NOTES:
*   ����������ӡ����һ�пɴ�ӡ42���ַ�
*   ������ʽ��ӡ����һ�пɴ�ӡ30���ַ�
* ------------------------------------------------------------------------ */
int Print_EngSmall(char *english_str)
{
    int  p_status = 0;

    // ����ӡ��״̬
    p_status = inPrint_CheckStatus( 0 );
    Print_CheckPrinterStatus( p_status );

    if( inPrint_bNewSprocketMode == 1 )
    {
        inPrint_Print_English( NORMAL, (unsigned char *)english_str );
        return PRINT_OK;
    }

    if ( MmiUtil_GetPrinterType() == SPROCKET_PRINTER )
    {
        inPrint_p3700_print(inPrint_iPrinterHandle, (unsigned char *)"\x1B""a22;");
        inPrint_p3700_select_font(inPrint_iPrinterHandle, 0x02, 0);
    }
    else
    {
        //inPrint_p3700_print(inPrint_iPrinterHandle, (unsigned char *)"\x1B""a16;");
        inPrint_p3700_select_font(inPrint_iPrinterHandle, 0x04, 0);
    }

    inPrint_p3700_print(inPrint_iPrinterHandle, (unsigned char *)english_str);

    return p_status;
}

/* --------------------------------------------------------------------------
 * FUNCTION NAME: Print_Hex
 * DESCRIPTION:   ��ӡ16��������.
 * PARAMETERS:
 *    msgPrompt (in) - ��ʾ��Ϣ
 *    Buf       (in) - ����
 *    BufLen    (in) - ���ݳ���.
 * RETURN:
 * NOTES:
 * ------------------------------------------------------------------------ */
void Print_Hex(char *msgPrompt, byte *Buf, int BufLen)
{
    char  out[128], tmp[128];
    usint i, j, k;

    Print_Str((char *)msgPrompt, 0);
    Print_Str("\n", 0);

    sprintf(tmp, "%03hu|---------Hex-------+\n", BufLen);
    Print_Str(tmp, 0);

    if ( BufLen > 1000 )
    {
        Print_Str( "BufLen is too large!\n", 0 );
        return;
    }

    j = (BufLen % 8) ? (BufLen / 8 + 1) : (BufLen / 8);

    for (i = 0; i < j; i++)
    {
        sprintf(out, "%03u| ", i*8);

        for (k = 0; k < 8; k++)
        {
            sprintf(tmp, "%02X", Buf[i*8+k]);
            strcat(out, tmp);

            if (k == 3)
            {
                strcat(out, " ");
            }
        }

        strcat(out, "\n");
        Print_Str(out, 0);
    }

    Print_Str("+----------------------+\n", 0);

    return;
}

/* -----------------------------------------------------------------------
* FUNCTION NAME:  Print_FormFeed
* DESCRIPTION:    ��ʽ��ӡ����ҳָ��
* PARAMETERS :
* RETURN:
* NOTES:
 * ----------------------------------------------------------------------*/
int Print_FormFeed(void)
{
    int p_status = 0;

    if ( MmiUtil_GetPrinterType() != SPROCKET_PRINTER)  // �������ͣ�ֱ�ӷ��� 0
        return 0;

    // ����ӡ��״̬
    p_status = inPrint_CheckStatus( 1 );
    Print_CheckPrinterStatus( p_status );

    inPrint_Log( __LINE__, "form feed start" );

    //inPrint_p3700_print(inPrint_iPrinterHandle, (unsigned char *)"\x18");  // clear print buffer
    inPrint_p3700_print(inPrint_iPrinterHandle, (unsigned char *)"\x0B");

    //inPrint_CheckStatus( 1 );

    inPrint_Log( __LINE__, "form feed end" );
    return p_status;
}

/* -----------------------------------------------------------------------
* FUNCTION NAME:  Print_SetLineHeight
* DESCRIPTION:    �����и߶�
* PARAMETERS :
*     height(in) -- �и߶�(default is 22, min is 16, max is 48)
* RETURN:
* NOTES:
 * ----------------------------------------------------------------------*/
void Print_SetLineHeight(int height)
{
    char buf[10];
    int p_status = 0;

    // ����ӡ��״̬
    p_status = inPrint_CheckStatus( 1 );
    if( p_status == PRINT_NOHANDLE )
        return;

    //inPrint_p3700_print( inPrint_iPrinterHandle, (unsigned char *)"\x18");  // clear print buffer

    memset(buf, 0, sizeof(buf));
    sprintf(buf, "\x1B""a%d;", height);
    inPrint_p3700_print(inPrint_iPrinterHandle, (unsigned char *)buf);

    return;
}

/* -----------------------------------------------------------------------
* FUNCTION NAME:  Print_SetFormLength
* DESCRIPTION:    �������ֽҳ�泤��
* PARAMETERS :
*     length(in) -- ҳ�泤��(default is 140mm, max is 300mm)
* RETURN:
* NOTES:
 * ----------------------------------------------------------------------*/
void Print_SetFormLength(int length)
{
    char buf[10];
    int  p_status = 0;

    // ����ӡ��״̬
    p_status = inPrint_CheckStatus( 1 );
    if( p_status == PRINT_NOHANDLE )
        return;

    //inPrint_p3700_print(inPrint_iPrinterHandle, (unsigned char *)"\x18");  // clear print buffer

    memset(buf, 0, sizeof(buf));
    sprintf(buf, "\x1B""K%d;", length);
    inPrint_p3700_print(inPrint_iPrinterHandle, (unsigned char *)buf);

    return;
}


/* -----------------------------------------------------------------------
* FUNCTION NAME:  Print_Feed
* DESCRIPTION:    ��ʽ��ӡ����ֽ/��ָֽ��
* PARAMETERS :
*   flag(in)   - FORWARD_PAPER:��ֽ/ REVERSE_PAPER:��ֽ
*   length(in) - ����
* RETURN:
* NOTES:
 * ----------------------------------------------------------------------*/
int Print_Feed(int flag, int length)
{
    int p_status = 0;
    char buf[20];

    if( flag != FORWARD_PAPER && flag != REVERSE_PAPER)
        return PRINT_OK;

    // ����ӡ��״̬
    p_status = inPrint_CheckStatus( 1 );
    Print_CheckPrinterStatus( p_status );

    // Added by @laikey_20130321 -->
    if ( MmiUtil_GetTerminalType( ) == _VX805 )
    {
        inPrint_Feed_Vx805( flag, length );
        return p_status;
    }
    // <--

    //inPrint_p3700_print(inPrint_iPrinterHandle, (unsigned char *)"\x18");  // clear print buffer

    memset(buf, 0, sizeof(buf));
    sprintf(buf, "\x1B""b%d,%d;", length, flag);

    inPrint_p3700_print(inPrint_iPrinterHandle, (unsigned char *)buf);

    if( MmiUtil_GetPrinterType() == SPROCKET_PRINTER &&
            MmiUtil_GetTerminalType() == _VX520S )
    {
        unsigned long lTrytimer;
        int iStatus;

        lTrytimer = read_ticks();
        while( 1 )
        {
            if( !inPrint_CheckReadlyStatus( 1, &iStatus ) )
                break;

            if( read_ticks() - lTrytimer > 500 )
                break;
        }
    }

    inPrint_Log( __LINE__, "Print_Feed(%d,%d) send ok!", flag, length );
    return p_status;
}

/* --------------------------------------------------------------------------
* FUNCTION NAME: Print_SetDark.
* DESCRIPTION:   ���ô�ӡ�ڶ�*DARK
* PARAMETERS:
*    darkValue(in) ----- (ȡֵ��Χ1-29)
* RETURN:
*		PRINT_NOHANDLE/PRINT_OK
* NOTES:
* ------------------------------------------------------------------------ */
void Print_SetDark(int darkValue)
{
    char buf[40];
    int  p_status = 0;

    // ����ӡ��״̬
    p_status = inPrint_CheckStatus( 1 );
    if( p_status == PRINT_NOHANDLE)
        return;

    inPrint_p3700_print(inPrint_iPrinterHandle, (unsigned char *)"\x18");  // clear print buffer

    memset(buf, 0, sizeof(buf));
    sprintf(buf, "\x1B""w%d;", darkValue);

    inPrint_p3700_print(inPrint_iPrinterHandle, (unsigned char *)buf);
}


/* --------------------------------------------------------------------------
* FUNCTION NAME: Print_Str_12.
* DESCRIPTION:   ��ͼ�η�ʽ��ӡ�����У�12x12��Ӣ�ģ�5x8���ִ��ĺ���
* PARAMETERS:
*		  str (in) -- Ҫ��ӡ���ַ���
*		  attrib (in) -- ��ӡ����, ��ʱ����
* RETURN:
*		PRINT_OK/PRINT_NOHANDLE/PRINT_NOPAPER/PRINT_FAIL
* NOTES:
* ------------------------------------------------------------------------ */
int Print_Str_12(char *str, unsigned char attrib)
{
    int len, i, j;
    short fp, fp1, retVal;
    char filename[32], tmp[4];
    char Printmode[4]= {0};
    char ioctl_status[4];
    unsigned char buf[32], linebuf[32*12];	// 12��, ÿ��15���֣�ÿ���ֵ�ÿ��
    int ret;
    long end;
    BOOL bIsGbkFont12;

    if (strlen(str) == 0)
        return PRINT_OK;

    // Added by @laikey_20130321 -->
    if ( MmiUtil_GetTerminalType() == _VX805)
    {
        return ( inPrint_Print_Str_12_Vx805( str, attrib ) );
    }
    // <--

    bIsGbkFont12 = isGbkFont12();
    if (bIsGbkFont12)
    {
        strcpy(filename, GBKFONT_12);
    }
    else
    {
        strcpy(filename, CHNFONT_12);
    }
    if ((fp = open(filename,O_RDONLY)) < 0)
        return PRINT_NOHANDLE;

    strcpy(filename, ENGFONT_5x8);
    if ((fp1 = open(filename,O_RDONLY)) < 0)
        return PRINT_NOHANDLE;

    //**************************************************************************************
    // Start the graphics mode of printing the data
    //ESC g is the command for going to the graphicsa mode
    //**************************************************************************************
    memset( Printmode, 0, 4 );
    memset( ioctl_status, 0, 4 );
    Printmode[ 0 ] = 0x1b;
    Printmode[ 1 ] = 0x67;

    while (get_port_status(inPrint_iPrinterHandle,ioctl_status)!=0)
        SVC_WAIT(2);

    end = set_itimeout(-1, 2, TM_SECONDS);
    while (write(inPrint_iPrinterHandle,Printmode,2) != 2)
    {
        SVC_WAIT(10);
        if (!CHK_TIMEOUT(-1, end))
        {
            close(fp);
            close(fp1);
            return 	WRITE_FAIL;
        }
    }

    //**************************************************************************************
    //Now thw bitmap will have the data in the reverse hence the last data of the bitmap
    //will be the first data hnece get the data in reverse
    //the value of the buffer is memset to 0x0c 1100 0000 which will not print data
    //Container should have 1 1			0 0 0 0 0 0
    //						| |			| | | | | |
    //					Non printing	Printing data
    //**************************************************************************************

    len = strlen( str );
    if (len > 30)	/* ֻ��ӡһ�� */
        len = 30;

    memset(linebuf, 0, sizeof(linebuf));

    for (i = 0; i < 12; i ++)
    {

        memset(buf, 0xC0, sizeof(buf));

        for (j = 0; j < len; j ++ )
        {
            if (bIsGbkFont12 && (unsigned char)str[j] >= 0x81 && (unsigned char)str[j+1] >= 0x40)
            {
                lseek(fp, inPrint_GetGBKOffset(str[j], str[j+1])*24 + 128*12 + 16 + (i * 2), SEEK_SET);

                read(fp, tmp, 2);

                /* 12x12����ÿ����2���ֽ���ɣ�ʵ��ֻռ����12��BIT */
                buf[j] |= tmp[0] >> 2;
                buf[j + 1] |= (tmp[0] << 6) >> 2;
                buf[j + 1] |= tmp[1] >> 4;
                j ++;
            }
            else if ((unsigned char)str[j] >= 0xA1 && (unsigned char)str[j+1] >= 0xA0)
            {
                lseek(fp, inPrint_GetGB2312Offset(str[j], str[j+1])*24 + (i * 2), SEEK_SET);

                read(fp, tmp, 2);

                /* 12x12����ÿ����2���ֽ���ɣ�ʵ��ֻռ����12��BIT */
                buf[j] |= tmp[0] >> 2;
                buf[j + 1] |= (tmp[0] << 6) >> 2;
                buf[j + 1] |= tmp[1] >> 4;
                j ++;
            }
            else if (i > 3) //ʹ��5x8��Ӣ�ģ��¶���
            {
                lseek(fp1, (8 + str[j] * 9 + 1 + i - 4), SEEK_SET);
                read(fp1, tmp, 1);

                /* 5x8����ÿ��1���ֽڣ�ʵ��ռ�ú�5��BIT */
                buf[j] |= tmp[0];
            }
        }
        buf[j] = 0x21;	/* ���� */

        if (j == 30)
            memcpy(linebuf + i * j, buf, j);
        else
            memcpy(linebuf + i * (j + 1), buf, j + 1);
    }
    linebuf[strlen((char *)linebuf)] = 0x21;	/* �о�һ������ */

    do
    {
        while (get_port_status(inPrint_iPrinterHandle, ioctl_status)!=0)
            SVC_WAIT(0);

        retVal = write(inPrint_iPrinterHandle,(char *)linebuf, strlen((const char *)linebuf));
    }
    while ((retVal<0) && (errno == ENOSPC || errno == ENXIO));

    //***********************************************************************************************
    // Exit from the graphics mode passing the 0x18 CAN command ie the 0001 0100 the fifth bit should be set to 1
    //***********************************************************************************************
    memset(Printmode,0,4);
    Printmode[0]=0x18;
    while (get_port_status(inPrint_iPrinterHandle, ioctl_status)!=0)
        SVC_WAIT(0);

    ret = PRINT_OK;
    end = set_itimeout(-1, 2, TM_SECONDS);
    while (write(inPrint_iPrinterHandle,Printmode,1) < 0)
    {
        SVC_WAIT(10);
        if (!CHK_TIMEOUT(-1, end))
        {
            ret = WRITE_FAIL;
            break;
        }
    }

    close(fp);
    close(fp1);
    SVC_WAIT(10);
    return ret;

}


int Print_SetSprocketDotMode(int dotmode)
{
    open_block_t parm;

    memset(&parm, 0, sizeof(parm));
    get_opn_blk( inPrint_iPrinterHandle, &parm );

    if(dotmode == MODE_360_DOTS)
    {
        inPrint_iSprocketDotMode = MODE_360_DOTS;
        parm.trailer.bytes.b[0] = 1;
    }
    else
    {
        inPrint_iSprocketDotMode = MODE_180_DOTS ;
        parm.trailer.bytes.b[0] = 0;
    }

    set_opn_blk( inPrint_iPrinterHandle, &parm );

    //SVC_WAIT( 100 );

    return inPrint_iSprocketDotMode;
}


/* --------------------------------------------------------------------------
* FUNCTION NAME:  Print_SetFont
* DESCRIPTION:  ���ô�ӡ���壬Ŀǰ֧��16x16,24x24
* PARAMETERS:
*   iFontSize (in)	=16:16X16
					=24:24X24
* RETURN: BANK_OK/BANK_FAIL
* NOTES:
	��ʱֻ֧��������ӡ�������������
* ------------------------------------------------------------------------ */
int Print_SetFontSize( PRINTFONTSIZE iFontSize )
{
    int fd;
    char cFontFile[ 126 ];

    if( inPrint_iFontSize == iFontSize )
        return PRINT_OK;

    if( iFontSize == PRINT_FONT24 )
        sprintf( cFontFile, "%s", CHNFONT_24T );
    else
        sprintf( cFontFile, "%s", CHNFONT );

    fd = open( cFontFile, F_RDONLY );
    if( fd <= 0 )
        return PRINT_FAIL;

    close( fd );

    inPrint_Log( __LINE__, "print set font size:%d, ok", iFontSize );

    inPrint_iFontSize = iFontSize;
    return PRINT_OK;
}


/* --------------------------------------------------------------------------
* FUNCTION NAME: Print_Pixel.
*
* DESCRIPTION: ��ӡ����������
*
* PARAMETERS:
*	pcPixelData			- ��Ҫ��ӡ�ĵ�������
*	iWidth				- ��ӡ���ݵĿ���
*	iHeight				- ��ӡ���ݵĸ߶�
*	iAlignMode			- ���뷽ʽ:LEFT_JST,RIGHT_JST,CENTER_JST
*
* RETURN:
*		enumPrintRet:PRINT_OK/PRINT_FAIL
		-10:�Ŵ���ӡ���ȳ���384����
*
* NOTES:
*		��ⳬʱʱ��Ϊ30��
* ------------------------------------------------------------------------ */
int Print_Pixel( unsigned char *pcPixelData, int iWidth, int iHeight, int iAlignMode )
{
    unsigned char *pcLineBuf;
    int iRet;
    int x, y;
    int iLength;
    int iOffset;
    long lTimer;
    char cPrintMode[ 4 ] = {0};
    char cIOstatus[ 4 ];

    if( pcPixelData == NULL )
        return PRINT_FAIL;

    if( inPrint_iPrinterHandle <= 0 )
        return PRINT_NOHANDLE;

    memset(cPrintMode, 0, 4);
    memset(cIOstatus, 0, 4);
    cPrintMode[ 0 ] = 0x1b;
    cPrintMode[ 1 ] = 'g';

    while( get_port_status(inPrint_iPrinterHandle, cIOstatus) != 0)
        SVC_WAIT( 2 );

    lTimer = set_itimeout(-1, 2, TM_SECONDS);
    while( write( inPrint_iPrinterHandle, cPrintMode, 2) != 2)
    {
        SVC_WAIT( 10 );
        if( !CHK_TIMEOUT( -1, lTimer ) )
            return  PRINT_FAIL;
    }

    iLength = (iWidth + 5) / 6;	 // ÿ�ֽ�6����

    if(iAlignMode == LEFT_JST )
        iOffset = 0;
    else if(iAlignMode == CENTER_JST )
        iOffset = (63 - iLength)/2;
    else
        iOffset = (63 - iLength);

    if( iOffset < 0 )
        iOffset = 0;

    pcLineBuf = (unsigned char *) malloc(iLength + iOffset + 1);

    while( get_port_status( inPrint_iPrinterHandle, cIOstatus) != 0)
        SVC_WAIT(0);

    //��ʼ���д�ӡ
    for( y = 0; y < iHeight; y ++ )
    {
        memset( pcLineBuf, 0, sizeof( pcLineBuf ) );
        memset( pcLineBuf, 0xC0, iOffset + iLength + 1 );
        for( x = 0; x < iWidth; x++)
        {
            if( pcPixelData[y * iWidth + x ] & 0x01 )
                pcLineBuf[ iOffset + x / 6 ] |= 1 << (6 - x % 6 - 1);
        }

        pcLineBuf[ iOffset + iLength ] = 0x21;  /* ���� */

        do
        {
            iRet = write( inPrint_iPrinterHandle, (char *)pcLineBuf, iOffset + iLength + 1);
        }
        while( (iRet < 0) && (errno == ENOSPC || errno == ENXIO));
    }

    while( get_port_status(inPrint_iPrinterHandle, cIOstatus) != 0)
        SVC_WAIT(0);

    iRet = PRINT_OK;
    lTimer = set_itimeout( -1, 2, TM_SECONDS);

    memset(cPrintMode, 0, 4);
    cPrintMode[ 0 ] = 0x18;
    while( write(inPrint_iPrinterHandle, cPrintMode, 1) < 0)
    {
        SVC_WAIT(10);

        if(!CHK_TIMEOUT(-1, lTimer))
        {
            iRet = PRINT_FAIL;
            break;
        }
    }

    free( pcLineBuf );
    return iRet;
}


/*-----------------------------------------------------------------------
 * FUNCTION NAME: Print_QRCode
 * DESCRIPTION:	��ӡQR��
 * PARAMETER:	qrcode - In
          		PixSize - In ͼ��Ŵ���
 * RETURN:		PRINT_OK / PRINT_FAIL
 * NOTE:
 *----------------------------------------------------------------------*/
int Print_QRCode( QRcode *stQRcode, int iZoomX, int iAlignMode )
{
    unsigned char *pcLineBuf;
    int width, height;
    int iRet;
    int x, y;
    int iLength;
    long lTimer;
    int iOffset;
    char cPrintMode[ 4 ] = {0};
    char cIOstatus[ 4 ];

    if(	stQRcode == NULL || stQRcode->data == NULL )
        return PRINT_FAIL;

    width = stQRcode->width * iZoomX;
    height = stQRcode->width * iZoomX;

    if( inPrint_iPrinterHandle <= 0 )
        return PRINT_NOHANDLE;

    memset(cIOstatus, 0, 4);
    while( get_port_status(inPrint_iPrinterHandle, cIOstatus) != 0)
        SVC_WAIT(2);

    lTimer = set_itimeout(-1, 2, TM_SECONDS);

    memset(cPrintMode, 0, 4);
    cPrintMode[ 0 ] = 0x1b;
    cPrintMode[ 1 ] = 'g';
    while( write( inPrint_iPrinterHandle, cPrintMode, 2) != 2)
    {
        SVC_WAIT( 10 );

        if( !CHK_TIMEOUT( -1, lTimer ) )
            return  PRINT_FAIL;
    }

    iLength = (width + 5) / 6;   // ÿ�ֽ�6����

    if(iAlignMode == LEFT_JST )
        iOffset = 0;
    else if(iAlignMode == CENTER_JST )
        iOffset = (63 - iLength)/2;
    else
        iOffset = (63 - iLength);

    if( iOffset < 0 )
        iOffset = 0;

    pcLineBuf = (unsigned char *) malloc( iOffset + iLength + 1);

    while( get_port_status( inPrint_iPrinterHandle, cIOstatus) != 0)
        SVC_WAIT(0);

    //��ʼ���д�ӡ
    for( y = 0; y < height; y ++ )
    {
        memset( pcLineBuf, 0, sizeof( pcLineBuf ) );
        memset( pcLineBuf, 0xC0, iOffset + iLength + 1 );
        for( x = 0; x < width; x++)
        {
            if( stQRcode->data [y / iZoomX * stQRcode->width + x / iZoomX ] & 0x01 )
                pcLineBuf[ iOffset + x / 6 ] |= 1 << (6 - x % 6 - 1);
        }

        pcLineBuf[ iOffset + iLength ] = 0x21;  /* ���� */

        do
        {
            iRet = write( inPrint_iPrinterHandle, (char *)pcLineBuf, iOffset + iLength + 1);
        }
        while( (iRet < 0) && (errno == ENOSPC || errno == ENXIO));
    }

    while( get_port_status(inPrint_iPrinterHandle, cIOstatus) != 0)
        SVC_WAIT(0);

    iRet = PRINT_OK;
    lTimer = set_itimeout( -1, 2, TM_SECONDS);

    memset(cPrintMode, 0, 4);
    cPrintMode[ 0 ] = 0x18;
    while( write(inPrint_iPrinterHandle, cPrintMode, 1) < 0)
    {
        SVC_WAIT(10);

        if(!CHK_TIMEOUT(-1, lTimer))
        {
            iRet = PRINT_FAIL;
            break;
        }
    }

    free( pcLineBuf );
    return iRet;
}


/*-----------------------------------------------------------------------
 * FUNCTION NAME: Print_SetUIScheme
 * DESCRIPTION:	���ô�ӡ�����״̬���Ƿ���ʾ��ʾ��Ϣ
 * PARAMETER:	iUIStatus - 1: ����ʾ״̬��Ϣ
 						  - 0: ��ʾ״̬��Ϣ
 * RETURN:		PRINT_OK / PRINT_FAIL
 * NOTE:
 *	������Ҫ,���ڵ���Print_Init��ʼ�����趨, ϵͳĬ��Ϊ0
 *----------------------------------------------------------------------*/
int Print_SetUIScheme( int iUIStatus )
{
    inPrint_iUIScheme = iUIStatus;

    inPrint_Log( __LINE__, "Print_SetUIScheme, inPrint_iUIScheme=%d", inPrint_iUIScheme );
    return PRINT_OK;
}


/*=========================================*
*   P R I V A T E     F U N C T I O N S   *
*=========================================*/

// debugģʽlog��־���
static void inPrint_Log( int iLine, char *pString, ... )
{
#ifdef	LOGSYS_FLAG
    static int init_status;
    struct Opn_Blk com_parm;
    char cMsgBuf[ 2048 ];
    char *pArg;
    va_list v_Arg;
    char *pComName = "/DEV/COM1";

    memset( cMsgBuf, 0, sizeof( cMsgBuf ) );
    sprintf( cMsgBuf, "[line=%d],", iLine );

    if( pString != NULL )
    {
        pArg = strchr( pString, '%' );

        if( pArg )
        {
            va_start( v_Arg, pString );
            vsprintf( cMsgBuf+strlen( cMsgBuf ), pString, v_Arg );
            va_end( v_Arg );
        }
        else
        {
            strcpy( cMsgBuf+strlen( cMsgBuf ), pString );
        }
    }

    if( !strchr( cMsgBuf, '\n') )
        strcat( cMsgBuf, "\n" );

    // Output message by COM
    if( init_status != 99 )
    {
        com_parm.rate = Rt_115200;
        com_parm.format = Fmt_A8N1;
        com_parm.protocol = P_char_mode;
        com_parm.parameter = 0;
        if( ComDev_Init( pComName, &com_parm ) == COMDEV_NOHANDLE )
            return;

        init_status = 99;
    }

    ComDev_Write( pComName, cMsgBuf, strlen( cMsgBuf ) );
#endif
    return;
}


static char inPrint_IsChinese(char *s)
{
    unsigned char us[3];
    memcpy(us, s, 2);

    if (isGbkFont16())	//added by baijz 20130515 for GBK
    {
        if (us[0] >= 0x81 && us[1] >= 0x40)
            return 1;
    }
    else
    {
        if (us[0] >= 0xA1 && us[1] > 0xA0)
            return 1;
    }

    return 0;
}


//�жϸú����Ƿ���Ҫ��ѹ��
int inPrint_CheckNotshzCasheString( char *str )
{
    char cTmpBuf[ 3 ];

    memset( cTmpBuf, 0, sizeof( cTmpBuf ) );
    memcpy( cTmpBuf, str, 2 );

    if( strstr( inPrint_NoTshzString, cTmpBuf ) )
        return 1;
    else
        return 0;
}


//��ȡ����Ҫ��ѹ��������,��Щ�����ڴ�ӡʱѹ�������ӡ��ῴ���庺��ԭ��
int inPrint_GetNNotshzCacheString( void )
{
    int fp;
    long file_size = 0;

    memset( inPrint_NoTshzString, 0, sizeof( inPrint_NoTshzString ) );

    if( (fp = open( "/notshz.txt", O_RDONLY ) ) <= 0 )
        return 0;

    file_size = lseek(fp, 0L, SEEK_END);

    if ( file_size > sizeof( inPrint_NoTshzString ) )
        file_size = sizeof( inPrint_NoTshzString );

    lseek( fp, 0L, SEEK_SET );
    read( fp, inPrint_NoTshzString, file_size );
    close( fp );

    inPrint_Log( __LINE__, "not switchhz cache:%s", inPrint_NoTshzString );

    return 1;
}


//��ȡ��ӡ�������ص������ݵĺ����б�
int inPrint_GetPrnCacheString( void )
{
    int fp;
    long file_size = 0;

    if( inPrint_GetFontSize( ) == PRINT_FONT24 )
    {
        memset( inPrint_cHZCasheString_24x24, 0, sizeof( inPrint_cHZCasheString_24x24) );
        if( (fp = open( PRNCACHE_24X24, O_RDONLY ) ) <= 0 )
        {
            fp = open(PRNCACHE_24X24, O_WRONLY | O_CREAT);
            close( fp );
            return 0;
        }

        file_size = lseek(fp, 0L, SEEK_END);

        if ( file_size > sizeof( inPrint_cHZCasheString_24x24 ) )
            file_size = sizeof( inPrint_cHZCasheString_24x24 );

        lseek( fp, 0L, SEEK_SET );
        read( fp, inPrint_cHZCasheString_24x24, file_size );
        close( fp );

        //inPrint_Log( __LINE__, "sting cache:%s", inPrint_cHZCasheString_24x24 );

        return strlen( inPrint_cHZCasheString_24x24 );
    }
    else
    {
        memset( inPrint_cHZCasheString_16x16, 0, sizeof( inPrint_cHZCasheString_16x16 ) );
        if( (fp = open( PRNCACHE_16X16, O_RDONLY ) ) <= 0 )
        {
            fp = open(PRNCACHE_16X16, O_WRONLY | O_CREAT);
            close( fp );
            return 0;
        }

        file_size = lseek(fp, 0L, SEEK_END);

        if ( file_size > sizeof( inPrint_cHZCasheString_16x16 ) )
            file_size = sizeof( inPrint_cHZCasheString_16x16 );

        lseek( fp, 0L, SEEK_SET );
        read( fp, inPrint_cHZCasheString_16x16, file_size );
        close( fp );

        //inPrint_Log( __LINE__, "sting cache:%s", inPrint_cHZCasheString_16x16 );

        return strlen( inPrint_cHZCasheString_16x16 );
    }

}

// ���Ҹú����Ƿ��Ѿ����ع�����
static int inPrint_SearchHZ( char *str, int *index )
{
    int i;
    int len;

    if( inPrint_GetFontSize( ) == PRINT_FONT24 )
    {
        len = strlen( inPrint_cHZCasheString_24x24 );
        if( len <= 0 )
        {
            *index = 0;
            return -1;
        }

        for( i = 0; i < len; i += 2 )
        {
            if( memcmp( inPrint_cHZCasheString_24x24+ i, str, 2 ) == 0 )
            {
                i >>= 1;	// i /= 2;
                return i;
            }
        }
    }
    else
    {
        len = strlen( inPrint_cHZCasheString_16x16 );
        if( len <= 0 )
        {
            *index = 0;
            return -1;
        }

        for( i = 0; i < len; i += 2 )
        {
            if( memcmp( inPrint_cHZCasheString_16x16 + i, str, 2 ) == 0 )
            {
                i >>= 1;	// i /= 2;
                return i;
            }
        }
    }

    *index = i >> 1;
    return -1;
}


// 8X8 bits����ת�ã���1X8�ֽ�
void inPrint_Turn_8X8(unsigned char *ary, unsigned char *dst)
{
    unsigned char mask;
    int i, j;

    for(i = 0; i < 8; i++)
    {
        dst[i] = 0;
        mask = 0x80;

        for(j = 0; j < 8; j++)
        {
            if(j <= i)
                dst[i] |= (ary[j] << (i - j)) & mask;
            else
                dst[i] |= (ary[j] >> (j - i)) & mask;

            mask >>= 1;
        }
    }
}


// ����2���޷����ַ��ͱ�����ֵ(��ָ��)
void inPrint_Swap_Val(unsigned char *Val1, unsigned char *Val2)
{
    unsigned char Temp;

    Temp = *Val1;
    *Val1 = *Val2;
    *Val2 = Temp;
}


// 24X24 bits����ת�ã��ֳ�3X3=9��8bits X 8bits�Ŀ�
void inPrint_Turn_24X24(unsigned char *ary, unsigned char *dst)
{
    int i, j, k;
    unsigned char im_ary[8], dest_ary[8];

    memcpy(dst, ary, 72);

    // ��һ��ѭ��, 3X3���ת��
    for(i = 0; i < 3; i++)
    {
        for(j = 0; j < 3; j++)
        {
            if(i <= j)  //�Խ��߼����µĲ���
                continue;

            for(k = 0; k < 8; k++)
            {
                inPrint_Swap_Val(&dst[i + k * 3 + j * 24], &dst[j + k * 3 + i * 24]);
            }
        }
    }

    // �ڶ���ѭ��, 8bits X 8bits����ת��
    for(i = 0; i < 3; i++)
    {
        for(j = 0; j < 3; j++)
        {
            memset(im_ary, 0, sizeof(im_ary));

            for(k = 0; k < 8; k++)
            {
                im_ary[k] = dst[i + k * 3 + j * 24 ];
            }

            memset(dest_ary, 0, sizeof(dest_ary));
            inPrint_Turn_8X8(im_ary, dest_ary);

            for(k = 0; k < 8; k++)
            {
                dst[i + k * 3 + j * 24 ] = dest_ary[k];
            }
        }
    }
}


// ˮƽ���е�24X24���ֵ���ת������8X8�Ŀ�, ������, ������������
static void inPrint_ConvertH2V( unsigned char *src, unsigned char *dest )
{
    int i, j, k;

    k = 0;

    for( i = 0; i < 9; i++ )
    {
        for( j = 0; j < 8; j++ )
        {
            dest[k] = src[( i/3 )*24 + i%3 + j*3];
            k++;
        }
    }
}

// ���غ��ֵ�������
int inPrint_Download_Hz_font(char Tab_id, char Ch_id, unsigned char *buf_pft, int buf_length)
{
    int ret;
    int retry;
    int len;
    char scmd[128];

    // select font size id and table id
    if( inPrint_GetFontSize( ) == PRINT_FONT24 )
        sprintf(scmd, "\x1bl5%d;", Tab_id);
    else
        sprintf(scmd, "\x1bl1%d;", Tab_id);
    inPrint_WriteStr(inPrint_iPrinterHandle, (unsigned char *)scmd);

    // prepare download font command
    scmd[0] = 0x1b;
    scmd[1] = 'm';
    scmd[2] = Ch_id;
    memcpy(scmd + 3, buf_pft, buf_length );
    scmd[buf_length+3] = ';';

    retry = 0;
    len = buf_length + 4;
    SVC_WAIT( 5 );

    while((ret = write(inPrint_iPrinterHandle, scmd, len)) != len && retry < 6)
    {
        SVC_WAIT( 200 );
        retry++;
    }

    return ret;
}


//���Һ�����Ӧ�ĵ������ݲ�����
static int inPrint_DownloadHZ(int printer_h , unsigned char *str, int totalhz)
{
    int fd;
    int i, j, k, qu, wei;
    unsigned long offset;
    int Ch_id;
    unsigned char buf[ 126 ], buf1[ 126 ];
    char fontName[21];
    BOOL bIsGbkFont16;

    if( printer_h <= 0 )
        return 0;

    if( inPrint_GetFontSize() == PRINT_FONT24 )
    {
#if 0
        // for gbk 24x24
        if( str[ 0 ] >= 0x81 && str[ 1 ] >= 0x40 )
            offset = ((str[ 0 ]-0x81)*191 + (str[ 1 ]-0x40) + 64)*(24*3) + 1552;
        else
            offset = ((str[ 0 ]-0xa1-15)*94 + (str[ 1 ]-0xa1) + 64)*(24*3) + 1552;

        fd = open( CHNFONT_GBK24, O_RDONLY );
        if( fd <= 0 )
        {
            inPrint_Log( __LINE__, "open chnfont_gbk24 fail" );
            return PRINT_FAIL;
        }
#else
        i = 0;
        qu = str[i] - 0xa0;
        wei = str[i+1] - 0xa0;

        if( qu >= 16 )
        {
            fd = open( CHNFONT_24S, O_RDONLY );
            if( fd <= 0 )
            {
                inPrint_Log( __LINE__, "open chnfont_24s fail" );
                return PRINT_FAIL;
            }
            offset = ( 94 * ( qu - 1 - 15 ) + wei - 1 ) * 72;
        }
        else
        {
            fd = open( CHNFONT_24T, O_RDONLY );
            if( fd <= 0 )
            {
                inPrint_Log( __LINE__, "open chnfont_24t fail" );
                return PRINT_FAIL;
            }

            offset = ( 94 * ( qu - 1 ) + wei - 1 ) * 72;
        }
#endif

        lseek( fd, offset, SEEK_SET );

        memset( buf, 0, sizeof( buf ) );
        if( read( fd, ( void * )buf, 72 ) != 72 )
        {
            inPrint_Log( __LINE__, "read 24x24 dot file 72 bytes fail" );
            close( fd );
            return PRINT_READFAIL;
        }

        close( fd );

#if 0
        memset( buf1, 0, sizeof( buf1 ) );
        inPrint_ConvertH2V( buf, buf1 );
#else
        memset(buf1, 0, sizeof(buf1));
        inPrint_Turn_24X24( buf, buf1);

        memset(buf, 0, sizeof(buf));
        inPrint_ConvertH2V( buf1, buf);

        memcpy( buf1, buf, 72 );
#endif
    }
    else
    {
        bIsGbkFont16 = isGbkFont16();
        if (bIsGbkFont16)
        {
            strcpy(fontName, GBKFONT_16);
            qu = str[ 0 ] - 0x81;
            wei = str[ 1 ] - 0x40;
        }
        else
        {
            strcpy(fontName, CHNFONT);
            qu = str[ 0 ] - 0xA1;
            wei = str[ 1 ] - 0xA1;
        }
        if ( qu < 0 || wei < 0 )
            return 0;

        if( bIsGbkFont16 )
            offset = ( qu * 191 + wei + 64 ) * 32L + 16;
        else
            offset = ( qu * 94 + wei + 64 ) * 32L + 16;

        fd = open( fontName, O_RDONLY );
        if( fd < 0 )
            return PRINT_FAIL;

        lseek( fd, offset, SEEK_SET );

        memset( buf, 0, sizeof( buf ) );
        if( read( fd, (char *)buf, 32 ) != 32 )
        {
            close( fd );
            return PRINT_READFAIL;
        }

        close( fd );

        memcpy( buf1, buf + 8, 8);
        memcpy( buf + 8, buf + 16, 8);
        memcpy( buf + 16, buf1, 8);
        memset( buf1, 0, sizeof(buf1));

        for (k = 0; k < 32; k += 8)
        {
            for (i = 0; i < 8; i++)
            {
                for (j = 0; j < 8; j++)
                    buf1[ i + k ] |= ( (buf[ j + k ] >> i) & 0x01 ) << (7 - j);
            }
        }
    }

    Ch_id = totalhz;
    if( inPrint_bNewSprocketMode == 0 )
    {
        if( inPrint_GetFontSize() == PRINT_FONT24 )
            inPrint_Download_Hz_font(24 + (Ch_id >> 7) * 9, Ch_id & 0x7f, buf1, 72 );
        else
            inPrint_Download_Hz_font(3 + (Ch_id >> 7) * 4, Ch_id & 0x7f, buf1, 32 );
    }
    else
    {
        if( inPrint_CheckNotshzCasheString( (char *)str ) == 1 )
        {
            inPrint_Compress_16x16_h_only( buf, buf1);

            inPrint_Download_Hz_font(3 + (Ch_id >> 7) * 4, Ch_id & 0x7f, buf, 32 );

            inPrint_Download_Hz_font(43 + (Ch_id >> 7) * 4, Ch_id & 0x7f, buf, 32 );
        }
        else
        {
            inPrint_Compress_16x16_h_only( buf, buf1 );
            inPrint_Download_Hz_font(3 + (Ch_id >> 7) * 4, Ch_id & 0x7f, buf, 32 );

            inPrint_Compress_16x16_hv(buf, buf1 );
            inPrint_Download_Hz_font(43 + (Ch_id >> 7) * 4, Ch_id & 0x7f, buf, 32 );
        }
    }

    if( inPrint_GetFontSize() == PRINT_FONT24 )
    {
        memcpy( inPrint_cHZCasheString_24x24 + strlen( inPrint_cHZCasheString_24x24 ), str, 2 );
        fd = open( PRNCACHE_24X24, O_RDWR );
    }
    else
    {
        memcpy( inPrint_cHZCasheString_16x16 + strlen( inPrint_cHZCasheString_16x16 ), str, 2 );
        fd = open( PRNCACHE_16X16, O_RDWR );
    }

    if( fd < 0 )
        return 0;

    lseek( fd, 0, SEEK_END );
    write( fd, (char *)str, 2 );
    close( fd );

    return 0;
}

static int inPrint_GetGB2312Offset(unsigned char h, unsigned char l)
{
    return((h-0xa1-15)*94 + (l-0xa1) + 1410); /* 1410�Ǻ��ֵ�ƫ���� */
}

static int inPrint_GetGBKOffset(unsigned char h, unsigned char l)
{
    return((h-0x81)*191 + (l-0x40));
}

static int inPrint_CheckMechFailure( int iResetFlag )
{
    int iTry = 0;
    int iFlag = iResetFlag;
    int iRet;
    char cBuffer[ 3 ];

    if( MmiUtil_GetPrinterType() != SPROCKET_PRINTER )
        return PRINT_OK;

    while( iTry++ < 5 )
    {
        if( iFlag == 1 )
        {
            reset_port_error( inPrint_iPrinterHandle );

            inPrint_Log( __LINE__, "machine mechanism fail,reset_port_error and please wait 500ms" );
            SVC_WAIT( 500 );
        }

        iRet = write( inPrint_iPrinterHandle, "\x1B\x64", 2 );
        if( iRet < 2 )
            break;

        memset( cBuffer, 0, sizeof( cBuffer ) );
        while( (iRet = read(inPrint_iPrinterHandle, cBuffer, 1)) == 0 )
            SVC_WAIT( 10 );

        if( iRet < 0 )
            break;

        inPrint_Log( __LINE__, "check mech failure,read buffer[0]=%02x", cBuffer[ 0 ] );

        if( !(cBuffer[ 0 ] & 0x40) )
            return 1;

        iFlag = 1;
    }

    return 0;
}
static int inPrint_GetStatus( void )
{
    int iRet;
    char cBuffer[ 3 ];

    if( inPrint_iPrinterHandle < 0 )
    {
        inPrint_Log( __LINE__, "inPrint_CheckReadlyStatus, no handle" );
        return PRINT_NOHANDLE;
    }

    //<ESC>d
    iRet = write(inPrint_iPrinterHandle, "\x1B\x64", 2 );
    if( iRet < 2 )
    {
        //*piRetPrinterStatus = PRINT_WRITEFAIL;
        inPrint_Log( __LINE__, "inPrint_CheckReadlyStatus, wirte <ESC>d fail, iRet=%d", iRet );
        return PRINT_WRITEFAIL;
    }

    memset( cBuffer, 0, sizeof( cBuffer ) );
    while( (iRet = read(inPrint_iPrinterHandle, cBuffer, 1)) == 0 )
        SVC_WAIT( 10 );

    if( iRet < 0 )
    {
        //*piRetPrinterStatus = PRINT_READFAIL;
        inPrint_Log( __LINE__, "inPrint_CheckReadlyStatus, read status fail, iRet=%d", iRet );
        return PRINT_READFAIL;
    }

    /*cBuffer[0]=
    int prnId=80;
    int ctsReq=0;
    int paperLow=0x00;
    int paperOut=0x02;
    int mechFail=0x40;
    int ramErr=0;
    int firmwareCorrupt=0x04;
    */

    inPrint_Log( __LINE__, "in printing, printer status=[%X]", cBuffer[0] );

    if( cBuffer[ 0 ] & 0x40 )
    {
        //*piRetPrinterStatus = PRINT_MERCHFAIL;
        inPrint_CheckMechFailure( 1 );
        return PRINT_MERCHFAIL;
    }

    if( cBuffer[ 0 ] & 0x02 )
    {
        inPrint_Log( __LINE__, "paper out" );
        return PRINT_NOPAPER;
    }

    if( cBuffer[ 0 ] & 0x01 )
    {
        inPrint_Log( __LINE__, "printer busy" );
    }

    return PRINT_OK;
}

static int inPrint_CheckReadlyStatus( int iWaitFlag, int *piRetPrinterStatus )
{
    int iRet;
    char cBuffer[ 3 ];

    if( inPrint_iPrinterHandle < 0 )
    {
        *piRetPrinterStatus = PRINT_NOHANDLE;
        inPrint_Log( __LINE__, "inPrint_CheckReadlyStatus, no handle" );
        return 0;
    }

    //<ESC>d
    iRet = write(inPrint_iPrinterHandle, "\x1B\x64", 2 );
    if( iRet < 2 )
    {
        //*piRetPrinterStatus = PRINT_WRITEFAIL;
        inPrint_Log( __LINE__, "inPrint_CheckReadlyStatus, wirte <ESC>d fail, iRet=%d", iRet );
        return 0;
    }

    memset( cBuffer, 0, sizeof( cBuffer ) );
    while( (iRet = read(inPrint_iPrinterHandle, cBuffer, 1)) == 0 )
        SVC_WAIT( 10 );

    if( iRet < 0 )
    {
        //*piRetPrinterStatus = PRINT_READFAIL;
        inPrint_Log( __LINE__, "inPrint_CheckReadlyStatus, read status fail, iRet=%d", iRet );
        return 0;
    }

    /*cBuffer[0]=
    int prnId=80;
    int ctsReq=0;
    int paperLow=0x00;
    int paperOut=0x02;
    int mechFail=0x40;
    int ramErr=0;
    int firmwareCorrupt=0x04;
    */

    inPrint_Log( __LINE__, "in printing, printer status=[%X]", cBuffer[0] );

    if( cBuffer[ 0 ] & 0x40 )
    {
        //*piRetPrinterStatus = PRINT_MERCHFAIL;
        inPrint_CheckMechFailure( 1 );
        //return 0;
    }

    if( cBuffer[ 0 ] & 0x02 )
    {
        inPrint_CheckMechFailure( iWaitFlag );

        inPrint_Log( __LINE__, "paper out" );

        *piRetPrinterStatus = PRINT_NOPAPER;

        if( inPrint_GetUIScheme() != 1 )
        {
            MmiUtil_ClearLines(LINE3, LINE4);
            MmiUtil_DisplayCenter("��ӡ��ȱֽ", LINE3, FALSE);
            MmiUtil_DisplayCenter("��װֽ�󰴼�����", LINE4, FALSE);
            get_char();
            MmiUtil_UserClr(LINE3);
            MmiUtil_DisplayCenter("��ӡ��", LINE3, FALSE);
        }
        //return 0;
    }

    if( cBuffer[ 0 ] & 0x01 )
        return 1;

    return 0;
}

static int inPrint_CheckNoPaper( int iPrinterStatus )
{
    if( (inPrint_GetUIScheme() == 1) && (iPrinterStatus == PRINT_NOPAPER) )
        return PRINT_NOPAPER;

    return PRINT_OK;
}

static int inPrint_CheckStatus( int iStatus )
{
    int i;
    int iPrinterStatus = PRINT_OK;

    i = 0;
    while( inPrint_CheckReadlyStatus( iStatus, &iPrinterStatus ) )
    {
        if( inPrint_CheckNoPaper( iPrinterStatus ) == PRINT_NOPAPER )
            return PRINT_NOPAPER;

        if( iStatus != 1 )
            break;

        SVC_WAIT( 100 );

        if( i++ > 50 )
            break;
    }

    return iPrinterStatus;
}


//---------------------------------------------------

// ����������ӡ���ܵ��´�ӡ����, �����ж�����ȡ�ֿ�����ߴ�ӡʧ��,��ͣ50ms��Ȼ���ٳ���һ��
// @laikey_20130109 -->

static int inPrint_p3700_print( short h_comm_port, unsigned char *pPrintString )
{
#if 1
    int iRet;

    iRet = p3700_print( h_comm_port, pPrintString );
    if ( iRet < 1 )
    {
        SVC_WAIT( 50 );

        iRet = p3700_print( h_comm_port, pPrintString );
    }

    return iRet;
#else
    inPrint_WriteStr( h_comm_port, pPrintString );
    return 0;
#endif
}


static short inPrint_p3700_select_font( short h_comm_port, short font_size, short font_table)
{
    int iRet;

    iRet = p3700_select_font( h_comm_port, font_size, font_table);
    if ( iRet < 1 )
    {
        SVC_WAIT( 50 );

        iRet = p3700_select_font( h_comm_port, font_size, font_table);
    }

    return iRet;
}


static short inPrint_p3700_dnld_graphic_file(short h_comm_port, short h_graphic_file )
{
    int iRet;

    iRet = p3700_dnld_graphic_file( h_comm_port, h_graphic_file );
    if ( iRet < 1 )
    {
        // deleted it for print delay, @laikey
        //SVC_WAIT( 50 );

        //iRet = p3700_dnld_graphic_file( h_comm_port, h_graphic_file );
    }

    return iRet;
}

static int inPrint_OpenDevice( void )
{
    int iOwnner = 0;
    int iHandle = 0;
    int tryTime = 0;

    do
    {
        iHandle = get_owner( DEV_COM4, &iOwnner);

        if ( iHandle < 0 )
            return iHandle;

        if (iOwnner != 0 && iOwnner != get_task_id())
        {
            return FALSE;
        }

        if (iOwnner == get_task_id()) //the device is used by myself
        {
            return TRUE;
        }

        iHandle = open( DEV_COM4, 0);
    }
    while (iOwnner != get_task_id() && tryTime++ < 3);

    return TRUE;
}


static int inPrint_CloseDev( void )
{
    int iOwnner = 0;
    int iHandle = 0;
    int tryTime = 0;

    do
    {
        iHandle = get_owner( DEV_COM4, &iOwnner);
        if ( iHandle < 0 )
        {
            return iHandle;
        }

        if ( iOwnner != 0 && iOwnner != get_task_id())
        {
            return FALSE ;
        }

        if ( iOwnner == 0 )
            break;

        close( iHandle );
    }
    while ( iOwnner != 0 && tryTime++ < 3);

    return TRUE;
}


static int inPrint_CheckPrintAutoOpenStatus( void )
{
    int iRet = 1;
    int iCurrGID = get_group( );
    char cBuffer[ 6 ];

    set_group( 15 );

    memset( cBuffer, 0, sizeof( cBuffer ) );
    get_env( "*AOPRTDEV", cBuffer, sizeof( cBuffer) );

    set_group( iCurrGID );

    if ( strlen( cBuffer ) > 0 )
        iRet = atoi( cBuffer );

    return iRet;
}

// <-- @laikey_20130109


// Added by @laikey_20130321 for Vx805 printer -->

static void inPrint_WaitPrinter( int inHandle )
{
    char cTmpBuf[ 5 ];
    int  iRet;
    unsigned long lTrytimer;

    lTrytimer = set_itimeout( -1, 10, TM_SECONDS );

    do
    {
        memset( cTmpBuf, 0x00, sizeof( cTmpBuf ) );

        iRet = get_port_status( inHandle, cTmpBuf );

        if ((iRet == 0) && (cTmpBuf[0] == 0) && (cTmpBuf[1] == 0) &&(cTmpBuf[2] == 0x1E))
            break;

        SVC_WAIT( 20 );

    }
    while ( (iRet >= 0) && (CHK_TIMEOUT( -1, lTrytimer)) );
}


static int inPrint_SafeWrite(int iHandle, char *pWriteData, int iDataLength )
{
    int bytesOut;
    int iLen;
    unsigned long lTrytimer;
    //char cStsBuf[ 5 ];

    lTrytimer = set_itimeout( -1, 10, TM_SECONDS );

#if 1
    iLen = 0;
    while( CHK_TIMEOUT( -1, lTrytimer ) )
    {
        errno = 0;
        bytesOut = write( iHandle, pWriteData + iLen, iDataLength - iLen );

        //while( get_port_status( iHandle, cStsBuf ) != 0);   // Flush all data in COM4
        //SVC_WAIT( 2 );

        if( bytesOut >= iDataLength || iLen >= iDataLength )
            break;

        inPrint_Log( __LINE__, "safe write, iHandle=%d, length=%d,%d,%d, errno=%d,str=%s", iHandle, iDataLength, bytesOut, iLen, errno, pWriteData );

        if( bytesOut <= 0 )
        {
            if( errno == ENOSPC || errno == ENXIO)
            {
                errno = 0;
                SVC_WAIT( 20 );
            }
        }
        else
        {
            iLen += bytesOut;
            SVC_WAIT( 10 );
        }
    }

    return iLen;
#else
    do
    {
        errno = 0;

        bytesOut = write( iHandle, pWriteData, iDataLength );

        //while( get_port_status( iHandle, cStsBuf ) != 0);   // Flush all data in COM4
        //SVC_WAIT( 2 );

        if ( bytesOut != iDataLength )
        {
            if( errno == ENOSPC || errno == ENXIO)
            {
                errno = 0;
                SVC_WAIT( 20 );
            }
            else if( bytesOut > 0 )
                break;
        }
        else
            break;
    }
    while ( (bytesOut != iDataLength) && (CHK_TIMEOUT( -1, lTrytimer)) );

    return bytesOut;
#endif


}

/* --------------------------------------------------------------------------
* FUNCTION NAME: inPrint_WriteStr.
* DESCRIPTION:   ��ӡ������Ӣ���ִ��ĺ���
* PARAMETERS:
*     str (in) -- Ҫ��ӡ���ַ���
*     attrib (in) -- ��ӡ����
* RETURN:
*   PRINT_OK/PRINT_NOHANDLE/PRINT_NOPAPER/PRINT_FAIL
* NOTES:
* ------------------------------------------------------------------------ */
static void inPrint_WriteStr( int hdl, unsigned char *pcString )
{
    inPrint_SafeWrite( hdl, (char *)pcString, strlen( (char *)pcString ) );
}


static int inPrint_Write_Vx805(int iHandle, char *pWriteData, int iDataLength )
{
    int bytesOut;
    unsigned long lTrytimer;

    lTrytimer = set_itimeout( -1, 10, TM_SECONDS );

    do
    {
        errno = 0;

        bytesOut = write( iHandle, pWriteData, iDataLength );

        if ( bytesOut != iDataLength )
        {
            if ( errno == ENOSPC )
            {
                errno = 0;
                SVC_WAIT( 20 );
            }
            else
                break;
        }
        else
            break;
    }
    while ( (bytesOut != iDataLength) && (CHK_TIMEOUT( -1, lTrytimer)) );

    return bytesOut;
}


static void inPrint_Feed_Vx805( int flag, int length )
{
    char cBuffer[ 20 ];
    int  iRet;

    if ( (flag != FORWARD_PAPER) && (flag != REVERSE_PAPER) )
        return;

    inPrint_WaitPrinter( inPrint_iPrinterHandle );
    cBuffer[ 0 ] = 0x18;
    inPrint_Write_Vx805( inPrint_iPrinterHandle, cBuffer, 1 );

    memset(cBuffer, 0, sizeof(cBuffer));
    iRet = sprintf(cBuffer, "\x1B""b%d,%d;", length, flag);

    inPrint_Write_Vx805( inPrint_iPrinterHandle, cBuffer, iRet);
    return;
}



static int inPrint_Print_Str_12_Vx805(char *pPrintString, unsigned char attrib)
{
    int i, j;
    int iRet;
    int iLength;
    short fp, fp1;
    char cTmpBuf[ 4 ];
    char cPrintMode[ 4 ]= {0};
    unsigned char cBuffer[ 32 ], cBuffer1Line[ 32 * 12 ];	// 12��, ÿ��15���֣�ÿ���ֵ�ÿ��
    BOOL bIsGbkFont12;

    iLength = strlen(pPrintString);
    if (iLength == 0)
        return PRINT_OK;

    bIsGbkFont12 = isGbkFont12();

    if (bIsGbkFont12)
    {
        if ((fp = open(GBKFONT_12,O_RDONLY)) < 0)
            return PRINT_NOHANDLE;
    }
    else
    {
        if ((fp = open(CHNFONT_12,O_RDONLY)) < 0)
            return PRINT_NOHANDLE;
    }

    if ((fp1 = open(ENGFONT_5x8,O_RDONLY)) < 0)
        return PRINT_NOHANDLE;

    //**************************************************************************************
    // Start the graphics mode of printing the data
    //ESC g is the command for going to the graphicsa mode
    //**************************************************************************************
    cPrintMode[0]=0x1b;
    cPrintMode[1]=0x67;

    inPrint_WaitPrinter(inPrint_iPrinterHandle);

    iRet = inPrint_Write_Vx805(inPrint_iPrinterHandle, cPrintMode,2);
    if (iRet != 2)
    {
        close(fp);
        close(fp1);
        return WRITE_FAIL;
    }

    //**************************************************************************************
    //Now thw bitmap will have the data in the reverse hence the last data of the bitmap
    //will be the first data hnece get the data in reverse
    //the value of the buffer is memset to 0x0c 1100 0000 which will not print data
    //Container should have 1 1			0 0 0 0 0 0
    //						| |			| | | | | |
    //					Non printing	Printing data
    //**************************************************************************************

    //iLength = strlen(pPrintString);
    if (iLength > 30)	// ֻ��ӡһ��
        iLength = 30;

    memset( cBuffer1Line, 0, sizeof( cBuffer1Line ) );

    for (i = 0; i < 12; i ++)
    {
        memset(cBuffer, 0xC0, sizeof( cBuffer ) );

        for (j = 0; j < iLength; j ++ )
        {
            if (bIsGbkFont12 && (unsigned char)pPrintString[j] >= 0x81 && (unsigned char)pPrintString[j+1] >= 0x40)
            {
                lseek(fp, inPrint_GetGBKOffset(pPrintString[j], pPrintString[j+1])*24 + 128*12 + 16 + (i * 2), SEEK_SET);

                read(fp, cTmpBuf, 2);

                /* 12x12����ÿ����2���ֽ���ɣ�ʵ��ֻռ����12��BIT */
                cBuffer[j] |= cTmpBuf[0] >> 2;
                cBuffer[j + 1] |= (cTmpBuf[0] << 6) >> 2;
                cBuffer[j + 1] |= cTmpBuf[1] >> 4;
                j ++;
            }
            else if ((unsigned char)pPrintString[j] >= 0xA1 && (unsigned char)pPrintString[j+1] >= 0xA0)
            {
                lseek(fp, inPrint_GetGB2312Offset(pPrintString[j], pPrintString[j+1])*24 + (i * 2), SEEK_SET);

                read(fp, cTmpBuf, 2);

                /* 12x12����ÿ����2���ֽ���ɣ�ʵ��ֻռ����12��BIT */
                cBuffer[j] |= cTmpBuf[0] >> 2;
                cBuffer[j + 1] |= (cTmpBuf[0] << 6) >> 2;
                cBuffer[j + 1] |= cTmpBuf[1] >> 4;
                j ++;
            }
            else if (i > 3) //ʹ��5x8��Ӣ�ģ��¶���
            {
                lseek(fp1, (8 + pPrintString[j] * 9 + 1 + i - 4), SEEK_SET);
                read(fp1, cTmpBuf, 1);

                // 5x8����ÿ��1���ֽڣ�ʵ��ռ�ú�5��BIT
                cBuffer[j] |= cTmpBuf[0];
            }
        }
        cBuffer[j] = 0x21;	// ����

        if (j == 30)
            memcpy(cBuffer1Line + i * j, cBuffer, j);
        else
            memcpy(cBuffer1Line + i * (j + 1), cBuffer, j + 1);
    }

    //Avoid calling strlen two times
    iLength = strlen((char *)cBuffer1Line);
    cBuffer1Line[iLength++] = 0x21;	// �о�һ������

    inPrint_Write_Vx805( inPrint_iPrinterHandle,(char *)cBuffer1Line, iLength );

    //***********************************************************************************************
    // Exit from the graphics mode passing the 0x18 CAN command ie the 0001 0100 the fifth bit should be set to 1
    //***********************************************************************************************
    cPrintMode[0]=0x18;

    inPrint_WaitPrinter(inPrint_iPrinterHandle);

    inPrint_Write_Vx805(inPrint_iPrinterHandle, cPrintMode,1);

    close( fp );
    close( fp1 );
    return PRINT_OK;

}

// <-- @laikey_20130321


/*
static void inPrint_Compress_16x16_v_only( unsigned char* buf_zip, unsigned char* buf_pft)
{
    int i, k;
    char bmask[] = {0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80};
    char tmpbuf[ 32 ];

    memset( tmpbuf, 0, sizeof( tmpbuf ) );

    // Shrink vertical adjacent dots
    for(k = 0; k < 32; k += 2)
    {
        tmpbuf[k] = 0;
        tmpbuf[k+1] = 0;

        for(i = 7; i >= 0; i--)
        {
            tmpbuf[k+1] += (buf_pft[k] | buf_pft[k+1]) & bmask[i];
        }
    }

    memcpy( buf_zip, tmpbuf, 32 );
}*/

//�Ե����������������ѹ��
static void inPrint_Compress_16x16_h_only( unsigned char* buf_zip, unsigned char* buf_pft)
{
    int i, k;
    unsigned char tmp, bmask[] = {0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80};
    unsigned char tmpbuf[ 32 ];

    memset( tmpbuf, 0, sizeof( tmpbuf ) );

    // Shrink horizontal adjacent dots
    for(k = 0; k < 8; k++)
    {
        // Process from top left
        for(tmp = 0, i = 7; i >= 0; i--)
        {
            if(buf_pft[k] & bmask[i])
                tmp += bmask[i--];
        }

        tmpbuf[k] = tmp;

        // Process top right
        for(tmp = 0, i = (tmpbuf[k] & 0x01) ? 6 : 7; i >= 0; i--)
            if(buf_pft[k+8] & bmask[i])
                tmp += bmask[i--];

        tmpbuf[k+8] = tmp;

        // Process  bottom left
        for(tmp = 0, i = 7; i >= 0; i--)
            if(buf_pft[k+16] & bmask[i])
                tmp += bmask[i--];

        tmpbuf[k+16] = tmp;

        // Process bottom right
        for(tmp = 0, i = (tmpbuf[k+16] & 0x01) ? 6 : 7; i >= 0; i--)
            if(buf_pft[k+24] & bmask[i])
                tmp += bmask[i--];

        tmpbuf[k+24] = tmp;
    }

    memcpy( buf_zip, tmpbuf, 32 );
}


//�Ե��������������������ѹ��
static void inPrint_Compress_16x16_hv( unsigned char* buf_zip, unsigned char* buf_pft)
{
    int i, k;
    unsigned char bmask[] = {0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80};
    unsigned char tmpbuf[ 32 ];

    memset( tmpbuf, 0, sizeof( tmpbuf ) );

    // Shrink vertical adjacent dots
    for(k = 0; k < 32; k += 2)
    {
        tmpbuf[k] = 0;
        tmpbuf[k+1] = 0;

        for(i = 7; i >= 0; i--)
        {
            tmpbuf[k+1] += (buf_pft[k] | buf_pft[k+1]) & bmask[i];
        }
    }

    // Shrink horizontal adjacent dots
    inPrint_Compress_16x16_h_only(buf_zip, tmpbuf);
}


// ����Ӣ�ĵ����ֿ�(������Ƶ�ѹ���ֿ�), ������ʽ��ӡ���ӿ��ӡ�ٶ�
static int inPrint_Download_EnglishFont_8x14(void)
{
    int i, j, retry, code, cnt;
    int fp;
    unsigned char buf[2048], scmd[128];
    long file_size = 0;

    // Added by laikey_20151209 -->
    if( inPrint_GetStatus() != PRINT_OK )
    {
        inPrint_Log( __LINE__, "english font download but printer is not ready" );
        return -5;
    }

    if( inPrint_iDownloadEnglishFontFlag == 1 )
    {
        inPrint_Log( __LINE__, "english font has already been download" );
        return 0;
    }
    // <--
    if((fp = open( ENGFONT_8x14, O_RDONLY)) <= 0)
    {
        MmiUtil_Warning( "Ӣ��8X14�ļ�δ�ҵ�" );
        return -1;
    }

    file_size = lseek(fp, 0L, SEEK_END);

    if(file_size > sizeof(buf))
        file_size = sizeof(buf);

    lseek(fp, 0L, SEEK_SET);
    read(fp, (char *)buf, file_size);

    // Check the font file is with correct format
    if(strcmp((char *)buf, "I\x1b\x6c") != 0)
    {
        close( fp ); // Added by laikey_20151209
        return -2;
    }

    //<ESC>l31; Select 8x14 font table 1
    inPrint_WriteStr(inPrint_iPrinterHandle, (unsigned char *)"\x1bl41;");

    inPrint_Log( __LINE__, "english download fontsize=4,table id=1" );

    memset(scmd, 0, sizeof(scmd));
    scmd[0] = 0x1b;
    scmd[1] = 'm';
    scmd[17] = ';';
    i = 8;
    code = 0x21;
    cnt = 0;

    while(i < file_size  &&  code < 0x7f)
    {
        scmd[2] = buf[i++];

        for(j = 3; j < 16; j += 2)
        {
            if(buf[i] == 0x7f)
                buf[i] = 0;

            scmd[j] = buf[i++];
        }

        retry = 0;
        SVC_WAIT(5);

        while(write(inPrint_iPrinterHandle, (char *)scmd, 18) != 18 && retry < 6)
        {
            retry++;
        }

        inPrint_Log( __LINE__, "english font download char=[%c=%d]",code,code );

        i++;
        code = buf[i];
        cnt++;
    }

    close( fp ); // Added by laikey_20151209

    inPrint_Log( __LINE__, "download english font 8x14 OK!" );
    SVC_WAIT( 200 );
    // Added by laikey_20151209 -->
    inPrint_iDownloadEnglishFontFlag = 1;
    //<--
    return cnt;
}

//��ӡ����
static void inPrint_Print_Hz( char *str, unsigned char attrib )
{
    int  i, scLen, hzLen, ccode, index;
    char attribuf[ 16 ];
    char cmdTable[16];
    char scmd[2048];
    int  idTable = 0, newTab;

    memset( attribuf, 0, sizeof( attribuf ) );
    if( (attrib & DH) || (attrib & DW) || (attrib & INV) )
    {
        i = 0;

        if( attrib & INV )
            attribuf[ i++ ] = 0x12;

        if( attrib & DH )
        {
            memcpy( attribuf + i, "\x1b\x66\x30\x31\x3b", 5 );
            i += 5;
        }

        if( attrib & DW )
            attribuf[ i ++ ] = 0x1e;

        //inPrint_WriteStr( inPrint_iPrinterHandle, (unsigned char *)attribuf );
    }

    memset( scmd, 0, sizeof( scmd ) );
    hzLen = strlen(str);
    strcpy(scmd, "\x1bH");
    scLen = 2;

    for(i = 0; i < hzLen; i += 2, scLen += 2)
    {
        ccode = inPrint_SearchHZ( &str[i], &index );
        if( ccode < 0 )
        {
            inPrint_Log( __LINE__, "search_hz:%2.2s not found in cache stings", &str[ i ] );
            continue;
        }
        else
            inPrint_Log( __LINE__, "search_hz:%2.2s found in cache index:%d", &str[ i ], ccode );

        if( inPrint_bNewSprocketMode == 0 )
        {
            inPrint_Log( __LINE__, ".........................." );

            if( inPrint_GetFontSize() == PRINT_FONT24 )
                newTab = (ccode >> 7) * 9 + 24;
            else
                newTab = (ccode >> 7) * 4 + 3;
        }
        else
        {
            if( (attrib & DH) || (attrib & DW ) )
                newTab = (ccode >> 7) * 4 + 3;	// h only
            else
                newTab = (ccode >> 7) * 4 + 43;	// hv both
        }

        if( newTab != idTable )
        {
            // before switch new table, write out previous string
            if( scLen > 2)
            {
                strcat( scmd, ";" );
                inPrint_WriteStr( inPrint_iPrinterHandle, (unsigned char *)scmd );
                scmd[2] = '\0';
                scLen = 2;
            }

            idTable = newTab;
            if( inPrint_GetFontSize( ) == PRINT_FONT24 )
                sprintf(cmdTable, "\x1bl%d%d;", 5, idTable);
            else
                sprintf(cmdTable, "\x1bl%d%d;", 1, idTable);

            inPrint_WriteStr(inPrint_iPrinterHandle, (unsigned char *)cmdTable);

            inPrint_WriteStr( inPrint_iPrinterHandle, (unsigned char *)attribuf );
        }

        sprintf(scmd + scLen, "%02X", (ccode & 0x7f));
    }

    strcat (scmd, ";");
    inPrint_WriteStr( inPrint_iPrinterHandle, (unsigned char *)scmd );
    return;
}

// ��ӡӢ��
static void inPrint_Print_English( unsigned char attrib, unsigned char *txtenglish )
{
    int i = 0;
    unsigned char attribuf[ 16 ];

    if( inPrint_bNewSprocketMode == 0 )
    {
        p3700_select_font( inPrint_iPrinterHandle, 0x04, 0 );

        if( (attrib & DH) || (attrib & DW) || (attrib & INV) )
        {
            i = 0;
            memset( attribuf, 0, sizeof( attribuf ) );

            if( attrib & INV )
                attribuf[ i++ ] = 0x12;

            if( attrib & DH )
            {
                memcpy( attribuf + i, "\x1b\x66\x30\x31\x3b", 5 );
                i += 5;
            }

            if( attrib & DW )
                attribuf[ i ++ ] = 0x1e;

            inPrint_WriteStr( inPrint_iPrinterHandle, attribuf );
        }

        inPrint_WriteStr( inPrint_iPrinterHandle, txtenglish );
        return;
    }

    // for spt new printer mode
    if( (attrib & DH) || (attrib & DW) || (attrib & INV) )
    {
        if( stprinter_parm.trailer.bytes.b[ 0 ] == 1 )	// 360 dot mode
            inPrint_WriteStr(inPrint_iPrinterHandle, (unsigned char *)"\x1bl40;");	// tall alpha/numeric
        else
            inPrint_WriteStr(inPrint_iPrinterHandle, (unsigned char *)"\x1bl20;");	// short alpha/numeric

        i = 0;
        memset( attribuf, 0, sizeof( attribuf ) );

        if( attrib & INV )
            attribuf[ i++ ] = 0x12;	// INVERSE;

        if( attrib & DH )
        {
            memcpy( attribuf + i, "\x1b\x66\x30\x31\x3b", 5 );	// DBL_HEIGHT;
            i += 5;
        }

        if( attrib & DW )
            attribuf[ i ++ ] = 0x1e;	// DBL_WIDTH;

        inPrint_WriteStr( inPrint_iPrinterHandle, attribuf );
    }
    else
    {
        // Added by laikey_20151209 -->
        if( inPrint_iDownloadEnglishFontFlag != 1 )
            inPrint_Download_EnglishFont_8x14();
        //<--
        if( stprinter_parm.trailer.bytes.b[0] == 1 )	// 360 dot mode
            inPrint_WriteStr( inPrint_iPrinterHandle, (unsigned char *)"\x1bl41;");
        else
            inPrint_WriteStr( inPrint_iPrinterHandle, (unsigned char *)"\x1bl20;");
    }

    inPrint_WriteStr( inPrint_iPrinterHandle, txtenglish );

    return;
}


static int inPrint_GetFontSize( void )
{
    return inPrint_iFontSize;
}

static int inPrint_GetUIScheme( void )
{
    return inPrint_iUIScheme;
}

// ��ӡbmpͼƬ
static int inPrint_Bitmap(int handle, int offset, char *filename)
{
    short bmp_file;
    short retVal;
    unsigned char fileheader[14];
    unsigned char infoheader[48];
    unsigned short BitsPerPixel = 0;
    short mod = 0;
    unsigned int height, width, widthActual = 0;
    int padding = 0;
    int m_size = 0;
    unsigned char  *bitmapData;
    unsigned char  *bitmapConv;
    unsigned char  *LineData;
    int i, j = 0;
    short offsetwidth = 0;
    unsigned short ReqSize;
    char Printmode[4] = {0};
    char ioctl_status[4];
    short heightIndex = 0;
    int bitcount, bitset;
    unsigned char DataBuf[1] = {0};
    unsigned char TransBuf[1] = {0};
    unsigned int counter[8] = {1, 2, 4, 8, 16, 32, 64, 128};
    char *filextn = ".bmp";
    char *position;
    short bits = 0;
    static int count = 0;

    //**********************************************************************************
    //  check whether the file is bmp
    //**********************************************************************************

    position = strstr(filename, filextn);
    if(position == NULL)
        return PRINT_OPENFAIL;

    //**********************************************************************************
    //  offset if it is less than 0 will be treated as 0 and more than 60 will be treated as 60
    //**********************************************************************************

    if(offset <= 0)
        offset = 0;
    else if(offset > 60)
        offset = 60;

    //**********************************************************************************
    //		Open the bmp file passed as the second paramter and read the header
    //**********************************************************************************
    bmp_file = open(filename, O_RDONLY);
    if(bmp_file < 0)
        return PRINT_OPENFAIL;
    else //Read the header of the bmp file
    {
        retVal = read(bmp_file, (char*)fileheader, sizeof(fileheader)); //file header
        if(retVal < 0)
        {
            close(bmp_file);
            return PRINT_READFAIL;
        }

        retVal = read(bmp_file, (char*)infoheader, sizeof(infoheader)); //informaton header
        if(retVal < 0)
        {
            close(bmp_file);
            return PRINT_READFAIL;
        }
    }

    //Read the 2 bytes of the bits per pixel data
    BitsPerPixel = infoheader[15] << 8 | infoheader[14] << 0;
    if(BitsPerPixel != 1)
    {
        close(bmp_file);
        return PRINT_FAIL;
    }

    // width is 4 bytes
    width = infoheader[7] << 24 | infoheader[6] << 16 | infoheader[5] << 8 | infoheader[4] << 0;
    // width is 4 bytes
    height = infoheader[11] << 24 | infoheader[10] << 16 | infoheader[9] << 8 | infoheader[8] << 0;

    if((width || height) <= 0)
    {
        close(bmp_file);
        return PRINT_FAIL;
    }

    if((width % 8) > 0)
    {
        mod = width % 8;
        widthActual = (width / 8) + 1;
    }
    else
    {
        widthActual = (width / 8);
        mod = 7;
    }

    padding = 4 - (widthActual % 4);
    if(padding == 4)
        padding = 0;

    m_size = height * widthActual;
    bitmapData = (unsigned char*)malloc(m_size);
    if(bitmapData == NULL)
    {
        close(bmp_file);
        return PRINT_FAIL;
    }

    memset(bitmapData, 0, m_size);
    ReqSize = ((widthActual * 8) + (offset * 6)) / 6 * height;
    bitmapConv = (unsigned char*)malloc(ReqSize + height);
    if(bitmapConv == NULL)
    {
        close(bmp_file);
        return PRINT_FAIL;
    }

    memset(bitmapConv, 0xC0, ReqSize);
    LineData = (unsigned char*)malloc(widthActual);
    if(LineData == NULL)
    {
        close(bmp_file);
        return PRINT_FAIL;
    }

    for(i = 0; i < height; ++i)
    {
        memset(LineData, 0, widthActual);
        //Reac the complete width required
        retVal = read(bmp_file, (char*)LineData, widthActual);

        //get each byte to the required pixel
        for(j = 0; j < widthActual; ++j)
            bitmapData[(i * widthActual) + j] = ~LineData[j];

        //omit the unrequired data at the the end
        retVal = lseek(bmp_file, padding, SEEK_CUR);
    }

    offsetwidth = (384 - ((offset * 6) + 12));
    if((offsetwidth % 8) > 0)
        width = (offsetwidth / 8) + 1;
    else
        width = (offsetwidth / 8);

    // if the width is less than widthActual then widthActual is taken as the actual value
    if(widthActual <= width)
        width = widthActual;
    else //the pixels of the lasr column has to be calculated to no of bits the last column has to print
        mod = offsetwidth % 8;

    memset(Printmode, 0, 4);
    memset(ioctl_status, 0, 4);
    Printmode[0] = 0x1b;
    Printmode[1] = 0x67;

    while(get_port_status(handle, ioctl_status) != 0)
    {
        SVC_WAIT(2);
    }

    retVal = write(handle, Printmode, 2);
    if(retVal < 0)
    {
        close(bmp_file);
        return PRINT_WRITEFAIL;
    }

    count = 0;
    for(i = height - 1; i >= 0; --i)
    {
        bitset = 5; // only 6 bits of data has to be read in the 8 bits and rest will go into another byte
        count = count + offset; // offset the value with buffer of the offset for each row

        for(j = 0; j < width; ++j)
        {
            if( j == (width - 1) )
                bits = 7 - (mod - 1);
            else
                bits = 0;

            DataBuf[0] = bitmapData[(i * widthActual) + j];
            for(bitcount = 7; bitcount >= bits; bitcount--)
            {
                TransBuf[0] = 0;
                TransBuf[0] = DataBuf[0] & counter[bitcount]; // Get the bit data
                TransBuf[0] = TransBuf[0] >> bitcount; // right shift to the 0th position
                TransBuf[0] = TransBuf[0] << bitset; //left shift to the required bit position
                bitmapConv[count] |= TransBuf[0]; // Or the value of the bit
                bitset--; //decrese the bit position

                if(bitset < 0) // if bit are filled then move to the other container
                {
                    bitset = 5;
                    count++;
                }
            }
        }

        ++heightIndex; // go the next row
        count++; //increase the count
        bitmapConv[count++] = 0x21; //new line

        // Once the count of the row is 50 then send the data to the printer
        if(count > 3000)
        {
            do
            {
                retVal = write(handle, (char *)bitmapConv, count); // write
            }
            while((retVal < 0) && (errno == ENOSPC || errno == ENXIO));

            count = 0; // reset the counter and the buffer
            memset(bitmapConv, 0xC0, ReqSize);
        }
    } // end of for loop

    // Print the remaining data
    do
    {
        retVal = write(handle, (char *)bitmapConv, count);
    }
    while((retVal < 0) && (errno == ENOSPC || errno == ENXIO));

    memset(Printmode, 0, 4);
    Printmode[0] = 0x18;

    while(get_port_status(handle, ioctl_status) != 0)
    {
        SVC_WAIT(0);
    }

    retVal = write(handle, Printmode, 1);
    if(retVal < 0)
    {
        close(bmp_file);
        return PRINT_WRITEFAIL;
    }

    //**************************************************************************************
    // Free the dynamic data buffer allocated
    //**************************************************************************************

    free(bitmapConv);
    free(bitmapData);
    free(LineData);
    bitmapConv = NULL;
    bitmapData = NULL;
    LineData = NULL;
    SVC_WAIT(100);

    close(bmp_file);
    return PRINT_OK;
}

