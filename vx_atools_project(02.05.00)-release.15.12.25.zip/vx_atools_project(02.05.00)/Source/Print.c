/****************************************************************************
* FILE NAME:   Print.c                            *
* MODULE NAME: Print                            *
* PROGRAMMER:  luqr                             *
* DESCRIPTION: ��ӡģ��                           *
* REVISION:    01.00 08/18/10                       *
****************************************************************************/

/*==========================================*
*         I N T R O D U C T I O N          *
*==========================================*/

/* void */

/*==========================================*
*             I N C L U D E S              *
*==========================================*/

#include "AppTools.h"

/*==========================================*
*        P R I V A T E  DEFINE              *
*===========================================*/
#define PRN_LINE_SIZE  42
#define DNLD_TO		3

#define TBID_FOR_12_24 59   // table id for 12X24��Ӣ���ַ���12*24��Ҫռ��6��table�����һ��table��64�����Դ�59��ʼ
#define Print_CheckPrinterStatus( status ) {if( (status == PRINT_NOHANDLE) || (status == PRINT_NOPAPER)||(status == PRINT_READFAIL) ) return status;}
#define Print_CheckPrinterStatusvoid( status ) {if( (status == PRINT_NOHANDLE) || (status == PRINT_NOPAPER)||(status == PRINT_READFAIL) ) return ;}

extern int isGbkFont12(void);
static int DownladFlag = 0;
#define PRN_MAX_FONT_NUM 1000
#define PRN_MAX_LIMI_NUM 200
unsigned char PRN_VX820DUET = 0;
/*==========================================*
*        P R I V A T E  D A T A            *
*==========================================*/
static open_block_t stprinter_parm;
static int inPrint_iSprocketDotMode;					// ��ʽ��ӡ����ӡ����ģʽ:360��180
static int inPrint_iPrinterHandle;
static int inPrint_iInitStatus;
static int inPrint_iFontSize;							// ��ӡ����: 24x24, 16x16
static int inPrint_iUIScheme;							// ����ӡ��ȱֽ��ʱ��atools���Ƿ���Ҫ��ʾȱֽ���ȴ�����
static int inPrint_iFullChineseMode;					// �Ƿ�ASCIIҲ�������ĵ�������ӡ
static int inPrint_iDownloadEnglishFontFlag;			// Ӣ�ĵ��������Ƿ��Ѿ��������
static byte inPrint_bGBK24Font;							// �Ƿ�֧��GBK24��������
static byte inPrint_bNewSprocketMode=0;					// =1:����ӡģʽ
static char inPrint_cHZCasheString_16x16[ 2048 ]= {0};	// �Ѿ����صĺ��ֻ���16x16����
static char inPrint_cHZCasheString_24x24[ 2048 ]= {0};	// �Ѿ����صĺ��ֻ���24x24����
static char inPrint_NoTshzString[ 512 ]= {0};			// ����Ҫת��ֱ�����صĺ��ֻ���
static int inPrint_is_12_24_font_ok;                    // 1: 12*24�Ѿ����ص���ӡ�������Դ�ӡ

/*=====================================================*
*   I N C L U D E  P R I V A T E  F U N C T I O N S   *
*=====================================================*/
static byte inPrint_IsChinese(char *s);
static byte inPrint_IsFullHzMode( void );
static byte inPrint_IsAsciiChar24x24( char *s );    // ��24*24�ķ�ʽ��ӡӢ���ַ�
static int inPrint_DownloadDot2Printer(int printer_h, unsigned char *str, int totalhz);
static int inPrint_DownloadHZ( unsigned char *str, unsigned char *pRetDotData );
static int inPrint_DownloadAscii( unsigned char *str, unsigned char *pRetDotData);
static int inPrint_GetPrnCacheString( void );
static void inPrint_WriteStr(int hdl, unsigned char *pcString );
static void inPrint_Compress_16x16_h_only( unsigned char* buf_zip, unsigned char* buf_pft);
static void inPrint_Compress_16x16_hv( unsigned char* buf_zip, unsigned char* buf_pft);
static void inPrint_Print_English( unsigned char attrib, unsigned char *txtenglish );
static int inPrint_Download_EnglishFont_8x14(void);
static int inPrint_CheckNotshzCasheString( char *str );
static int inPrint_GetNNotshzCacheString( void );
static int inPrint_Download2Printer(char Tab_id, char Ch_id, unsigned char *buf_pft, int buf_length );
static void inPrint_Print_Hz( char *str, unsigned char attrib );
static int inPrint_p3700_print( short h_comm_port, unsigned char *pPrintString );
static short inPrint_p3700_select_font( short h_comm_port, short font_size, short font_table);
static short inPrint_p3700_dnld_graphic_file(short h_comm_port, short h_graphic_file );
static int inPrint_OpenDevice( void );
static int inPrint_CloseDev( void );
static int inPrint_CheckPrintAutoOpenStatus( void );
static int inPrint_CheckReadlyStatus( int iWaitFlag, int *piRetPrinterStatus );
static void inPrint_Feed_Vx805( int flag, int length );
static int inPrint_Print_Str_12_Vx805(char *str, unsigned char attrib);
static int inPrint_GetGB2312Offset(unsigned char h, unsigned char l);
static int inPrint_GetGBKOffset(unsigned char h, unsigned char l);
static int inPrint_SearchHZ( char *str, int *index, char *pcRetStr, int *piRetDoubleFlag );
static int inPrint_CheckStatus( int iStatus );
static int inPrint_GetFontSize( void );
static void inPrint_Log( int iLine, char *pString, ... );
static int inPrint_GetUIScheme( void );
static int inPrint_CheckNoPaper( int iPrinterStatus );
static int inPrint_Bitmap(int handle, int offset, char *filename);
//static void inPrint_Log_test( int iLine, char *pString, ... );
static void inPrint_ConvertH2V12( unsigned char *src, unsigned char *dest );    // 12*24������
static int inPrint_ChkVx820DuetVer( void );   // ���Vx820�����Ĵ�ӡ���汾���Ƿ�֧��12*24��ӡ
static int inPrint_GetStatus( void );
static int inPrint_init( short h_comm_port, short time_out, short prnType );
static int inPrint_ACT_CheckOSVersion(void);
static int inPrint_PRN_id( short h_comm_port, short id_time_out, short prnType );
short inPrint_p3700_close(short handle);
short inPrint_select_font( short h_comm_port, short font_size, short font_table );
extern void vdWaitForPrinter(int hPrt);

int write_check_print(int h_comm_port,char * rd_buf,int len)
{
    int ret_val = 0;
    int offset = 0;
    int maxsize = 1024; // һ����(Vx820)��ӡ��д�������ֽ�����û�в��Ը���������
    inPrint_Log( __LINE__, "write_check_print \r\n" );
    vdWaitForPrinter(h_comm_port);
    if( maxsize > len )
    {
        maxsize = len;
    }
    do
    {
        ret_val = write( h_comm_port, (char *)rd_buf + offset , maxsize);
        if( ret_val > 0 )
        {
            offset += ret_val;
            if( maxsize > (len-offset) )
            {
                maxsize = (len-offset);
            }
        }
        if( offset >= len )
        {
            // ��д����
            break;
        }
        else
            SVC_WAIT(5);
    }
    while( ret_val >= 0 || ((ret_val < 0) && (errno == ENOSPC || errno == ENXIO)));

    inPrint_Log( __LINE__, "write_check_print = %d \r\n", ret_val );
    return ret_val;

}

/*=========================================*
*   P U B L I C     F U N C T I O N S     *
*=========================================*/

void Print_InitPrm( void )
{
    inPrint_iPrinterHandle = 0;
    inPrint_iInitStatus = 0;
    inPrint_bNewSprocketMode = 0;
    inPrint_iFontSize = PRINT_FONT16;
    inPrint_iSprocketDotMode = MODE_180_DOTS;
    inPrint_iUIScheme = 0;
    inPrint_iFullChineseMode = 0;
    inPrint_bGBK24Font = 0;
    inPrint_is_12_24_font_ok = 0;
    inPrint_iDownloadEnglishFontFlag = 0;
    memset( inPrint_cHZCasheString_16x16, 0, sizeof( inPrint_cHZCasheString_16x16 ) );
    memset( inPrint_cHZCasheString_24x24, 0, sizeof( inPrint_cHZCasheString_24x24 ) );
    memset( inPrint_NoTshzString, 0, sizeof( inPrint_NoTshzString ) );
    return;
}

// ����12*24��Ӣ���ַ�
int Print_Load_12_24_font(void)
{
    //int iSubID;
    //int iRet;
    int fd;
    //int is12x24 = 0;
    int fontsize = 0;
    char c = ' ';
    unsigned char ASCLBuf[ 24 ][ 2 ];

    //int i;
    unsigned long Offset;

    byte cDotData[ 126 ]; //cDotData1[ 126 ];

    fd = open( ASCFONT_24, O_RDONLY );
    if( fd <= 0 )
    {
        //
        error_tone();
        return PRINT_FAIL;
    }


    fontsize = inPrint_GetFontSize();
    if( fontsize != PRINT_FONT24 )
    {
        Print_SetFontSize(PRINT_FONT24);
    }

    for(c=' '; c<='~'; c++)
    {
        memset( ASCLBuf, 0, sizeof( ASCLBuf ) );

        Offset = c * 48;
        lseek( fd, Offset, SEEK_SET );
        if( read( fd, ( void * )ASCLBuf, 48 ) != 48 )
        {
            //close( fd );
            //return PRINT_FAIL;
            continue;
        }

        inPrint_ConvertH2V12( (unsigned char *)ASCLBuf, cDotData );

        inPrint_Download2Printer(TBID_FOR_12_24 , c, cDotData, 48 );    // ռ��6��table(59~64)
    }
    close( fd );


    if( fontsize != PRINT_FONT24 )
    {
        Print_SetFontSize((PRINTFONTSIZE)fontsize);
    }
    inPrint_is_12_24_font_ok = 1;
    inPrint_Log( __LINE__, "inPrint_is_12_24_font_ok is be set 1 " );

    return 1;

}


int inPrint_GetTerminalType(void)
{
    char buf[64];
    char buf_e[64];
    int		TermType = 0;

    memset(buf_e, 0 , sizeof(buf_e));
    SVC_INFO_EPROM(buf_e);
    SVC_CS2AZ(buf_e, buf_e); /* convert counted to normal string */

    memset(buf, 0 , sizeof(buf));
    SVC_INFO_MODELNO(buf);

    if (!memcmp(buf,"VX510",5)) //Vx510
    {
        TermType = _VX510;
    }
    else if (!memcmp(buf,"VX610",5)) //Vx610
    {
        TermType = _VX610;
    }
    else if (!memcmp(buf,"VX670",5)) //Vx670
    {
        TermType = _VX670;
    }
    else if (!memcmp(buf,"VX700",5)) //Vx700
    {
        TermType = _VX700;
    }
    else if (!memcmp(buf,"V510G",5)) //Vx510GPRS
    {
        TermType = _VX510G;
    }
    else if (!memcmp(buf,"VX520",5)) //Vx520
    {
        if (!memcmp(buf_e,"QT5G",4)) //Vx520 GPRS
        {
            TermType = _VX520;
        }
    }
    else if (!memcmp(buf,"VX680",5)) //Vx680     // add "QT6B" for 680 Wifi, Add by Simon, 2012-9-4
    {
        TermType = _VX680;
    }
    else if (!memcmp(buf,"VX820",5)) //Vx820
    {
        TermType = _VX820;
    }
    else if (!memcmp(buf,"VX805",5)) //Vx805
    {
        TermType = _VX805;
    }
    else if (!memcmp(buf,"VX675",5)) //VX675	   // Merge from Xichuan, Add by Simon, 2012-9-4
    {
        TermType = _VX675;
    }
    else
    {
        TermType = _VX510;
    }

    return TermType ;
}

/* --------------------------------------------------------------------------
* FUNCTION NAME: Print_Init.
* DESCRIPTION:   ��ʼ����ӡ��
* PARAMETERS:
* RETURN:
*   PRINT_NOHANDLE/PRINT_OK
* NOTES:
* ------------------------------------------------------------------------ */
int Print_Init(void)
{
    char os_version[ 56 ] = {0};    // �����ж�OS�Ƿ�֧��12*24����
    char *ptmp = NULL;

    inPrint_Log( __LINE__, "Print_Init......" );


    // Get POS Verison
    if ( (inPrint_GetTerminalType()) == _VX820 )
    {
        PRN_VX820DUET = 1;
        inPrint_Log( __LINE__, "Print Init Version is VX820......" );
    }

    inPrint_iPrinterHandle = Device_GetHandle( DEV_COM4 );
    if ( inPrint_iPrinterHandle < 0 )
    {
        // LOG_PRINTF_LIB( "Print_Init, DEV_COM4 can't be used,handle=[%d]", inPrint_iPrinterHandle );
        return PRINT_NOHANDLE;
    }

    memset(&stprinter_parm, 0, sizeof(stprinter_parm));
    stprinter_parm.rate      = Rt_19200;
    stprinter_parm.format    = Fmt_A8N1 | Fmt_DTR | Fmt_RTS | Fmt_auto;	//Fmt_A8N1 | Fmt_AFC | Fmt_DTR;
    stprinter_parm.protocol  = P_char_mode;
    stprinter_parm.parameter = 0;

    inPrint_bNewSprocketMode = 0;
    inPrint_iUIScheme = 0;

    if ( MmiUtil_GetPrinterType() == SPROCKET_PRINTER)
    {
        if( MmiUtil_GetTerminalType() == _VX520S || MmiUtil_GetTerminalType() == _VX805 )
        {
            inPrint_bNewSprocketMode = 1;

            inPrint_Log( __LINE__, "printer for new fast printing mode!" );
        }

        // cx 141107 start
        if( inPrint_iSprocketDotMode == MODE_360_DOTS)
        {
            //add by 2014.10.10
            // set 360-dot mode
            stprinter_parm.trailer.bytes.b[0] = 1;

            // do home-position-seek after every 10 left+right passes
            stprinter_parm.trailer.bytes.b[1] = 20;//20141205 Set 20 or even more instead of 10.

            // shift printing area on 3 dot to left
            //stprinter_parm.trailer.bytes.b[2] = (signed char)-3;
            //end
        }
        // cx 141107 end
    }

    set_opn_blk( inPrint_iPrinterHandle, &stprinter_parm );
    SVC_WAIT( 200 );

    inPrint_p3700_print( inPrint_iPrinterHandle, (unsigned char *)"\x18");

    if( PRN_VX820DUET == 1 )
        inPrint_init( inPrint_iPrinterHandle, 6 , P3700);
    else
        p3700_init( inPrint_iPrinterHandle, 6 );

    SVC_WAIT( 100 );

    // Added by laikey_20151209 -->
    switch( inPrint_GetStatus() )
    {
    case PRINT_MERCHFAIL:
        MmiUtil_Warning( "��ӡ������" );
        break;
    case PRINT_WRITEFAIL:
        break;
    case PRINT_READFAIL:
        break;
    case PRINT_NOPAPER:
        MmiUtil_Warning( "��ӡ��ȱֽ" );
        break;
    case PRINT_NOHANDLE:
        MmiUtil_Warning( "��ӡ����ʧ��" );
        break;
    }
    // <--

    //ɾ����ӡ��ʱ�ļ�
//  _remove(PRNCACHE_16X16);

    if( inPrint_iInitStatus < 100 )
    {
        inPrint_iInitStatus = 100;

        if( inPrint_bNewSprocketMode == 1 )
        {
            // ����Ӣ�ĵ����ֿ�(������Ƶ�ѹ���ֿ�)
            inPrint_Download_EnglishFont_8x14();
            inPrint_Log( __LINE__, "inPrint_Download_EnglishFont_8x14" );

            //��ȡ����Ҫ��ѹ��������
            inPrint_GetNNotshzCacheString( );
        }
    }

    // ��ȡOS�汾��������240ʱ��������12*24������
    // OS verison
    memset(os_version, 0, sizeof(os_version));
    SVC_INFO_EPROM(os_version);
    SVC_CS2AZ(os_version, os_version);

    // ptmp= os_version+strlen(os_version)-3;// ȡ��3λΪ�汾�ţ���ȻQT5G0245.0ȡ���İ汾��ΪQT5G0245��û��.0,
    ptmp= os_version+5;  // ���Ǹ�Ϊȡ��5λ��3���ֽ�Ϊ�汾�ţ�����Ӧ�ñȽϱ���
    *(ptmp+3) = 0;

    inPrint_Log(__LINE__, "get OS version[%s],[%s]", os_version, ptmp );
    if( strcmp( ptmp, "240" ) < 0 )
    {
        // not suport 12*24
        if( strncmp( os_version+2, "820", 3 ) == 0 )
        {
            normal_tone();
            // ��֧��12*24
        }
    }
    else
    {
        if( strncmp( os_version+2, "820", 3 ) == 0
                && inPrint_ChkVx820DuetVer() < 0 )
        {
            normal_tone();
            // ��֧��12*24
        }
        else
        {
            Print_Load_12_24_font();
        }
    }

    return PRINT_OK;
}


/* --------------------------------------------------------------------------
* FUNCTION NAME: Print_Open.
* DESCRIPTION:   �򿪴�ӡ��
* PARAMETERS:
* RETURN:
*   PRINT_NOHANDLE/PRINT_OK
* NOTES:
*	Added by @laikey_20130111
* ------------------------------------------------------------------------ */
int Print_Open( void )
{
    open_block_t parm;

    if ( inPrint_CheckPrintAutoOpenStatus( ) == 1 )
        return PRINT_OK;

    if ( inPrint_OpenDevice( ) != TRUE )
        return PRINT_NOHANDLE;

    inPrint_iPrinterHandle = Device_GetHandle( DEV_COM4 );
    if ( inPrint_iPrinterHandle < 0 )
        return PRINT_NOHANDLE;

    memset(&parm, 0, sizeof(parm));
    parm.rate      = Rt_19200;
    parm.format    = Fmt_A8N1 | Fmt_auto | Fmt_RTS;
    parm.protocol  = P_char_mode;
    parm.parameter = 0;

    set_opn_blk( inPrint_iPrinterHandle, &parm );
    SVC_WAIT( 200 );

    inPrint_p3700_print( inPrint_iPrinterHandle, (unsigned char *)"\x18");	// clear print buffer

    p3700_init( inPrint_iPrinterHandle, 6 );
    SVC_WAIT( 100 );

    return PRINT_OK;
}


/* --------------------------------------------------------------------------
* FUNCTION NAME: Print_Close.
* DESCRIPTION:   �رմ�ӡ��
* PARAMETERS:
* RETURN:
*   PRINT_NOHANDLE/PRINT_OK
* NOTES:
*	Added by @laikey_20130111
* ------------------------------------------------------------------------ */
int Print_Close( void )
{
    int iRet;

    if ( inPrint_CheckPrintAutoOpenStatus( ) == 1 )
        return PRINT_OK;

    if( PRN_VX820DUET == 1 )
    {
        iRet = inPrint_p3700_close( inPrint_iPrinterHandle );
        if ( iRet < 0 )
        {
            SVC_WAIT( 50 );

            iRet = inPrint_p3700_close( inPrint_iPrinterHandle );
        }
    }
    else
    {
        iRet = p3700_close( inPrint_iPrinterHandle );
        if ( iRet < 0 )
        {
            SVC_WAIT( 50 );

            iRet = p3700_close( inPrint_iPrinterHandle );
        }

    }
    inPrint_iPrinterHandle = 0;
    iRet = inPrint_CloseDev( );

    if ( iRet == TRUE )
        return PRINT_OK;
    else
        return PRINT_FAIL;
}


/* --------------------------------------------------------------------------
* FUNCTION NAME: Print_DelCache.
* DESCRIPTION:   ɾ����ӡ��ʱ�ļ�
* PARAMETERS:	None
* RETURN:		Return value of _remove()
* NOTES:		Should be called once in MainApp
* ------------------------------------------------------------------------ */
int Print_DelCache(void)
{
    inPrint_Log( __LINE__, "Print_DelCache" );

    memset( inPrint_cHZCasheString_16x16, 0, sizeof( inPrint_cHZCasheString_16x16 ) );
    memset( inPrint_cHZCasheString_24x24, 0, sizeof( inPrint_cHZCasheString_24x24 ) );

    _remove( PRNCACHE_16X16 );
    _remove( PRNCACHE_24X24 );

    return PRINT_OK;
}

/* --------------------------------------------------------------------------
* FUNCTION NAME: Print_PreLoadFont.
* DESCRIPTION:   ����16x16�����ֿ⣬��Print_init��ִ��
* PARAMETERS:
* RETURN:
* NOTES:
* ------------------------------------------------------------------------ */
void Print_PreLoadFont(void)
{
    int fp;
    int i;
    unsigned long lMaxCnt;
    int Ch_id;
    char cTmpBuf[ 2048 ];
    int rem = 0;
    //char buf[1024];
    //int offset = 0;
    //int iDflag =0;
    //int head = 0;
    if((fp = open( PRNCACHE_16X16, O_RDONLY)) > 0)
    {
        Print_SetFontSize( PRINT_FONT16 );

        lMaxCnt = lseek(fp, 0L, SEEK_END);

        if( lMaxCnt > sizeof(cTmpBuf))
            lMaxCnt = sizeof(cTmpBuf);

        memset( inPrint_cHZCasheString_16x16, 0, sizeof( inPrint_cHZCasheString_16x16 ) );
        memset( cTmpBuf, 0, sizeof( cTmpBuf ) );
        lseek( fp, 0L, SEEK_SET);
        read( fp, cTmpBuf, lMaxCnt );
        close( fp );

        lMaxCnt = strlen( cTmpBuf );
        rem = _remove( PRNCACHE_16X16 );

        // �����ӡ������
        inPrint_p3700_print( inPrint_iPrinterHandle, (unsigned char *)"\x18");

        inPrint_Log( __LINE__, "sting cache 16x16:%s | rem = %d ", cTmpBuf , rem );

        for( Ch_id = 0, i = 0; i < lMaxCnt; i += 2 )
        {
            inPrint_DownloadDot2Printer( inPrint_iPrinterHandle, (unsigned char *)&cTmpBuf[ i ], Ch_id );
            //inPrint_Log_test( __LINE__, "download hz:%2.2s-%d", &cTmpBuf[ i ], Ch_id );
            Ch_id ++;
        }
    }

    if((fp = open( PRNCACHE_24X24, O_RDONLY)) > 0)
    {
        Print_SetFontSize( PRINT_FONT24 );

        lMaxCnt = lseek(fp, 0L, SEEK_END);

        if( lMaxCnt > sizeof(cTmpBuf))
            lMaxCnt = sizeof(cTmpBuf);

        memset( inPrint_cHZCasheString_24x24, 0, sizeof( inPrint_cHZCasheString_24x24 ) );
        memset( cTmpBuf, 0, sizeof( cTmpBuf ) );
        lseek( fp, 0L, SEEK_SET);
        read( fp, cTmpBuf, lMaxCnt );
        close( fp );
        inPrint_p3700_print( inPrint_iPrinterHandle, (unsigned char *)"\x18");
        lMaxCnt = strlen( cTmpBuf );
        rem = _remove( PRNCACHE_24X24 );

        inPrint_Log( __LINE__, "sting cache 24x24:%s | rem = %d", cTmpBuf , rem);

        //inPrint_Log_test( __LINE__, "cTmpBuf:%s ", cTmpBuf );
//        hexdump( "file",cTmpBuf , lMaxCnt);

        for( Ch_id = 0, i = 0; i < lMaxCnt; i += 2 )
        {
            inPrint_DownloadDot2Printer( inPrint_iPrinterHandle, (unsigned char *)&cTmpBuf[ i ], Ch_id );
            //inPrint_Log_test( __LINE__, "download hz:%2.2s-%d", buf , offset );
            Ch_id++;
        }

        //inPrint_Log_test( __LINE__, "Preloadfont:%s | %d", inPrint_cHZCasheString_24x24, lMaxCnt);
    }
    return;
}


int Print_Str(char *str, unsigned char attrib)
{
    int i;
    int offset = 0;
    int head;
    int tail;
    int len;
    int hzmode = 0;
    int p_status = 0;
    int iDflag = 1;
    char buf[1024];

    // ����ӡ��״̬
    inPrint_Log( __LINE__, "write");
    p_status = inPrint_CheckStatus( 0 );
    inPrint_Log( __LINE__, "write");
    Print_CheckPrinterStatus( p_status );
    inPrint_Log( __LINE__, "write");
    inPrint_GetPrnCacheString( );

    inPrint_Log( __LINE__, "string=%s", str );

    //inPrint_Log_test( __LINE__, "printstr:%s ", inPrint_cHZCasheString_24x24 );

    len = strlen( str );
    if( len > sizeof( buf ) )
        return PRINT_FAIL;

    for( i = 0; i < len; i ++ )
    {
        if( inPrint_IsChinese( &str[ i ] ) )
        {
            memset( buf, 0, 3 );
            offset = 0;
            head = inPrint_SearchHZ( &str[i], &offset, buf, &iDflag );
            if( head < 0 )
            {
                inPrint_DownloadDot2Printer( inPrint_iPrinterHandle, (unsigned char *)buf, offset );

                inPrint_Log( __LINE__, "download hz:%2.2s-%d", buf, offset );
//               inPrint_Log_test( __LINE__, "DHz|%2.2s-%d-%d", buf, head ,offset );
            }
            else
            {
                inPrint_Log( __LINE__, "search hz:%2.2s-%d", buf, head );
//               inPrint_Log_test( __LINE__, "SHz:%2.2s-%d-%d", buf, head , offset);
            }
//            inPrint_Log_test( __LINE__, "g_24x24:%s ", inPrint_cHZCasheString_24x24 );
            if( iDflag == 1 )
                i++;
        }
    }

    hzmode = inPrint_IsChinese( str );

    for(head = tail = 0; tail < len; tail ++)
    {
        if( hzmode == 0 )
        {
            if( inPrint_IsChinese( str + tail ) )
            {
                hzmode = 1;

                memcpy( buf, str + head, tail - head);
                buf[ tail-head ] = 0;

                head = tail++; // Chinese has 2 bytes
                //inPrint_Log_test( __LINE__, "WE:%s-%d\r\n", buf, attrib  );
                inPrint_Print_English( attrib, (unsigned char *)buf );
            }
        }
        else
        {
            if( inPrint_IsChinese( str + tail ) )
            {
                if( inPrint_IsAsciiChar24x24( str + tail ) )
                {
                    if( strlen( str + tail) > 1 && inPrint_IsAsciiChar24x24( str + tail + 1 ) )
                        tail ++;
                }
                else
                    tail ++; // Chinese has 2 bytes
            }
            else
            {
                hzmode = 0;

                memcpy( buf, str + head, tail - head );
                buf[ tail-head ] = 0;

                head = tail;
                //inPrint_Log_test( __LINE__, "WH:%s-%d\r\n", buf, attrib  );
                inPrint_Print_Hz( buf, attrib );
            }
        }
    }

    if( head < len )
    {
        memcpy( buf, str + head, tail - head);
        buf[ tail-head ] = 0;

        if( hzmode )
        {
            //inPrint_Log_test( __LINE__, "WE:%s-%d\r\n", buf, attrib  );
            inPrint_Print_Hz( buf, attrib );
        }
        else
        {
            //inPrint_Log_test( __LINE__, "WH:%s-%d | %d | %d\r\n", buf, attrib, tail , head );
            inPrint_Print_English( attrib, (unsigned char *)buf );
        }
    }

    if( inPrint_bNewSprocketMode == 0 )
    {
        if( strchr( str, '\n' ) )
            SVC_WAIT( 10 );
    }

    return 0;
}

// �����ַ����������ַ���Ӣ���ַ�����
int inPrint_count_chars(char* in, int* en, int *cn )
{
    (*cn) = 0;
    (*en) = 0;
    if( in == NULL )
    {
        return 0;
    }
    while( (*in) != 0 )
    {
        if( (*in)&0x80 )
        {
            ++(*cn);
            if( *(++in) == 0 )  // ��һ���ַ���0ʱ�˳�
            {
                break;
            }
            ++(in); // ������2���ַ���Ҫ�ƶ�2��
        }
        else
        {
            ++(*en);
            ++(in);
        }
    }
    return (((*cn)<<1)+(*en));
}

// ����520,680,820
// 16*16�� 24*24 ����ͨ��
int Print_StrLR(char *left, char * right, unsigned char attrib)
{
    int offset = 0;
    int colMax = 32;
    int result;
    int en[2]= {0},cn[2]= {0};  // ���ڼ�¼��ࡢ�Ҳ�ĺ��֡�Ӣ���ַ�����
    int en_cnt = 0, cn_cnt=0;
    int dotMax = 384;   // ����һ����384����
    int dotOfEn = 12;
    int dotOfCn = 16;
    int mod3;

    char buffer[128];
    memset( buffer, ' ', sizeof(buffer));
    buffer[127] = 0;


    if( inPrint_iFontSize == PRINT_FONT24 )
    {
        // 24*24 (Ӣ��12*24)
        colMax = 32;    // һ�д�ӡ32��Ӣ���ַ�
        dotOfEn = 12;
        dotOfCn = 24;
    }
    else
    {
        // ����16*16��һ��24�� ��
        // Ӣ��8*14@32��һ��32��
        colMax = 32;    // һ�д�ӡ32��Ӣ���ַ�
        dotOfEn = 12;
        dotOfCn = 16;
    }

    if(attrib & DW) // ����ģʽ
    {
        colMax = (colMax>>1);   // ����2
        dotOfEn = (dotOfEn<<1); // ����2
        dotOfCn = (dotOfCn<<1);
    }

    if( left  )
    {
        if( inPrint_count_chars(left, &en[0], &cn[0] ) >= 128 )
        {
            // ̫����
            // ̫����
            Print_Str( left ,attrib);
            Print_Str( "\n" ,attrib);
            left = NULL;
        }
        else
        {
            en_cnt += en[0];
            cn_cnt += cn[0];
        }

    }
    if( right )
    {
        if( inPrint_count_chars(right, &en[1], &cn[1] ) >= 128 )
        {
            // ̫����
            Print_Str( right ,attrib);
            Print_Str( "\n" ,attrib);
            right = NULL;
        }
        else
        {
            en_cnt += en[1];
            cn_cnt += cn[1];
        }

    }

    if( left== NULL || right == NULL )
    {
        return 128;
    }

    if( ((en_cnt*dotOfEn)+(cn_cnt*dotOfCn)) >= dotMax )
    {
        // ����һ���ˣ��ֱ��ӡ2��: ����룬���Ҷ���

        if( left )
        {
            // ��ӡ�����
            strcpy( buffer, left );
            strcat( buffer, "\n" );
            result=Print_Str( buffer ,attrib);

            // ����������ַ�����ֱ�����Ҳ��ַ������¸�ֵ
            en_cnt = en[1];
            cn_cnt = cn[1];
            left = NULL;
            memset(buffer, ' ', colMax );
        }
    }

    // �˴���Ҫ��else

    if(left)
    {
        offset = strlen(left);
        strncpy(buffer, left, offset );
    }

    if(right)
    {
        // ���ۺ�������࣬�����Ҳֻ࣬��Ҫ�����ܵ������Ϳ�����
        if( cn_cnt> 0 && inPrint_iFontSize == PRINT_FONT16 )
        {
            // �Ҳ��ַ����к���,������16*16�ģ���Ҫ���¼��㳤��
            // ÿ3������,3*16=48,�൱��4��Ӣ���ַ�
            // Ҳ����ÿ6�������ַ����൱��4��Ӣ���ַ�������Ҫ2��Ӣ���ַ���λ
            mod3 = (cn_cnt%3);
            if( mod3 )  // ���ֲ���3�ı���,��Ҫ��ȫ�ǿո���3��
            {
                // ���㻹��д���������ַ�(�ո�)
                if( (dotMax-cn_cnt*dotOfCn-en_cnt*dotOfEn) > (3-mod3)*dotOfCn )
                {
                    // �������ַ���������3�ı���
                    // offset���Ѿ���bufferд����ַ�����ûд��ʱ��0
                    memset( buffer+offset, 0xA1, (3-mod3)<<1 );  // 2��A1��1��ȫ�ǿո�

                    cn_cnt += (3-mod3);
                }
                else
                {
                    // ֱ�Ӳ�1��Ӣ�Ŀո񣬴˴���Ҫ�ټ��㣬����
                    memset( buffer+offset, ' ', 1 );
                }
            }

            offset = (colMax - strlen(right));  // �ҵ��Ҷ���Ļ���λ��
            // ÿ3�����֣�����2���ո�
            // Ҳ����ÿ6�������ַ����൱��4��Ӣ���ַ�������Ҫ2��Ӣ���ַ���λ
            offset += ((cn_cnt/3)<<1);
        }
        else
        {
            // �Ҳ�û�к��֣�ֱ�Ӽ��㳤��
            offset = (colMax - strlen(right));
        }

        if(offset < 0)
            offset = 0;

        strcpy((buffer + offset), right );

    }
    else
    {
        buffer[offset] = 0;
    }


    strcat( buffer, "\n" );
    result=Print_Str(buffer,attrib);

    return result;

}


/* --------------------------------------------------------------------------
* FUNCTION NAME:  Print_StrStr
* DESCRIPTION:    ��ͬһ�д�ӡ2��buffer with/without justification
* PARAMETERS:
*   cLStr (in) -- �����ַ���
*   cRStr (in) -- �Ҳ���ַ���
*   form (in)  -- ��ӡ��ʽ���ο�TFormat���壩
* RETURN:         none
* NOTES:
*  1.left string can be overwritten by right one, if the strings too long
*  2.form=FORMAT_PRINT   causes left/right-justification of the strings ;
*    form=WITHOUT_FORMAT cause string's concatenation and printing as
*                        single string.
*    form=LEFT_BOLD      causes left/right justification like in the case
*                        of FORMAT_PRINT, left-justified part will be
*                        printed by Bold font.
* ------------------------------------------------------------------------ */
void Print_StrStr(char *cLStr, char *cRStr, TFormat form)
{
    BOOL bIsTotalASCIIFlag;
    BOOL bIsTotalASCIIFlag_R;
    sint i, siPrintSize;
    char tmp[64];

    siPrintSize = PRN_LINE_SIZE;
    bIsTotalASCIIFlag = FALSE;
    bIsTotalASCIIFlag_R = FALSE;

    for (i = 0; i < strlen(cLStr); i++)
    {
        if (!isascii(cLStr[i]))
        {
            bIsTotalASCIIFlag = TRUE;
            break;
        }
    }

    for (i = 0; i < strlen(cRStr); i++)
    {
        if (!isascii(cRStr[i]))
        {
            bIsTotalASCIIFlag = TRUE;
            bIsTotalASCIIFlag_R = TRUE;
            break;
        }
    }

    if( !bIsTotalASCIIFlag_R )
    {
        if( inPrint_iSprocketDotMode == 1 )
            siPrintSize = 40;
        else
            siPrintSize -= 1;
    }
    else if (!bIsTotalASCIIFlag)
    {
        siPrintSize -= 1;
    }

    switch (form)
    {
    case FORMAT_PRINT:
        i = siPrintSize - strlen(cRStr);
        Print_Str(cLStr, NORMAL);

        if ((siPrintSize - strlen(cLStr)) <= strlen(cRStr))
        {
            Print_Str("\n", NORMAL);
        }
        else
        {
            i -= strlen(cLStr);
        }

        if (i > 0)
        {
            memset(tmp, 0, sizeof(tmp));
            memset(tmp, ' ', i);
            Print_Str(tmp, NORMAL);
        }

        Print_Str(cRStr, NORMAL);
        Print_Str("\n", NORMAL);
        break;
    case FORMAT_LBOLD:
        Print_Str(cLStr, DH | DW);

        if ((siPrintSize - strlen(cLStr)*2) < strlen(cRStr))
        {
            Print_Str("\n", NORMAL);
            i = siPrintSize - strlen(cRStr);
        }
        else
        {
            i = siPrintSize - strlen(cLStr) * 2 - strlen(cRStr);
        }

        if (i > 0)
        {
            memset(tmp, 0, sizeof(tmp));
            memset(tmp, ' ', i);
            Print_Str(tmp, NORMAL);
        }

        Print_Str(cRStr, NORMAL);
        Print_Str("\n", NORMAL);
        break;
    case FORMAT_RBOLD:
        Print_Str(cLStr, NORMAL);

        if ((siPrintSize - strlen(cLStr)) < strlen(cRStr)*2)
        {
            Print_Str("\n", NORMAL);
            i = siPrintSize - strlen(cRStr) * 2;
        }
        else
        {
            i = siPrintSize - strlen(cLStr) - strlen(cRStr) * 2;
        }

        if (i > 0)
        {
            memset(tmp, 0, sizeof(tmp));
            memset(tmp, ' ', i);
            Print_Str(tmp, NORMAL);
        }

        Print_Str(cRStr, DW);
        Print_Str("\n", NORMAL);
        break;
    case FORMAT_BOLD:
        Print_Str(cLStr, DH | DW);

        if ((siPrintSize - strlen(cLStr)*2) < strlen(cRStr)*2)
        {
            Print_Str("\n", NORMAL);
            i = siPrintSize - strlen(cRStr) * 2;
        }
        else
        {
            i = siPrintSize - strlen(cLStr) * 2 - strlen(cRStr) * 2;
        }

        if (i > 0)
        {
            memset(tmp, 0, sizeof(tmp));
            memset(tmp, ' ', i);
            Print_Str(tmp, NORMAL);
        }

        Print_Str(cRStr, DH | DW);
        Print_Str("\n", NORMAL);
        break;
    default:
        break;
    }

}

short inPrint_print_graphic (short h_comm_port, short imageId, short offset)
{
    short ret_val ;
    char  rd_buf[15];

// the Esc for Graphic download. "\0x1bGPImageID,offset;Graphic-data;"
    memset(rd_buf,0,sizeof(rd_buf));
//	rd_buf[0] = 0x1b;
//	rd_buf[1] = 'G';
//	rd_buf[2] = 'P';
// 	{PRN_LOGO, {0x1b,0x47,0x50}},
//    getEsqSeq(rd_buf, PRN_LOGO); //DCS ID 191 RAJAGOPAL_N1
    rd_buf[0] = 0x1b;
    rd_buf[1] = 0x47;
    rd_buf[2] = 0x50; //wangzhijian
//Currently only imageID 0 is supported.
    ret_val = strlen(rd_buf);
    int2str(rd_buf+ret_val,imageId);
    ret_val = strlen(rd_buf);
    rd_buf[ret_val] = ',';
    ret_val = strlen(rd_buf);
    int2str(rd_buf+ret_val,offset);
    ret_val = strlen(rd_buf);
    rd_buf[ret_val] = ';';
    inPrint_Log( __LINE__, "inPrint_print_graphic" );

    write_check_print( h_comm_port, (char *)rd_buf, strlen( rd_buf));
    return ret_val;
}

/* --------------------------------------------------------------------------
* FUNCTION NAME: Print_logo.
* DESCRIPTION:   ��ӡlgoͼƬ
* PARAMETERS:
*   Offset ��in��-- ͼƬ��ߵĿհ�
*   LogoFile ��in��-- ͼƬ�ļ����ƣ���׺.lgo��
* RETURN:
*   PRINT_OK/PRINT_NOHANDLE/PRINT_NOPAPER/PRINT_FAIL
* NOTES:
* ------------------------------------------------------------------------ */
int Print_logo(short offset, char *LogoFile)
{
    int  font_file_h;
    int  ret;
    int  i;
    int  p_status = 0;
//    static int dnld_graphic_flag;
//    static char cLogoFileName[ 126 ];

    // ����ӡ��״̬
    if( PRN_VX820DUET == 1 )
    {
        p_status = inPrint_CheckStatus( 0 );
    }
    else
    {
        p_status = inPrint_CheckStatus( 1 );
    }
    Print_CheckPrinterStatus( p_status );
    inPrint_Log( __LINE__, "Print test");
    if (LogoFile == NULL)
        return PRINT_OK;


    if ( DownladFlag == 0 )
    {
        if( PRN_VX820DUET == 1 )
        {
            DownladFlag = 1;
        }

        // ����LOGO�ļ�
        if ((font_file_h = File_Open(LogoFile, O_RDONLY)) < 0)
        {
            return PRINT_OPENFAIL;
        }

        i = 3;

        while ( i > 0 )
        {
            if( PRN_VX820DUET == 1 )
            {
                ret = inPrint_p3700_dnld_graphic_file(inPrint_iPrinterHandle, font_file_h);
            }
            else
            {
                ret = p3700_dnld_graphic_file(inPrint_iPrinterHandle, font_file_h);
            }

            if (ret == 0)
                break;

            SVC_WAIT( 1000 );
            i--;
        }

        File_Close(font_file_h);

//        sprintf( cLogoFileName, "%s", LogoFile );
    }

    // ��ӡLOGO�ļ�

    if( PRN_VX820DUET == 1 )
    {
        ret = inPrint_print_graphic( inPrint_iPrinterHandle, 0, offset);
    }
    else
    {
        ret = p3700_print_graphic( inPrint_iPrinterHandle, 0, offset);
    }
    if (ret <= 0)
        return PRINT_FAIL;

    return p_status;
}

/* --------------------------------------------------------------------------
* FUNCTION NAME: Print_bitmap.
* DESCRIPTION:   ��ӡbitmap�ļ�
* PARAMETERS:
*   Offset ��in��-- ͼƬ��ߵĿհ�
*   BmpFile ��in��-- ͼƬ�ļ����ƣ���׺.bmp��
* RETURN:
*   PRINT_OK/PRINT_NOHANDLE/PRINT_NOPAPER/PRINT_FAIL
* NOTES:��ӡ��bmp֮�󣬴�ӡ����handle���ر��ˡ���Ҫ���´򿪴�ӡ���豸����ʼ����
* ------------------------------------------------------------------------ */
int Print_bitmap(short offset, char *BmpFile)
{
    int  iRet;
    int  p_status = 0;

    if (BmpFile == NULL)
        return PRINT_OK;

    // ����ӡ��״̬
    p_status = inPrint_CheckStatus( 1 );
    Print_CheckPrinterStatus( p_status );

    inPrint_Log( __LINE__, "Print_bitmap, printer handle=[%d]", inPrint_iPrinterHandle );

    //ret = print_image(offset, BmpFile);
    iRet = inPrint_Bitmap( inPrint_iPrinterHandle, offset, BmpFile);

    inPrint_Log( __LINE__, "Print_bitmap ret=[%d]", iRet );

    return iRet;
}

/* --------------------------------------------------------------------------
* FUNCTION NAME: Print_English.
* DESCRIPTION:   ��ӡӢ���ַ���
* PARAMETERS:
*   english_str (in) -- Ӣ���ַ���
*   font_size (in) -- 0x02, 0x03, 0x04
* RETURN:
*   PRINT_OK/PRINT_NOHANDLE/PRINT_NOPAPER/PRINT_FAIL
* NOTES:
*   ����������ӡ��
*   0x02���壬һ�пɴ�ӡ24���ַ�
*   0x03���壬һ�пɴ�ӡ32���ַ�
*   0x04���壬һ�пɴ�ӡ42���ַ�
*   ������ʽ��ӡ��
*   0x02���壬һ�пɴ�ӡ30���ַ�
*   0x03���壬һ�пɴ�ӡ15���ַ�
*   0x04���壬һ�пɴ�ӡ20���ַ�
* ------------------------------------------------------------------------ */
int Print_English(char *english_str, short font_size)
{
    int  p_status = 0;

    // ����ӡ��״̬
    p_status = inPrint_CheckStatus( 0 );
    Print_CheckPrinterStatus( p_status );
    inPrint_Log( __LINE__, "Print test");
    if( inPrint_bNewSprocketMode == 1 )
    {
        inPrint_Print_English( NORMAL, (unsigned char *)english_str );
        return PRINT_OK;
    }

    // ESC=0x1B, a22=�����и߶�22
    //inPrint_p3700_print( inPrint_iPrinterHandle, (unsigned char *)"\x1B""a22;");
    inPrint_Log( __LINE__, "Print test");
    inPrint_p3700_select_font( inPrint_iPrinterHandle, font_size, 0);
    inPrint_p3700_print( inPrint_iPrinterHandle, (unsigned char *)english_str);

    return p_status;
}

/* --------------------------------------------------------------------------
* FUNCTION NAME: Print_EngSmall.
* DESCRIPTION:   ��ӡӢ���ַ���
* PARAMETERS:
*   english_str ��in��-- Ӣ���ַ���
* RETURN:
*   PRINT_OK/PRINT_NOHANDLE/PRINT_NOPAPER/PRINT_FAIL
* NOTES:
*   ����������ӡ����һ�пɴ�ӡ42���ַ�
*   ������ʽ��ӡ����һ�пɴ�ӡ30���ַ�
* ------------------------------------------------------------------------ */
int Print_EngSmall(char *english_str)
{
    int  p_status = 0;

    // ����ӡ��״̬
    p_status = inPrint_CheckStatus( 0 );
    Print_CheckPrinterStatus( p_status );
    inPrint_Log( __LINE__, "Print test");
    if( inPrint_bNewSprocketMode == 1 )
    {
        inPrint_Print_English( NORMAL, (unsigned char *)english_str );
        return PRINT_OK;
    }
    inPrint_Log( __LINE__, "Print test");
    if ( MmiUtil_GetPrinterType() == SPROCKET_PRINTER )
    {
        inPrint_Log( __LINE__, "Print test");
        inPrint_p3700_print(inPrint_iPrinterHandle, (unsigned char *)"\x1B""a22;");
        inPrint_p3700_select_font(inPrint_iPrinterHandle, 0x02, 0);
    }
    else
    {
        //inPrint_p3700_print(inPrint_iPrinterHandle, (unsigned char *)"\x1B""a16;");
        inPrint_Log( __LINE__, "Print test");
        inPrint_p3700_select_font(inPrint_iPrinterHandle, 0x04, 0);
    }
    inPrint_Log( __LINE__, "Print test");
    inPrint_p3700_print(inPrint_iPrinterHandle, (unsigned char *)english_str);
    inPrint_Log( __LINE__, "Print test");
    return p_status;
}

/* --------------------------------------------------------------------------
 * FUNCTION NAME: Print_Hex
 * DESCRIPTION:   ��ӡ16��������.
 * PARAMETERS:
 *    msgPrompt (in) - ��ʾ��Ϣ
 *    Buf       (in) - ����
 *    BufLen    (in) - ���ݳ���.
 * RETURN:
 * NOTES:
 * ------------------------------------------------------------------------ */
void Print_Hex(char *msgPrompt, byte *Buf, int BufLen)
{
    char  out[128], tmp[128];
    usint i, j, k;

    Print_Str((char *)msgPrompt, 0);
    Print_Str("\n", 0);

    sprintf(tmp, "%03hu|---------Hex-------+\n", BufLen);
    Print_Str(tmp, 0);

    if ( BufLen > 1000 )
    {
        Print_Str( "BufLen is too large!\n", 0 );
        return;
    }

    j = (BufLen % 8) ? (BufLen / 8 + 1) : (BufLen / 8);

    for (i = 0; i < j; i++)
    {
        sprintf(out, "%03u| ", i*8);

        for (k = 0; k < 8; k++)
        {
            sprintf(tmp, "%02X", Buf[i*8+k]);
            strcat(out, tmp);

            if (k == 3)
            {
                strcat(out, " ");
            }
        }

        strcat(out, "\n");
        Print_Str(out, 0);
    }

    Print_Str("+----------------------+\n", 0);

    return;
}

/* -----------------------------------------------------------------------
* FUNCTION NAME:  Print_FormFeed
* DESCRIPTION:    ��ʽ��ӡ����ҳָ��
* PARAMETERS :
* RETURN:
* NOTES:
 * ----------------------------------------------------------------------*/
int Print_FormFeed(void)
{
    int p_status = 0;

    if ( MmiUtil_GetPrinterType() != SPROCKET_PRINTER)  // �������ͣ�ֱ�ӷ��� 0
        return 0;

    // ����ӡ��״̬
    p_status = inPrint_CheckStatus( 1 );
    Print_CheckPrinterStatus( p_status );

    inPrint_Log( __LINE__, "form feed start" );

    //inPrint_p3700_print(inPrint_iPrinterHandle, (unsigned char *)"\x18");  // clear print buffer
    inPrint_p3700_print(inPrint_iPrinterHandle, (unsigned char *)"\x0B");

    //inPrint_CheckStatus( 1 );

    inPrint_Log( __LINE__, "form feed end" );
    return p_status;
}

/* -----------------------------------------------------------------------
* FUNCTION NAME:  Print_SetLineHeight
* DESCRIPTION:    �����и߶�
* PARAMETERS :
*     height(in) -- �и߶�(default is 22, min is 16, max is 48)
* RETURN:
* NOTES:
 * ----------------------------------------------------------------------*/
void Print_SetLineHeight(int height)
{
    char buf[10];
    int p_status = 0;

    // ����ӡ��״̬
    p_status = inPrint_CheckStatus( 1 );
    if( PRN_VX820DUET == 1 )
    {
        Print_CheckPrinterStatusvoid( p_status );
    }
    else
    {
        if( p_status == PRINT_NOHANDLE )
            return;
    }
    //inPrint_p3700_print( inPrint_iPrinterHandle, (unsigned char *)"\x18");  // clear print buffer
    inPrint_Log( __LINE__, "Print test");
    memset(buf, 0, sizeof(buf));
    sprintf(buf, "\x1B""a%d;", height);
    inPrint_p3700_print(inPrint_iPrinterHandle, (unsigned char *)buf);
    inPrint_Log( __LINE__, "Print test");
    return;
}

/* -----------------------------------------------------------------------
* FUNCTION NAME:  Print_SetFormLength
* DESCRIPTION:    �������ֽҳ�泤��
* PARAMETERS :
*     length(in) -- ҳ�泤��(default is 140mm, max is 300mm)
* RETURN:
* NOTES:
 * ----------------------------------------------------------------------*/
void Print_SetFormLength(int length)
{
    char buf[10];
    int  p_status = 0;

    // ����ӡ��״̬
    p_status = inPrint_CheckStatus( 1 );
    if( PRN_VX820DUET == 1 )
    {
        Print_CheckPrinterStatusvoid( p_status );
    }
    else
    {
        if( p_status == PRINT_NOHANDLE )
            return;
    }
    //inPrint_p3700_print(inPrint_iPrinterHandle, (unsigned char *)"\x18");  // clear print buffer
    inPrint_Log( __LINE__, "Print test");
    memset(buf, 0, sizeof(buf));
    sprintf(buf, "\x1B""K%d;", length);
    inPrint_p3700_print(inPrint_iPrinterHandle, (unsigned char *)buf);
    inPrint_Log( __LINE__, "Print test");
    return;
}


/* -----------------------------------------------------------------------
* FUNCTION NAME:  Print_Feed
* DESCRIPTION:    ��ʽ��ӡ����ֽ/��ָֽ��
* PARAMETERS :
*   flag(in)   - FORWARD_PAPER:��ֽ/ REVERSE_PAPER:��ֽ
*   length(in) - ����
* RETURN:
* NOTES:
 * ----------------------------------------------------------------------*/
int Print_Feed(int flag, int length)
{
    int p_status = 0;
    char buf[20];

    if( flag != FORWARD_PAPER && flag != REVERSE_PAPER)
        return PRINT_OK;

    // ����ӡ��״̬
    p_status = inPrint_CheckStatus( 1 );
    Print_CheckPrinterStatus( p_status );
    inPrint_Log( __LINE__, "Print test");
    // Added by @laikey_20130321 -->
    if ( MmiUtil_GetTerminalType( ) == _VX805 )
    {
        inPrint_Feed_Vx805( flag, length );
        return p_status;
    }
    // <--

    //inPrint_p3700_print(inPrint_iPrinterHandle, (unsigned char *)"\x18");  // clear print buffer

    memset(buf, 0, sizeof(buf));
    sprintf(buf, "\x1B""b%d,%d;", length, flag);

    inPrint_p3700_print(inPrint_iPrinterHandle, (unsigned char *)buf);

    if( MmiUtil_GetPrinterType() == SPROCKET_PRINTER &&
            MmiUtil_GetTerminalType() == _VX520S )
    {
        unsigned long lTrytimer;
        int iStatus;

        lTrytimer = read_ticks();
        while( 1 )
        {
            if( !inPrint_CheckReadlyStatus( 1, &iStatus ) )
                break;

            if( read_ticks() - lTrytimer > 500 )
                break;
        }
    }

    inPrint_Log( __LINE__, "Print_Feed(%d,%d) send ok!", flag, length );
    return p_status;
}

/* --------------------------------------------------------------------------
* FUNCTION NAME: Print_SetDark.
* DESCRIPTION:   ���ô�ӡ�ڶ�*DARK
* PARAMETERS:
*    darkValue(in) ----- (ȡֵ��Χ1-29)
* RETURN:
*		PRINT_NOHANDLE/PRINT_OK
* NOTES:
* ------------------------------------------------------------------------ */
void Print_SetDark(int darkValue)
{
    char buf[40];
    int  p_status = 0;

    // ����ӡ��״̬
    p_status = inPrint_CheckStatus( 1 );
    if( PRN_VX820DUET == 1 )
    {
        Print_CheckPrinterStatusvoid( p_status );
    }
    else
    {
        if( p_status == PRINT_NOHANDLE)
            return;
    }
    inPrint_Log( __LINE__, "Print test");
    inPrint_p3700_print(inPrint_iPrinterHandle, (unsigned char *)"\x18");  // clear print buffer

    memset(buf, 0, sizeof(buf));
    sprintf(buf, "\x1B""w%d;", darkValue);

    inPrint_p3700_print(inPrint_iPrinterHandle, (unsigned char *)buf);
}


/* --------------------------------------------------------------------------
* FUNCTION NAME: Print_Str_12.
* DESCRIPTION:   ��ͼ�η�ʽ��ӡ�����У�12x12��Ӣ�ģ�5x8���ִ��ĺ���
* PARAMETERS:
*		  str (in) -- Ҫ��ӡ���ַ���
*		  attrib (in) -- ��ӡ����, ��ʱ����
* RETURN:
*		PRINT_OK/PRINT_NOHANDLE/PRINT_NOPAPER/PRINT_FAIL
* NOTES:
* ------------------------------------------------------------------------ */
int Print_Str_12(char *str, unsigned char attrib)
{
    int len, i, j;
    short fp, fp1, retVal;
    char filename[32], tmp[4];
    char Printmode[4]= {0};
    char ioctl_status[4];
    unsigned char buf[32], linebuf[32*12];	// 12��, ÿ��15���֣�ÿ���ֵ�ÿ��
    int ret = 0;
    long end;
    BOOL bIsGbkFont12;

    if (strlen(str) == 0)
        return PRINT_OK;

    // Added by @laikey_20130321 -->
    if ( MmiUtil_GetTerminalType() == _VX805)
    {
        return ( inPrint_Print_Str_12_Vx805( str, attrib ) );
    }
    // <--

    bIsGbkFont12 = isGbkFont12();
    if (bIsGbkFont12)
    {
        strcpy(filename, GBKFONT_12);
    }
    else
    {
        strcpy(filename, CHNFONT_12);
    }
    if ((fp = open(filename,O_RDONLY)) < 0)
        return PRINT_NOHANDLE;

    strcpy(filename, ENGFONT_5x8);
    if ((fp1 = open(filename,O_RDONLY)) < 0)
        return PRINT_NOHANDLE;

    //**************************************************************************************
    // Start the graphics mode of printing the data
    //ESC g is the command for going to the graphicsa mode
    //**************************************************************************************
    memset( Printmode, 0, 4 );
    memset( ioctl_status, 0, 4 );
    Printmode[ 0 ] = 0x1b;
    Printmode[ 1 ] = 0x67;

    if( PRN_VX820DUET != 1 )
    {
        while (get_port_status(inPrint_iPrinterHandle,ioctl_status)!=0)
            SVC_WAIT(2);

        end = set_itimeout(-1, 2, TM_SECONDS);
        while (write(inPrint_iPrinterHandle,Printmode,2) != 2)
        {
            SVC_WAIT(10);
            if (!CHK_TIMEOUT(-1, end))
            {
                close(fp);
                close(fp1);
                return 	WRITE_FAIL;
            }
        }
    }
    else
    {
        write_check_print(inPrint_iPrinterHandle,Printmode,2);
    }
    //**************************************************************************************
    //Now thw bitmap will have the data in the reverse hence the last data of the bitmap
    //will be the first data hnece get the data in reverse
    //the value of the buffer is memset to 0x0c 1100 0000 which will not print data
    //Container should have 1 1			0 0 0 0 0 0
    //						| |			| | | | | |
    //					Non printing	Printing data
    //**************************************************************************************

    len = strlen( str );
    if (len > 30)	/* ֻ��ӡһ�� */
        len = 30;

    memset(linebuf, 0, sizeof(linebuf));

    for (i = 0; i < 12; i ++)
    {

        memset(buf, 0xC0, sizeof(buf));

        for (j = 0; j < len; j ++ )
        {
            if (bIsGbkFont12 && (unsigned char)str[j] >= 0x81 && (unsigned char)str[j+1] >= 0x40)
            {
                lseek(fp, inPrint_GetGBKOffset(str[j], str[j+1])*24 + 128*12 + 16 + (i * 2), SEEK_SET);

                read(fp, tmp, 2);

                /* 12x12����ÿ����2���ֽ���ɣ�ʵ��ֻռ����12��BIT */
                buf[j] |= tmp[0] >> 2;
                buf[j + 1] |= (tmp[0] << 6) >> 2;
                buf[j + 1] |= tmp[1] >> 4;
                j ++;
            }
            else if ((unsigned char)str[j] >= 0xA1 && (unsigned char)str[j+1] >= 0xA0)
            {
                lseek(fp, inPrint_GetGB2312Offset(str[j], str[j+1])*24 + (i * 2), SEEK_SET);

                read(fp, tmp, 2);

                /* 12x12����ÿ����2���ֽ���ɣ�ʵ��ֻռ����12��BIT */
                buf[j] |= tmp[0] >> 2;
                buf[j + 1] |= (tmp[0] << 6) >> 2;
                buf[j + 1] |= tmp[1] >> 4;
                j ++;
            }
            else if (i > 3) //ʹ��5x8��Ӣ�ģ��¶���
            {
                lseek(fp1, (8 + str[j] * 9 + 1 + i - 4), SEEK_SET);
                read(fp1, tmp, 1);

                /* 5x8����ÿ��1���ֽڣ�ʵ��ռ�ú�5��BIT */
                buf[j] |= tmp[0];
            }
        }
        buf[j] = 0x21;	/* ���� */

        if (j == 30)
            memcpy(linebuf + i * j, buf, j);
        else
            memcpy(linebuf + i * (j + 1), buf, j + 1);
    }
    linebuf[strlen((char *)linebuf)] = 0x21;	/* �о�һ������ */
    if( PRN_VX820DUET != 1 )
    {
        do
        {
            while (get_port_status(inPrint_iPrinterHandle, ioctl_status)!=0)
                SVC_WAIT(0);

            retVal = write(inPrint_iPrinterHandle,(char *)linebuf, strlen((const char *)linebuf));
        }
        while ((retVal<0) && (errno == ENOSPC || errno == ENXIO));
    }
    else
    {
        write_check_print(inPrint_iPrinterHandle,(char *)linebuf, strlen((const char *)linebuf));
    }
    //***********************************************************************************************
    // Exit from the graphics mode passing the 0x18 CAN command ie the 0001 0100 the fifth bit should be set to 1
    //***********************************************************************************************
    memset(Printmode,0,4);
    Printmode[0]=0x18;

    if( PRN_VX820DUET != 1 )
    {
        while (get_port_status(inPrint_iPrinterHandle, ioctl_status)!=0)
            SVC_WAIT(0);

        ret = PRINT_OK;
        end = set_itimeout(-1, 2, TM_SECONDS);
        while (write(inPrint_iPrinterHandle,Printmode,1) < 0)
        {
            SVC_WAIT(10);
            if (!CHK_TIMEOUT(-1, end))
            {
                ret = WRITE_FAIL;
                break;
            }
        }
    }
    else
    {
        write_check_print(inPrint_iPrinterHandle,Printmode,1);
    }
    close(fp);
    close(fp1);
    SVC_WAIT(10);
    return ret;

}


int Print_SetSprocketDotMode(int dotmode)
{
    open_block_t parm;

    memset(&parm, 0, sizeof(parm));
    get_opn_blk( inPrint_iPrinterHandle, &parm );

    if(dotmode == MODE_360_DOTS)
    {
        inPrint_iSprocketDotMode = MODE_360_DOTS;
        parm.trailer.bytes.b[0] = 1;
    }
    else
    {
        inPrint_iSprocketDotMode = MODE_180_DOTS ;
        parm.trailer.bytes.b[0] = 0;
    }

    set_opn_blk( inPrint_iPrinterHandle, &parm );

    //SVC_WAIT( 100 );

    return inPrint_iSprocketDotMode;
}


/* --------------------------------------------------------------------------
* FUNCTION NAME:  Print_SetFont
* DESCRIPTION:  ���ô�ӡ���壬Ŀǰ֧��16x16,24x24
* PARAMETERS:
*   iFontSize (in)	=16:16X16
					=24:24X24
* RETURN: BANK_OK/BANK_FAIL
* NOTES:
	��ʱֻ֧��������ӡ�������������
* ------------------------------------------------------------------------ */
int Print_SetFontSize( PRINTFONTSIZE iFontSize )
{
    inPrint_Log( __LINE__, "print set font size:%d, ok", iFontSize );

    inPrint_iFontSize = iFontSize;
    return PRINT_OK;
}


/* --------------------------------------------------------------------------
* FUNCTION NAME: Print_Pixel.
*
* DESCRIPTION: ��ӡ����������
*
* PARAMETERS:
*	pcPixelData			- ��Ҫ��ӡ�ĵ�������
*	iWidth				- ��ӡ���ݵĿ���
*	iHeight				- ��ӡ���ݵĸ߶�
*	iAlignMode			- ���뷽ʽ:LEFT_JST,RIGHT_JST,CENTER_JST
*
* RETURN:
*		enumPrintRet:PRINT_OK/PRINT_FAIL
		-10:�Ŵ���ӡ���ȳ���384����
*
* NOTES:
*		��ⳬʱʱ��Ϊ30��
* ------------------------------------------------------------------------ */
int Print_Pixel( unsigned char *pcPixelData, int iWidth, int iHeight, int iAlignMode )
{
    unsigned char *pcLineBuf;
    int iRet;
    int x, y;
    int iLength;
    int iOffset;
    long lTimer = 0;
    char cPrintMode[ 4 ] = {0};
    char cIOstatus[ 4 ];

    if( pcPixelData == NULL )
        return PRINT_FAIL;

    if( inPrint_iPrinterHandle <= 0 )
        return PRINT_NOHANDLE;

    memset(cPrintMode, 0, 4);
    memset(cIOstatus, 0, 4);
    cPrintMode[ 0 ] = 0x1b;
    cPrintMode[ 1 ] = 'g';
    if( PRN_VX820DUET != 1 )
    {
        while( get_port_status(inPrint_iPrinterHandle, cIOstatus) != 0)
            SVC_WAIT( 2 );

        lTimer = set_itimeout(-1, 2, TM_SECONDS);
        while( write( inPrint_iPrinterHandle, cPrintMode, 2) != 2)
        {
            SVC_WAIT( 10 );
            if( !CHK_TIMEOUT( -1, lTimer ) )
                return  PRINT_FAIL;
        }
    }
    else
    {
        write_check_print( inPrint_iPrinterHandle, cPrintMode, 2);
    }
    iLength = (iWidth + 5) / 6;	 // ÿ�ֽ�6����

    if(iAlignMode == LEFT_JST )
        iOffset = 0;
    else if(iAlignMode == CENTER_JST )
        iOffset = (63 - iLength)/2;
    else
        iOffset = (63 - iLength);

    if( iOffset < 0 )
        iOffset = 0;

    pcLineBuf = (unsigned char *) malloc(iLength + iOffset + 1);

    while( get_port_status( inPrint_iPrinterHandle, cIOstatus) != 0)
        SVC_WAIT(0);

    //��ʼ���д�ӡ
    for( y = 0; y < iHeight; y ++ )
    {
        memset( pcLineBuf, 0, sizeof( pcLineBuf ) );
        memset( pcLineBuf, 0xC0, iOffset + iLength + 1 );
        for( x = 0; x < iWidth; x++)
        {
            if( pcPixelData[y * iWidth + x ] & 0x01 )
                pcLineBuf[ iOffset + x / 6 ] |= 1 << (6 - x % 6 - 1);
        }

        pcLineBuf[ iOffset + iLength ] = 0x21;  /* ���� */
        if( PRN_VX820DUET != 1 )
        {
            do
            {
                iRet = write( inPrint_iPrinterHandle, (char *)pcLineBuf, iOffset + iLength + 1);
            }
            while( (iRet < 0) && (errno == ENOSPC || errno == ENXIO));
        }
        else
        {
            write_check_print( inPrint_iPrinterHandle, (char *)pcLineBuf, iOffset + iLength + 1);
        }
    }
    if( PRN_VX820DUET != 1 )
    {
        while( get_port_status(inPrint_iPrinterHandle, cIOstatus) != 0)
            SVC_WAIT(0);
    }
    iRet = PRINT_OK;

    if( PRN_VX820DUET != 1 )
    {
        lTimer = set_itimeout( -1, 2, TM_SECONDS);
    }
    memset(cPrintMode, 0, 4);
    cPrintMode[ 0 ] = 0x18;
    if( PRN_VX820DUET != 1 )
    {
        while( write(inPrint_iPrinterHandle, cPrintMode, 1) < 0)
        {
            SVC_WAIT(10);

            if(!CHK_TIMEOUT(-1, lTimer))
            {
                iRet = PRINT_FAIL;
                break;
            }
        }
    }
    else
    {
        write_check_print(inPrint_iPrinterHandle, cPrintMode, 1);
    }
    free( pcLineBuf );
    return iRet;
}


/*-----------------------------------------------------------------------
 * FUNCTION NAME: Print_QRCode
 * DESCRIPTION:	��ӡQR��
 * PARAMETER:	qrcode - In
          		PixSize - In ͼ��Ŵ���
 * RETURN:		PRINT_OK / PRINT_FAIL
 * NOTE:
 *----------------------------------------------------------------------*/
int Print_QRCode( QRcode *stQRcode, int iZoomX, int iAlignMode )
{
    unsigned char *pcLineBuf;
    int width, height;
    int iRet;
    int x, y;
    int iLength;
    long lTimer = 0;
    int iOffset;
    char cPrintMode[ 4 ] = {0};
    char cIOstatus[ 4 ];

    if(	stQRcode == NULL || stQRcode->data == NULL )
        return PRINT_FAIL;

    width = stQRcode->width * iZoomX;
    height = stQRcode->width * iZoomX;

    if( inPrint_iPrinterHandle <= 0 )
        return PRINT_NOHANDLE;

    memset(cIOstatus, 0, 4);
    while( get_port_status(inPrint_iPrinterHandle, cIOstatus) != 0)
        SVC_WAIT(2);
    if( PRN_VX820DUET != 1 )
    {
        lTimer = set_itimeout(-1, 2, TM_SECONDS);
    }
    memset(cPrintMode, 0, 4);
    cPrintMode[ 0 ] = 0x1b;
    cPrintMode[ 1 ] = 'g';
    if( PRN_VX820DUET != 1 )
    {
        while( write( inPrint_iPrinterHandle, cPrintMode, 2) != 2)
        {
            SVC_WAIT( 10 );

            if( !CHK_TIMEOUT( -1, lTimer ) )
                return  PRINT_FAIL;
        }
    }
    else
    {
        write_check_print( inPrint_iPrinterHandle, cPrintMode, 2);
    }
    iLength = (width + 5) / 6;   // ÿ�ֽ�6����

    if(iAlignMode == LEFT_JST )
        iOffset = 0;
    else if(iAlignMode == CENTER_JST )
        iOffset = (63 - iLength)/2;
    else
        iOffset = (63 - iLength);

    if( iOffset < 0 )
        iOffset = 0;

    pcLineBuf = (unsigned char *) malloc( iOffset + iLength + 1);

    while( get_port_status( inPrint_iPrinterHandle, cIOstatus) != 0)
        SVC_WAIT(0);

    //��ʼ���д�ӡ
    for( y = 0; y < height; y ++ )
    {
        memset( pcLineBuf, 0, sizeof( pcLineBuf ) );
        memset( pcLineBuf, 0xC0, iOffset + iLength + 1 );
        for( x = 0; x < width; x++)
        {
            if( stQRcode->data [y / iZoomX * stQRcode->width + x / iZoomX ] & 0x01 )
                pcLineBuf[ iOffset + x / 6 ] |= 1 << (6 - x % 6 - 1);
        }

        pcLineBuf[ iOffset + iLength ] = 0x21;  /* ���� */
        if( PRN_VX820DUET != 1 )
        {
            do
            {
                iRet = write( inPrint_iPrinterHandle, (char *)pcLineBuf, iOffset + iLength + 1);
            }
            while( (iRet < 0) && (errno == ENOSPC || errno == ENXIO));
        }
        else
        {
            write_check_print( inPrint_iPrinterHandle, (char *)pcLineBuf, iOffset + iLength + 1);

        }
    }
    while( get_port_status(inPrint_iPrinterHandle, cIOstatus) != 0)
        SVC_WAIT(0);

    iRet = PRINT_OK;
    if( PRN_VX820DUET != 1 )
    {
        lTimer = set_itimeout( -1, 2, TM_SECONDS);
    }
    memset(cPrintMode, 0, 4);
    cPrintMode[ 0 ] = 0x18;
    if( PRN_VX820DUET != 1 )
    {
        while( write(inPrint_iPrinterHandle, cPrintMode, 1) < 0)
        {
            SVC_WAIT(10);

            if(!CHK_TIMEOUT(-1, lTimer))
            {
                iRet = PRINT_FAIL;
                break;
            }
        }
    }
    else
    {
        write_check_print(inPrint_iPrinterHandle, cPrintMode, 1);
    }
    free( pcLineBuf );
    return iRet;
}


/*-----------------------------------------------------------------------
 * FUNCTION NAME: Print_SetUIScheme
 * DESCRIPTION:	���ô�ӡ�����״̬���Ƿ���ʾ��ʾ��Ϣ
 * PARAMETER:	iUIStatus - 1: ����ʾ״̬��Ϣ
 						  - 0: ��ʾ״̬��Ϣ
 * RETURN:		PRINT_OK / PRINT_FAIL
 * NOTE:
 *	������Ҫ,���ڵ���Print_Init��ʼ�����趨, ϵͳĬ��Ϊ0
 *----------------------------------------------------------------------*/
int Print_SetUIScheme( int iUIStatus )
{
    inPrint_iUIScheme = iUIStatus;

    inPrint_Log( __LINE__, "Print_SetUIScheme, inPrint_iUIScheme=%d", inPrint_iUIScheme );
    return PRINT_OK;
}

/*-----------------------------------------------------------------------
 * FUNCTION NAME: Print_SetFullHZMode
 * DESCRIPTION:	����ASCII(Ӣ��)��ӡ�Ƿ������ֵ���ģʽ��ӡ
 * PARAMETER:	iMode - 1: �������ֵ���ģʽ��ӡ
 					  - 0: ����Ӣ�ĵ���ģʽ��ӡ
 * RETURN:
 * NOTE:
 *----------------------------------------------------------------------*/
void Print_SetFullHzMode( int iMode )
{
    if( iMode != 1 && iMode != 0 )
        return;

    inPrint_iFullChineseMode = iMode;
}


/*=========================================*
*   P R I V A T E     F U N C T I O N S   *
*=========================================*/

// debugģʽlog��־���
static void inPrint_Log( int iLine, char *pString, ... )
{
#ifdef	LOGSYS_FLAG
    static int init_status;
    struct Opn_Blk com_parm;
    char cMsgBuf[ 2048 ];
    char *pArg;
    va_list v_Arg;
    //char *pComName = (char *)"DEV_USBD";
    //char *pComName = (char *)DEV_COM1;  //for VX520
    //char *pComName = (char *)"/DEV/COM1";
    char *pComName = (char *)"/DEV/COM1";

    memset( cMsgBuf, 0, sizeof( cMsgBuf ) );
    sprintf( cMsgBuf, "[line=%d],", iLine );

    if( pString != NULL )
    {
        pArg = strchr( pString, '%' );

        if( pArg )
        {
            va_start( v_Arg, pString );
            vsprintf( cMsgBuf+strlen( cMsgBuf ), pString, v_Arg );
            va_end( v_Arg );
        }
        else
        {
            strcpy( cMsgBuf+strlen( cMsgBuf ), pString );
        }
    }

    if( !strchr( cMsgBuf, '\n') )
        strcat( cMsgBuf, "\r\n" );

    // Output message by COM
    if( init_status != 99 )
    {
        com_parm.rate = Rt_115200;
        com_parm.format = Fmt_A8N1;
        com_parm.protocol = P_char_mode;
        com_parm.parameter = 0;
        if( ComDev_Init( pComName, &com_parm ) == COMDEV_NOHANDLE )
        {
            int handle;

            handle = open( pComName, 0 );
            if( handle > 0 )
                set_opn_blk( handle, &com_parm);
            else
                return;
        }
        init_status = 99;
    }

    ComDev_Write( pComName, cMsgBuf, strlen( cMsgBuf ) );
#endif
    return;
}

/* --------------------------------------------------------------------------
* FUNCTION NAME: Print_DelCache.
* DESCRIPTION:   ɾ����ӡ��ʱ�ļ�
* PARAMETERS:	None
* RETURN:		Return value of _remove()
* NOTES:		Should be called once in MainApp
* ------------------------------------------------------------------------ */
int Print_DelLastCache(void)
{
    int fd;
    //int i;
    unsigned long lMaxCnt;

    inPrint_Log( __LINE__, "Print_DelLastCache" );

//    memset( inPrint_cHZCasheString_16x16, 0, sizeof( inPrint_cHZCasheString_16x16 ) );
//    memset( inPrint_cHZCasheString_24x24, 0, sizeof( inPrint_cHZCasheString_24x24 ) );

    if((fd = open( PRNCACHE_24X24, O_RDONLY)) > 0)
    {
        lMaxCnt = lseek(fd, 0L, SEEK_END);

        memset( inPrint_cHZCasheString_24x24, 0, sizeof( inPrint_cHZCasheString_24x24 ) );
        lseek( fd, 0L, SEEK_SET);
        read( fd, inPrint_cHZCasheString_24x24, lMaxCnt - PRN_MAX_LIMI_NUM );
        close( fd );

        _remove( PRNCACHE_24X24 );


        //inPrint_Log( __LINE__, "open cache PRINT_FONT16!" );
        fd = open( PRNCACHE_24X24, O_RDWR | O_CREAT);

        lseek( fd, 0, SEEK_SET );
        write( fd, (char *)inPrint_cHZCasheString_24x24, sizeof( inPrint_cHZCasheString_24x24 ) );
        close( fd );
    }
    if((fd = open( PRNCACHE_16X16, O_RDONLY)) > 0)
    {
        lMaxCnt = lseek(fd, 0L, SEEK_END);

        memset( inPrint_cHZCasheString_16x16, 0, sizeof( inPrint_cHZCasheString_16x16 ) );
        lseek( fd, 0L, SEEK_SET);
        read( fd, inPrint_cHZCasheString_16x16, lMaxCnt - PRN_MAX_LIMI_NUM );
        close( fd );

        _remove( PRNCACHE_16X16 );

        //inPrint_Log( __LINE__, "open cache PRINT_FONT16!" );
        fd = open( PRNCACHE_16X16, O_RDWR | O_CREAT);

        lseek( fd, 0, SEEK_SET );
        write( fd, (char *)inPrint_cHZCasheString_16x16, sizeof( inPrint_cHZCasheString_16x16 ) );
        close( fd );
    }
    return PRINT_OK;

}

static byte inPrint_IsGBK24Font( void )
{
    int fd;

    if( inPrint_bGBK24Font == '1' )
        return 1;
    else if( inPrint_bGBK24Font == '2' )
        return 0;

    fd = open( CHNFONT_GBK24, O_RDONLY );
    if ( fd <= 0 )
    {
        inPrint_bGBK24Font = '2';
        return 0;
    }
    close( fd );

    inPrint_bGBK24Font = '1';
    return 1;
}

static byte inPrint_IsChinese( char *s )
{
    unsigned char us[3];

    memcpy( us, s, 2 );

    if( isGbkFont16() )	//added by baijz 20130515 for GBK
    {
        if (us[0] >= 0x81 && us[1] >= 0x40)
            return 1;
    }
    else
    {
        if (us[0] >= 0xA1 && us[1] > 0xA0)
            return 1;
    }

    return inPrint_IsAsciiChar24x24( s );
    //return 0;
}

static byte inPrint_IsFullHzMode( void )
{
    if( inPrint_iFullChineseMode != 1 )
        return 0;
    else
        return 1;
}

static byte inPrint_IsAsciiChar24x24( char *s )
{
    unsigned char us;


    if( (inPrint_is_12_24_font_ok) || ( !inPrint_IsFullHzMode() ))
    {
        // �Ѿ���12x24���ַ�������0��ֱ��ʹ��Ӣ�ķ�ʽ��ӡ
        return 0;
    }

    us = s[ 0 ];
    if( us >= 0x20 && us <= 0x7e )
        return 1;

    return 0;
}

//�жϸú����Ƿ���Ҫ��ѹ��
int inPrint_CheckNotshzCasheString( char *str )
{
    char cTmpBuf[ 3 ];

    memset( cTmpBuf, 0, sizeof( cTmpBuf ) );
    memcpy( cTmpBuf, str, 2 );

    if( strstr( inPrint_NoTshzString, cTmpBuf ) )
        return 1;
    else
        return 0;
}


//��ȡ����Ҫ��ѹ��������,��Щ�����ڴ�ӡʱѹ�������ӡ��ῴ���庺��ԭ��
int inPrint_GetNNotshzCacheString( void )
{
    int fp;
    long file_size = 0;

    memset( inPrint_NoTshzString, 0, sizeof( inPrint_NoTshzString ) );

    if( (fp = open( "/notshz.txt", O_RDONLY ) ) <= 0 )
        return 0;

    file_size = lseek(fp, 0L, SEEK_END);

    if ( file_size > sizeof( inPrint_NoTshzString ) )
        file_size = sizeof( inPrint_NoTshzString );

    lseek( fp, 0L, SEEK_SET );
    read( fp, inPrint_NoTshzString, file_size );
    close( fp );

    inPrint_Log( __LINE__, "not switchhz cache:%s", inPrint_NoTshzString );

    return 1;
}


//��ȡ��ӡ�������ص������ݵĺ����б�
int inPrint_GetPrnCacheString( void )
{
    int fp;
    long file_size = 0;

    if( inPrint_GetFontSize( ) == PRINT_FONT24 )
    {
        memset( inPrint_cHZCasheString_24x24, 0, sizeof( inPrint_cHZCasheString_24x24) );
        if( (fp = open( PRNCACHE_24X24, O_RDONLY ) ) <= 0 )
        {
            fp = open(PRNCACHE_24X24, O_WRONLY | O_CREAT);
            close( fp );
            return 0;
        }

        file_size = lseek(fp, 0L, SEEK_END);

        if ( file_size > sizeof( inPrint_cHZCasheString_24x24 ) )
            file_size = sizeof( inPrint_cHZCasheString_24x24 );

        lseek( fp, 0L, SEEK_SET );
        read( fp, inPrint_cHZCasheString_24x24, file_size );
        close( fp );

        //inPrint_Log( __LINE__, "sting cache:%s", inPrint_cHZCasheString_24x24 );

        return strlen( inPrint_cHZCasheString_24x24 );
    }
    else
    {
        memset( inPrint_cHZCasheString_16x16, 0, sizeof( inPrint_cHZCasheString_16x16 ) );
        if( (fp = open( PRNCACHE_16X16, O_RDONLY ) ) <= 0 )
        {
            fp = open(PRNCACHE_16X16, O_WRONLY | O_CREAT);
            close( fp );
            return 0;
        }

        file_size = lseek(fp, 0L, SEEK_END);

        if ( file_size > sizeof( inPrint_cHZCasheString_16x16 ) )
            file_size = sizeof( inPrint_cHZCasheString_16x16 );

        lseek( fp, 0L, SEEK_SET );
        read( fp, inPrint_cHZCasheString_16x16, file_size );
        close( fp );

        //inPrint_Log( __LINE__, "sting cache:%s", inPrint_cHZCasheString_16x16 );

        return strlen( inPrint_cHZCasheString_16x16 );
    }

}

// ���Ҹú����Ƿ��Ѿ����ع�����
static int inPrint_SearchHZ( char *str, int *index, char *pcRetStr, int *piRetDoubleFlag )
{
    int i;
    int len;
    byte buf[ 3 ];
    char *p;

    *piRetDoubleFlag = 1;
    memset( buf, 0, sizeof( buf ) );

    if( inPrint_IsAsciiChar24x24( str ) )
    {
        buf[ 0 ] = str[ 0 ];

        if( strlen( str ) <= 1 )
        {
            *piRetDoubleFlag = 0;
            buf[ 1 ] = ' ';
        }
        else if( str[ 1 ] >= 0x20 && str[ 1 ] <= 0x7e )
            buf[ 1 ] = str[ 1 ];
        else
        {
            *piRetDoubleFlag = 0;
            buf[ 1 ] = ' ';
        }
    }
    else
    {
        memcpy( buf, str, 2 );
    }
    memcpy( pcRetStr, buf, 2 );

    if( inPrint_GetFontSize( ) == PRINT_FONT24 )
    {
        len = strlen( inPrint_cHZCasheString_24x24 );
        p = inPrint_cHZCasheString_24x24;
    }
    else
    {
        len = strlen( inPrint_cHZCasheString_16x16 );
        p = inPrint_cHZCasheString_16x16;
    }

    if( len <= 0 )
    {
        *index = 0;
        return -1;
    }

    for( i = 0; i < len; i += 2 )
    {
        if( memcmp( p + i, buf, 2 ) == 0 )
        {
            i >>= 1;	// i /= 2;
            return i;
        }
    }

    *index = i >> 1;

    if (( PRN_MAX_FONT_NUM/2 ) <= (*index) )
    {
        *index = ( PRN_MAX_FONT_NUM - PRN_MAX_LIMI_NUM )/2;
        Print_DelLastCache();
    }
    return -1;
}


// 8X8 bits����ת�ã���1X8�ֽ�
void inPrint_Turn_8X8(unsigned char *ary, unsigned char *dst)
{
    unsigned char mask;
    int i, j;

    for(i = 0; i < 8; i++)
    {
        dst[i] = 0;
        mask = 0x80;

        for(j = 0; j < 8; j++)
        {
            if(j <= i)
                dst[i] |= (ary[j] << (i - j)) & mask;
            else
                dst[i] |= (ary[j] >> (j - i)) & mask;

            mask >>= 1;
        }
    }
}


// ����2���޷����ַ��ͱ�����ֵ(��ָ��)
void inPrint_Swap_Val(unsigned char *Val1, unsigned char *Val2)
{
    unsigned char Temp;

    Temp = *Val1;
    *Val1 = *Val2;
    *Val2 = Temp;
}


// 24X24 bits����ת�ã��ֳ�3X3=9��8bits X 8bits�Ŀ�
void inPrint_Turn_24X24(unsigned char *ary, unsigned char *dst)
{
    int i, j, k;
    unsigned char im_ary[8], dest_ary[8];

    memcpy(dst, ary, 72);

    // ��һ��ѭ��, 3X3���ת��
    for(i = 0; i < 3; i++)
    {
        for(j = 0; j < 3; j++)
        {
            if(i <= j)  //�Խ��߼����µĲ���
                continue;

            for(k = 0; k < 8; k++)
            {
                inPrint_Swap_Val(&dst[i + k * 3 + j * 24], &dst[j + k * 3 + i * 24]);
            }
        }
    }

    // �ڶ���ѭ��, 8bits X 8bits����ת��
    for(i = 0; i < 3; i++)
    {
        for(j = 0; j < 3; j++)
        {
            memset(im_ary, 0, sizeof(im_ary));

            for(k = 0; k < 8; k++)
            {
                im_ary[k] = dst[i + k * 3 + j * 24 ];
            }

            memset(dest_ary, 0, sizeof(dest_ary));
            inPrint_Turn_8X8(im_ary, dest_ary);

            for(k = 0; k < 8; k++)
            {
                dst[i + k * 3 + j * 24 ] = dest_ary[k];
            }
        }
    }
}


// ˮƽ���е�24X24���ֵ���ת������8X8�Ŀ�, ������, ������������
static void inPrint_ConvertH2V( unsigned char *src, unsigned char *dest )
{
    int i, j, k;

    k = 0;

    for( i = 0; i < 9; i++ )
    {
        for( j = 0; j < 8; j++ )
        {
            dest[k] = src[( i/3 )*24 + i%3 + j*3];
            k++;
        }
    }
}

static void inPrint_ConvertH2V16( unsigned char *src, unsigned char *dest )
{
    int i, j, k;

    k = 0;

    for( i = 0; i < 4; i++ )
    {
        for( j = 0; j < 8; j++ )
        {
            dest[k] = src[( i/2 )*16 + i%2 + j*2];
            k++;
        }
    }
}

// for 12*24
static void inPrint_ConvertH2V12( unsigned char *src, unsigned char *dest )
{
    int i, j, k;

    k = 0;

    for( i = 0; i < 6; i++ )// һ����6��, 48�ֽ�
    {
        // 8 4
        // 8 4
        // 8 4
        for( j = 0; j < 8; j++ )
        {
            dest[k] = src[( i/2 )*16 + i%2 + j*2];
            k++;
        }
    }
}

static int inPrint_DownloadDot2Printer(int printer_h, unsigned char *str, int totalhz)
{
    int iSubID;
    int iRet;
    int fd;
    byte cDotData[ 126 ], cDotData1[ 126 ];

    if( printer_h <= 0 )
    {
        inPrint_Log( __LINE__, "download dot 2 printer, no handl" );
        return PRINT_NOHANDLE;
    }

    if( inPrint_IsAsciiChar24x24( (char *)str ) )
        iRet = inPrint_DownloadAscii( str, cDotData );
    else
        iRet = inPrint_DownloadHZ( str, cDotData );

    if( iRet != PRINT_OK )
    {
        inPrint_Log( __LINE__, "get download dot fail, iRet = %d ", iRet );
        return iRet;
    }

    iSubID = totalhz;
    if( inPrint_bNewSprocketMode == 0 )
    {
        if( inPrint_GetFontSize() == PRINT_FONT24 )
            inPrint_Download2Printer(24 + (iSubID >> 7) * 9, iSubID & 0x7f, cDotData, 72 );
        else
            inPrint_Download2Printer(3 + (iSubID >> 7) * 4, iSubID & 0x7f, cDotData, 32 );
    }
    else
    {
        if( inPrint_CheckNotshzCasheString( (char *)str ) == 1 )
        {
            inPrint_Compress_16x16_h_only( cDotData1, cDotData);

            inPrint_Download2Printer(3 + (iSubID >> 7) * 4, iSubID & 0x7f, cDotData1, 32 );

            inPrint_Download2Printer(43 + (iSubID >> 7) * 4, iSubID & 0x7f, cDotData1, 32 );
        }
        else
        {
            inPrint_Compress_16x16_h_only( cDotData1, cDotData );
            inPrint_Download2Printer(3 + (iSubID >> 7) * 4, iSubID & 0x7f, cDotData1, 32 );

            inPrint_Compress_16x16_hv(cDotData1, cDotData );
            inPrint_Download2Printer(43 + (iSubID >> 7) * 4, iSubID & 0x7f, cDotData1, 32 );
        }
    }

    if( inPrint_GetFontSize() == PRINT_FONT24 )
    {
        inPrint_Log( __LINE__, "open cache PRINT_FONT24!" );
        memcpy( inPrint_cHZCasheString_24x24 + strlen( inPrint_cHZCasheString_24x24 ), str, 2 );
        fd = open( PRNCACHE_24X24, O_RDWR | O_CREAT);
    }
    else
    {
        inPrint_Log( __LINE__, "open cache PRINT_FONT16!" );
        memcpy( inPrint_cHZCasheString_16x16 + strlen( inPrint_cHZCasheString_16x16 ), str, 2 );
        fd = open( PRNCACHE_16X16, O_RDWR | O_CREAT);
    }

    if( fd < 0 )
    {
        inPrint_Log( __LINE__, "open cache buffer file fail!" );
        return PRINT_OK;
    }

    lseek( fd, 0, SEEK_END );
    write( fd, (char *)str, 2 );  //no font index file
    close( fd );

    return PRINT_OK;
}

//���Һ�����Ӧ�ĵ������ݲ�����
static int inPrint_DownloadHZ( unsigned char *str, unsigned char *pRetDotData )
{
    int fd;
    int i, j, k, qu, wei;
    unsigned long offset;
    unsigned char buf[ 126 ], buf1[ 126 ];
    char fontName[21];
    BOOL bIsGBKFont;

    if( inPrint_GetFontSize() == PRINT_FONT24 )
    {
        bIsGBKFont = 1;
        if( inPrint_IsGBK24Font() )
        {
            // for gbk 24x24
            if( str[ 0 ] >= 0x81 && str[ 1 ] >= 0x40 )
                offset = ((str[ 0 ]-0x81)*191 + (str[ 1 ]-0x40) + 64)*(24*3) + 1552;
            else
                offset = ((str[ 0 ]-0xa1-15)*94 + (str[ 1 ]-0xa1) + 64)*(24*3) + 1552;

            fd = open( CHNFONT_GBK24, O_RDONLY );
            if( fd <= 0 )
            {
                inPrint_Log( __LINE__, "open chnfont_gbk24 fail" );
                return PRINT_FAIL;
            }
        }
        else
        {
            qu = str[0] - 0xa0;
            wei = str[1] - 0xa0;

            if( qu >= 16 )
            {
                fd = open( CHNFONT_24S, O_RDONLY );
                if( fd <= 0 )
                {
                    inPrint_Log( __LINE__, "open chnfont_24s fail, will try #24s next" );

                    bIsGBKFont = 0;
                    fd = open( "F:/#HZK24S", O_RDONLY );
                    if( fd <= 0 )
                    {
                        inPrint_Log( __LINE__, "open chnfont_#24s fail" );
                        return PRINT_FAIL;
                    }
                }
                offset = ( 94 * ( qu - 1 - 15 ) + wei - 1 ) * 72;
            }
            else
            {
                fd = open( CHNFONT_24T, O_RDONLY );
                if( fd <= 0 )
                {
                    inPrint_Log( __LINE__, "open chnfont_24t fail, will try #24t next" );

                    bIsGBKFont = 0;
                    fd = open( "F:/#HZK24T", O_RDONLY );
                    if( fd <= 0 )
                    {
                        inPrint_Log( __LINE__, "open chnfont_#24t fail" );
                        return PRINT_FAIL;
                    }
                }

                offset = ( 94 * ( qu - 1 ) + wei - 1 ) * 72;
            }
        }

        lseek( fd, offset, SEEK_SET );

        memset( buf, 0, sizeof( buf ) );
        if( read( fd, ( void * )buf, 72 ) != 72 )
        {
            inPrint_Log( __LINE__, "read 24x24 dot file 72 bytes fail" );
            close( fd );
            return PRINT_READFAIL;
        }

        close( fd );

        inPrint_Log( __LINE__, "bIsGBKFont=%x", bIsGBKFont );

        memset(buf1, 0, sizeof(buf1));
        if( bIsGBKFont )
            memcpy( buf1, buf, 72 );
        else
            inPrint_Turn_24X24( buf, buf1);

        memset(buf, 0, sizeof(buf));
        inPrint_ConvertH2V( buf1, buf);

        memcpy( pRetDotData, buf, 72 );
    }
    else
    {
        bIsGBKFont = isGbkFont16();
        if (bIsGBKFont)
        {
            strcpy(fontName, GBKFONT_16);
            qu = str[ 0 ] - 0x81;
            wei = str[ 1 ] - 0x40;
        }
        else
        {
            strcpy(fontName, CHNFONT);
            qu = str[ 0 ] - 0xA1;
            wei = str[ 1 ] - 0xA1;
        }
        if ( qu < 0 || wei < 0 )
            return 0;

        if( bIsGBKFont )
            offset = ( qu * 191 + wei + 64 ) * 32L + 16;
        else
            offset = ( qu * 94 + wei + 64 ) * 32L + 16;

        fd = open( fontName, O_RDONLY );
        if( fd < 0 )
            return PRINT_FAIL;

        lseek( fd, offset, SEEK_SET );

        memset( buf, 0, sizeof( buf ) );
        if( read( fd, (char *)buf, 32 ) != 32 )
        {
            close( fd );
            return PRINT_READFAIL;
        }

        close( fd );

        memcpy( buf1, buf + 8, 8);
        memcpy( buf + 8, buf + 16, 8);
        memcpy( buf + 16, buf1, 8);
        memset( buf1, 0, sizeof(buf1));

        for (k = 0; k < 32; k += 8)
        {
            for (i = 0; i < 8; i++)
            {
                for (j = 0; j < 8; j++)
                    buf1[ i + k ] |= ( (buf[ j + k ] >> i) & 0x01 ) << (7 - j);
            }
        }

        memcpy( pRetDotData, buf1, 32 );
    }

    return PRINT_OK;
}

static int inPrint_DownloadAscii( unsigned char *str, unsigned char *pcRetDotData )
{
    int fd;
    int i;
    unsigned long Offset;

    inPrint_Log( __LINE__, "inPrint_DownloadAscii" );

    if( inPrint_GetFontSize() == PRINT_FONT24 )
    {
        unsigned char ASCLBuf[ 24 ][ 2 ];
        unsigned char ASCRBuf[ 24 ][ 2 ];
        unsigned char ASCBuf[ 24 ][ 3 ];
        unsigned char Vertical[80];

        inPrint_Log( __LINE__, "inPrint_DownloadAscii" );
        memset( ASCLBuf, 0, sizeof( ASCLBuf ) );
        memset( ASCRBuf, 0, sizeof( ASCRBuf ) );
        memset( ASCBuf, 0, sizeof( ASCBuf ) );

        fd = open( ASCFONT_24, O_RDONLY );
        if( fd <= 0 )
        {
            inPrint_Log( __LINE__, "Open failed ASCFONT_24" );
            return PRINT_FAIL;
        }

        Offset = str[ 0 ] * 48;
        lseek( fd, Offset, SEEK_SET );
        if( read( fd, ( void * )ASCLBuf, 48 ) != 48 )
        {
            close( fd );
            inPrint_Log( __LINE__, "read failed ASCFONT_24" );
            return PRINT_FAIL;
        }

        Offset = str[ 1 ] * 48;
        lseek( fd, Offset, SEEK_SET );
        if( read( fd, ( void * )ASCRBuf, 48 ) != 48 )
        {
            close( fd );
            inPrint_Log( __LINE__, "read failed ASCFONT_24" );
            return PRINT_FAIL;
        }

        close( fd );

        for( i = 0; i < 24; i++ )
        {
            ASCBuf[ i ][ 0 ] = ASCLBuf[ i ][ 0 ];
            ASCBuf[ i ][ 1 ] = ASCLBuf[ i ][ 1 ];
            ASCBuf[ i ][ 1 ] |= ASCRBuf[ i ][ 0 ] >> 4;
            ASCBuf[ i ][ 2 ] |= (( ASCRBuf[ i ][ 0 ] & 0x0f ) << 4 );
            ASCBuf[ i ][ 2 ] |= ASCRBuf[ i ][ 1 ] >> 4;
        }

        memset( Vertical, 0, sizeof( Vertical ) );
        memcpy( Vertical, ASCBuf, 72 );
        inPrint_ConvertH2V( Vertical, pcRetDotData );

    }
    else
    {
        unsigned char ASCLBuf[ 16 ];
        unsigned char ASCRBuf[ 16 ];
        unsigned char Vertical[ 80 ];

        memset( ASCLBuf, 0, sizeof( ASCLBuf ) );
        memset( ASCRBuf, 0, sizeof( ASCRBuf ) );

        fd = open( ASCFONT_16, O_RDONLY );
        if( fd <= 0 )
        {
            inPrint_Log( __LINE__, "Open ASCFONT_16 failed " );
            return PRINT_FAIL;
        }
        Offset = str[ 0 ] * 16;
        lseek( fd, Offset, SEEK_SET );
        if( read( fd, ( void * )ASCLBuf, 16 ) != 16 )
        {
            inPrint_Log( __LINE__, "read ASCLbuf is error :%s ", ASCLBuf);
            close( fd );
            return -2;
        }

        Offset = str[ 1 ] * 16;
        lseek( fd, Offset, SEEK_SET );
        if( read( fd, ( void * )ASCRBuf, 16 ) != 16 )
        {
            inPrint_Log( __LINE__, "read ASCRbuf is error :%s ", ASCRBuf);
            close( fd );
            return PRINT_FAIL;
        }

        close( fd );

        memset( Vertical, 0, sizeof( Vertical ) );
        for( i = 0; i < 16; i++ )
        {
            Vertical[ i*2 ] = ASCLBuf[ i ];
            Vertical[ i*2 + 1 ] = ASCRBuf[ i ];
        }

        inPrint_ConvertH2V16( Vertical, pcRetDotData );

    }

    return PRINT_OK;
}


// ���غ��ֵ�������
int inPrint_Download2Printer(char Tab_id, char Ch_id, unsigned char *buf_pft, int buf_length)
{
    int ret = 0;
    int retry;
    int len;
    char scmd[128];

    // select font size id and table id
    if( inPrint_GetFontSize( ) == PRINT_FONT24 )
    {
        if( Tab_id == TBID_FOR_12_24)
        {
            // l9��12*24��Ӧ�ı��
            sprintf(scmd, "\x1bl9%d;", Tab_id);
        }
        else
        {
            sprintf(scmd, "\x1bl5%d;", Tab_id);
        }
    }
    else
        sprintf(scmd, "\x1bl1%d;", Tab_id);

    SVC_WAIT( 5 );

    inPrint_WriteStr(inPrint_iPrinterHandle, (unsigned char *)scmd);
    retry = 0;
    // prepare download font command
    scmd[0] = 0x1b;
    scmd[1] = 'm';
    scmd[2] = Ch_id;
    if( 0 )// PRN_VX820DUET == 1) //failed
    {
        scmd[3] = '\0';
        inPrint_WriteStr(inPrint_iPrinterHandle, (unsigned char *)scmd);

        memcpy(scmd , buf_pft, buf_length );
        scmd[buf_length] = ';';
        len = buf_length + 1;
    }
    else
    {
        memcpy(scmd + 3, buf_pft, buf_length );
        scmd[buf_length+3] = ';';

        len = buf_length + 4;
    }
    SVC_WAIT( 7 );

    if( PRN_VX820DUET != 1 )
    {
        while((ret = write(inPrint_iPrinterHandle, scmd, len)) != len && retry < 6)
        {
            SVC_WAIT( 200 );
            retry++;
        }
    }
    else
    {
        write_check_print(inPrint_iPrinterHandle, scmd, len);
    }
    return ret;
}

static int inPrint_GetGB2312Offset(unsigned char h, unsigned char l)
{
    return((h-0xa1-15)*94 + (l-0xa1) + 1410); /* 1410�Ǻ��ֵ�ƫ���� */
}

static int inPrint_GetGBKOffset(unsigned char h, unsigned char l)
{
    return((h-0x81)*191 + (l-0x40));
}

static int inPrint_CheckMechFailure( int iResetFlag )
{
    int iTry = 0;
    int iFlag = iResetFlag;
    int iRet;
    char cBuffer[ 3 ];

    if( MmiUtil_GetPrinterType() != SPROCKET_PRINTER )
        return PRINT_OK;

    while( iTry++ < 5 )
    {
        if( iFlag == 1 )
        {
            reset_port_error( inPrint_iPrinterHandle );

            inPrint_Log( __LINE__, "machine mechanism fail,reset_port_error and please wait 500ms" );
            SVC_WAIT( 500 );
        }
        if( PRN_VX820DUET != 1 )
        {
            iRet = write( inPrint_iPrinterHandle, "\x1B\x64", 2 );
            if( iRet < 2 )
                break;
        }
        else
        {
            write_check_print( inPrint_iPrinterHandle, "\x1B\x64", 2 );
        }
        memset( cBuffer, 0, sizeof( cBuffer ) );
        while( (iRet = read(inPrint_iPrinterHandle, cBuffer, 1)) == 0 )
            SVC_WAIT( 10 );

        if( iRet < 0 )
            break;

        inPrint_Log( __LINE__, "check mech failure,read buffer[0]=%02x", cBuffer[ 0 ] );

        if( !(cBuffer[ 0 ] & 0x40) )
            return 1;

        iFlag = 1;
    }

    return 0;
}

static int inPrint_CheckReadlyStatus( int iWaitFlag, int *piRetPrinterStatus )
{
    int iRet;
    int delay = 0;
    char cBuffer[ 3 ];
    inPrint_Log( __LINE__, "write");
    if( inPrint_iPrinterHandle < 0 )
    {
        *piRetPrinterStatus = PRINT_NOHANDLE;
        inPrint_Log( __LINE__, "inPrint_CheckReadlyStatus, no handle" );
        return 0;
    }
    inPrint_Log( __LINE__, "write");
    //<ESC>d
    if( PRN_VX820DUET != 1 )
    {
        iRet = write(inPrint_iPrinterHandle, "\x1B\x64", 2 );
        inPrint_Log( __LINE__, "write");
        if( iRet < 2 )
        {
            //*piRetPrinterStatus = PRINT_WRITEFAIL;
            inPrint_Log( __LINE__, "inPrint_CheckReadlyStatus, wirte <ESC>d fail, iRet=%d", iRet );
            return 0;
        }
    }
    else
    {
        write_check_print(inPrint_iPrinterHandle, "\x1B\x64", 2 );
    }
    memset( cBuffer, 0, sizeof( cBuffer ) );
    inPrint_Log( __LINE__, "write");
    if( PRN_VX820DUET != 1 )
    {
        while( (iRet = read(inPrint_iPrinterHandle, cBuffer, 1)) == 0 )
            SVC_WAIT( 10 );
    }
    else
    {
        inPrint_Log( __LINE__, "write");
        while( (iRet = read(inPrint_iPrinterHandle, cBuffer, 1)) == 0 )
        {
            inPrint_Log( __LINE__, "inPrint CheckReadlyState" );
            SVC_WAIT( 10 );
            if(delay > 1000/10)
            {
                iRet = -1;
                break;
            }
            else
                delay++;
        }
    }
    if( iRet < 0 )
    {
        inPrint_Log( __LINE__, "write");
        if( PRN_VX820DUET == 1 )
            *piRetPrinterStatus = PRINT_READFAIL;
        inPrint_Log( __LINE__, "inPrint_CheckReadlyStatus, read status fail, iRet=%d", iRet );
        return 0;
    }

    /*cBuffer[0]=
    int prnId=80;
    int ctsReq=0;
    int paperLow=0x00;
    int paperOut=0x02;
    int mechFail=0x40;
    int ramErr=0;
    int firmwareCorrupt=0x04;
    */

    inPrint_Log( __LINE__, "in printing, printer status=[%X]", cBuffer[0] );

    if( cBuffer[ 0 ] & 0x40 )
    {
        //*piRetPrinterStatus = PRINT_MERCHFAIL;
        inPrint_CheckMechFailure( 1 );
        //return 0;
    }

    if( cBuffer[ 0 ] & 0x02 )
    {
        inPrint_CheckMechFailure( iWaitFlag );

        inPrint_Log( __LINE__, "paper out" );

        *piRetPrinterStatus = PRINT_NOPAPER;

        if( inPrint_GetUIScheme() != 1 )
        {
            MmiUtil_ClearLines(LINE3, LINE4);
            MmiUtil_DisplayCenter("��ӡ��ȱֽ", LINE3, FALSE);
            MmiUtil_DisplayCenter("��װֽ�󰴼�����", LINE4, FALSE);
            get_char();
            MmiUtil_UserClr(LINE3);
            MmiUtil_DisplayCenter("��ӡ��", LINE3, FALSE);
        }
        //return 0;
    }

    if( cBuffer[ 0 ] & 0x01 )
        return 1;

    return 0;
}

static int inPrint_CheckNoPaper( int iPrinterStatus )
{
    if( (inPrint_GetUIScheme() == 1) && (iPrinterStatus == PRINT_NOPAPER) )
        return PRINT_NOPAPER;

    return PRINT_OK;
}

static int inPrint_GetStatus( void )
{
    int iRet;
    char cBuffer[ 3 ];

    if( inPrint_iPrinterHandle < 0 )
    {
        inPrint_Log( __LINE__, "inPrint_CheckReadlyStatus, no handle" );
        return PRINT_NOHANDLE;
    }

    //<ESC>d
    iRet = write(inPrint_iPrinterHandle, "\x1B\x64", 2 );
    if( iRet < 2 )
    {
        //*piRetPrinterStatus = PRINT_WRITEFAIL;
        inPrint_Log( __LINE__, "inPrint_CheckReadlyStatus, wirte <ESC>d fail, iRet=%d", iRet );
        return PRINT_WRITEFAIL;
    }

    memset( cBuffer, 0, sizeof( cBuffer ) );
    while( (iRet = read(inPrint_iPrinterHandle, cBuffer, 1)) == 0 )
        SVC_WAIT( 10 );

    if( iRet < 0 )
    {
        //*piRetPrinterStatus = PRINT_READFAIL;
        inPrint_Log( __LINE__, "inPrint_CheckReadlyStatus, read status fail, iRet=%d", iRet );
        return PRINT_READFAIL;
    }

    /*cBuffer[0]=
    int prnId=80;
    int ctsReq=0;
    int paperLow=0x00;
    int paperOut=0x02;
    int mechFail=0x40;
    int ramErr=0;
    int firmwareCorrupt=0x04;
    */

    inPrint_Log( __LINE__, "in printing, printer status=[%X]", cBuffer[0] );

    if( cBuffer[ 0 ] & 0x40 )
    {
        //*piRetPrinterStatus = PRINT_MERCHFAIL;
        inPrint_CheckMechFailure( 1 );
        return PRINT_MERCHFAIL;
    }

    if( cBuffer[ 0 ] & 0x02 )
    {
        inPrint_Log( __LINE__, "paper out" );
        return PRINT_NOPAPER;
    }

    if( cBuffer[ 0 ] & 0x01 )
    {
        inPrint_Log( __LINE__, "printer busy" );
    }

    return PRINT_OK;
}

static int inPrint_CheckStatus( int iStatus )
{
    int i;
    int iPrinterStatus = PRINT_OK;

    i = 0;
    while( inPrint_CheckReadlyStatus( iStatus, &iPrinterStatus ) )
    {
        if( inPrint_CheckNoPaper( iPrinterStatus ) == PRINT_NOPAPER )
            return PRINT_NOPAPER;

        if( iStatus != 1 )
            break;

        SVC_WAIT( 100 );

        if( i++ > 50 )
            break;
    }
    inPrint_Log( __LINE__, "write");
    return iPrinterStatus;
}


//---------------------------------------------------

// ����������ӡ���ܵ��´�ӡ����, �����ж�����ȡ�ֿ�����ߴ�ӡʧ��,��ͣ50ms��Ȼ���ٳ���һ��
// @laikey_20130109 -->

static int inPrint_p3700_print( short h_comm_port, unsigned char *pPrintString )
{
#if 0
    int iRet;

    iRet = p3700_print( h_comm_port, pPrintString );
    if ( iRet < 1 )
    {
        SVC_WAIT( 50 );

        iRet = p3700_print( h_comm_port, pPrintString );
    }

    return iRet;
#else

    inPrint_WriteStr( h_comm_port, pPrintString );
    return 0;
#endif
}


static short inPrint_p3700_select_font( short h_comm_port, short font_size, short font_table)
{
    int iRet;

    if( PRN_VX820DUET == 1 )
    {

        iRet = inPrint_select_font( h_comm_port, font_size, font_table);
        if ( iRet < 1 )
        {
            SVC_WAIT( 50 );

            iRet = inPrint_select_font( h_comm_port, font_size, font_table);
        }
    }
    else
    {
        iRet = p3700_select_font( h_comm_port, font_size, font_table);
        if ( iRet < 1 )
        {
            SVC_WAIT( 50 );

            iRet = p3700_select_font( h_comm_port, font_size, font_table);
        }
    }
    return iRet;
}

static int inPrint_PRN_id( short h_comm_port, short id_time_out, short prnType )
{
    char cmd[20];
    int retVal=0;
    unsigned long timeout = 0L;

    //initEsqSeq(prnType);

    memset(cmd, 0, sizeof(cmd));
    //clear receiving buffer

    while ( read( h_comm_port, cmd, 1 ))
        ;

    //ask for the printer's id by sending <ESC>i
    //retVal = getEsqSeq(cmd, ID_REQ);
    cmd[0]=0x1b;
    cmd[1]=0x69;

    vdWaitForPrinter(h_comm_port);
    if(retVal > 0)
    {
        retVal = write( h_comm_port, cmd, strlen(cmd));
        if(retVal > 0)
        {
            //init buffer
            memset(cmd, 0, 20);
            // now get the printer's response
            timeout = read_ticks() + (1000 * id_time_out);
            while (read_ticks() < timeout)
            {
                retVal = read( h_comm_port, cmd, 4 );
                if (retVal > 0 )
                {
                    retVal = OK;
                    break;
                }
                else			// set return flag to indicate success
                    retVal = NO_RSP;
            }

        }
    }

    return retVal;
}


static int inPrint_ACT_CheckOSVersion(void)
{

    char buffer[10]= {0};
    char version[10]= {0};

    short majorVersion = 0;

    SVC_INFO_EPROM(buffer);
    // buffer will be in fromat "\tQ30016AO".parse the buffer to get 15/16/12 in Q80016...
    strncpy(version,buffer+5,2);
    majorVersion = atoi(version);

    if (majorVersion == 16)
    {
        memset(version, 0, sizeof(version));
        strncpy(version,buffer+8,1);
        majorVersion = atoi(version);
        if ((majorVersion >=1) && (majorVersion <=4))
            return TRUE;
        else
            return FALSE;
    }
    else
        return FALSE;
}

static int inPrint_init( short h_comm_port, short time_out, short prnType )
{
    char inbuf[20];
    short len;// retVal;
    memset(inbuf, 0, sizeof(inbuf));

    //initEsqSeq(prnType);
    //printerEsqSeq = (PRN_ESC_SEQ*)PRN3700EsqSeq;

    // initialize the printer & put it into power up state
    //len = getEsqSeq(inbuf, INIT);
    inbuf[0] = 0x1b;
    inbuf[1] = 0x63;
    len = 2;

    write_check_print( h_comm_port, (char *)inbuf, len);

    //There are printer issues observed on 1.x 3750s with Opsys 16A1 or higher, when using the
    //ACT formater functions to print.  A work-around at the library layer is required for
    //solving this printer issue in the Operating system 16A1 to 16A5.
    // Reference Clarify Case ID is  #040511-1084. SRS ID : 3.1
    // The solution is suggested & confirmed by Perry_B1 : Ravi_B3 17/07/2004

    if ( (prnType == P3700) && (inPrint_ACT_CheckOSVersion()) )
        SVC_WAIT( 200 );
    // Perry  : Ends here.

    return (inPrint_PRN_id( h_comm_port, time_out, prnType));
}

static int inPrint_prn_close( short h_comm_port )
{
    char ioctl_status[4];
    unsigned long timeout = 0L;

    memset(ioctl_status, 0, sizeof(ioctl_status));
    timeout = read_ticks() + 2000; // 2000 milisecs?!

//	while(retVal = get_port_status(h_comm_port,(char*)ioctl_status))
    while( get_port_status(h_comm_port,(char*)ioctl_status) > 0 )
    {
        if(timeout < read_ticks())
            return(-1);
    }

    close(h_comm_port);

    return 0;
}

short inPrint_p3700_close(short handle)
{

    if(inPrint_ACT_CheckOSVersion())
        SVC_WAIT(200);

    return(inPrint_prn_close(handle));
}

short inPrint_select_font( short h_comm_port, short font_size, short font_table )
{
    char buf[11];
    short retVal = 0;
    //short fonttab;

    //gFontsize = font_size;
    memset(buf, 0x00, sizeof(buf));
    //retVal = getEsqSeq(buf, SEL_FONT);
    //if(retVal <= 0)
    //    return retVal;
    buf[0] = 0x1b;
    buf[1] = 0x6c;
    //buf[3] = '0';
    retVal = 2;

    buf[retVal] = (char) font_size + '0';
    int2str (buf+retVal+1, font_table);

    retVal = strlen(buf);
    buf[retVal] = ';';

    //validate_fonttable = font_table;

    retVal = write_check_print( h_comm_port, (char *)buf, strlen( buf));

    return retVal;
}


short inPrint_dnld_graphic_file (short h_comm_port, short h_graphic_file)
{
    short ret_val = DNLD_FAIL;
    char  rd_buf[2048];   // 64 is the size of internal buffer.
    short bytesRead;
    //char stTempBuffer[2] = {0};  // Added for reading the config.sys entry


    if (read( h_graphic_file, rd_buf, 1 ) < 1)
    {
        ret_val = HEADER_ERROR;
        return ret_val;
    }


    if( rd_buf[0] == 0x65 )
    {
        bytesRead=1;
        while(bytesRead)
        {


            if ((bytesRead = read( h_graphic_file, rd_buf, 1024)) < 0)
            {
                ret_val = FILE_ERROR;
                break;
            }

            ret_val = write_check_print( h_comm_port, (char *)rd_buf, (short)bytesRead);

        }

    }
    close( h_graphic_file );
    return ret_val;
}

static short inPrint_p3700_dnld_graphic_file(short h_comm_port, short h_graphic_file )
{
    return inPrint_dnld_graphic_file( h_comm_port, h_graphic_file );
}

static int inPrint_OpenDevice( void )
{
    int iOwnner = 0;
    int iHandle = 0;
    int tryTime = 0;

    do
    {
        iHandle = get_owner( DEV_COM4, &iOwnner);

        if ( iHandle < 0 )
            return iHandle;

        if (iOwnner != 0 && iOwnner != get_task_id())
        {
            return FALSE;
        }

        if (iOwnner == get_task_id()) //the device is used by myself
        {
            return TRUE;
        }

        iHandle = open( DEV_COM4, 0);
    }
    while (iOwnner != get_task_id() && tryTime++ < 3);

    return TRUE;
}


static int inPrint_CloseDev( void )
{
    int iOwnner = 0;
    int iHandle = 0;
    int tryTime = 0;

    do
    {
        iHandle = get_owner( DEV_COM4, &iOwnner);
        if ( iHandle < 0 )
        {
            return iHandle;
        }

        if ( iOwnner != 0 && iOwnner != get_task_id())
        {
            return FALSE ;
        }

        if ( iOwnner == 0 )
            break;

        close( iHandle );
    }
    while ( iOwnner != 0 && tryTime++ < 3);

    return TRUE;
}


static int inPrint_CheckPrintAutoOpenStatus( void )
{
    int iRet = 1;
    int iCurrGID = get_group( );
    char cBuffer[ 6 ];

    set_group( 15 );

    memset( cBuffer, 0, sizeof( cBuffer ) );
    get_env( "*AOPRTDEV", cBuffer, sizeof( cBuffer) );

    set_group( iCurrGID );

    if ( strlen( cBuffer ) > 0 )
        iRet = atoi( cBuffer );

    return iRet;
}

// <-- @laikey_20130109


// Added by @laikey_20130321 for Vx805 printer -->

static void inPrint_WaitPrinter( int inHandle )
{
    char cTmpBuf[ 5 ];
    int  iRet;
    unsigned long lTrytimer;

    lTrytimer = set_itimeout( -1, 10, TM_SECONDS );

    do
    {
        memset( cTmpBuf, 0x00, sizeof( cTmpBuf ) );

        iRet = get_port_status( inHandle, cTmpBuf );

        if ((iRet == 0) && (cTmpBuf[0] == 0) && (cTmpBuf[1] == 0) &&(cTmpBuf[2] == 0x1E))
            break;

        SVC_WAIT( 20 );

    }
    while ( (iRet >= 0) && (CHK_TIMEOUT( -1, lTrytimer)) );
}



static int inPrint_SafeWrite(int iHandle, char *pWriteData, int iDataLength )
{
    int bytesOut;
    int iLen;
    unsigned long lTrytimer;
    //char cStsBuf[ 5 ];

    lTrytimer = set_itimeout( -1, 10, TM_SECONDS );

#if 1
    iLen = 0;
    while( CHK_TIMEOUT( -1, lTrytimer ) )
    {
        errno = 0;
        bytesOut = write( iHandle, pWriteData + iLen, iDataLength - iLen );

        // while( get_port_status( iHandle, cStsBuf ) != 0);   // Flush all data in COM4
        // SVC_WAIT( 2 );

        if( bytesOut >= iDataLength || iLen >= iDataLength )
            break;

        inPrint_Log( __LINE__, "safe write, iHandle=%d, length=%d,%d,%d, errno=%d,str=%s", iHandle, iDataLength, bytesOut, iLen, errno, pWriteData );


        if( bytesOut <= 0 )
        {
            if( errno == ENOSPC || errno == ENXIO)
            {
                errno = 0;
                SVC_WAIT( 20 );
            }
        }
        else
        {
            iLen += bytesOut;
            SVC_WAIT( 10 );
        }
    }

    return iLen;
#else
    do
    {
        errno = 0;

        bytesOut = write( iHandle, pWriteData, iDataLength );

        //while( get_port_status( iHandle, cStsBuf ) != 0);   // Flush all data in COM4
        //SVC_WAIT( 2 );

        if ( bytesOut != iDataLength )
        {
            if( errno == ENOSPC || errno == ENXIO)
            {
                errno = 0;
                SVC_WAIT( 20 );
            }
            else if( bytesOut > 0 )
                break;
        }
        else
            break;
    }
    while ( (bytesOut != iDataLength) && (CHK_TIMEOUT( -1, lTrytimer)) );

    return bytesOut;
#endif


}

/* --------------------------------------------------------------------------
* FUNCTION NAME: inPrint_WriteStr.
* DESCRIPTION:   ��ӡ������Ӣ���ִ��ĺ���
* PARAMETERS:
*     str (in) -- Ҫ��ӡ���ַ���
*     attrib (in) -- ��ӡ����
* RETURN:
*   PRINT_OK/PRINT_NOHANDLE/PRINT_NOPAPER/PRINT_FAIL
* NOTES:
* ------------------------------------------------------------------------ */
static void inPrint_WriteStr( int hdl, unsigned char *pcString )
{
    if( PRN_VX820DUET != 1 )
        inPrint_SafeWrite( hdl, (char *)pcString, strlen( (char *)pcString ) );
    else
        write_check_print( hdl, (char *)pcString, strlen( (char *)pcString ) );

}


static int inPrint_Write_Vx805(int iHandle, char *pWriteData, int iDataLength )
{
    int bytesOut;
    unsigned long lTrytimer;
    if( PRN_VX820DUET != 1 )
    {
        lTrytimer = set_itimeout( -1, 10, TM_SECONDS );

        do
        {
            errno = 0;

            bytesOut = write( iHandle, pWriteData, iDataLength );

            if ( bytesOut != iDataLength )
            {
                if ( errno == ENOSPC )
                {
                    errno = 0;
                    SVC_WAIT( 20 );
                }
                else
                    break;
            }
            else
                break;
        }
        while ( (bytesOut != iDataLength) && (CHK_TIMEOUT( -1, lTrytimer)) );
    }
    else
        bytesOut = write_check_print( iHandle, pWriteData, iDataLength );
    return bytesOut;
}


static void inPrint_Feed_Vx805( int flag, int length )
{
    char cBuffer[ 20 ];
    int  iRet;

    if ( (flag != FORWARD_PAPER) && (flag != REVERSE_PAPER) )
        return;

    inPrint_WaitPrinter( inPrint_iPrinterHandle );
    cBuffer[ 0 ] = 0x18;
    inPrint_Write_Vx805( inPrint_iPrinterHandle, cBuffer, 1 );

    memset(cBuffer, 0, sizeof(cBuffer));
    iRet = sprintf(cBuffer, "\x1B""b%d,%d;", length, flag);

    inPrint_Write_Vx805( inPrint_iPrinterHandle, cBuffer, iRet);
    return;
}



static int inPrint_Print_Str_12_Vx805(char *pPrintString, unsigned char attrib)
{
    int i, j;
    int iRet;
    int iLength;
    short fp, fp1;
    char cTmpBuf[ 4 ];
    char cPrintMode[ 4 ]= {0};
    unsigned char cBuffer[ 32 ], cBuffer1Line[ 32 * 12 ];	// 12��, ÿ��15���֣�ÿ���ֵ�ÿ��
    BOOL bIsGbkFont12;

    iLength = strlen(pPrintString);
    if (iLength == 0)
        return PRINT_OK;

    bIsGbkFont12 = isGbkFont12();

    if (bIsGbkFont12)
    {
        if ((fp = open(GBKFONT_12,O_RDONLY)) < 0)
            return PRINT_NOHANDLE;
    }
    else
    {
        if ((fp = open(CHNFONT_12,O_RDONLY)) < 0)
            return PRINT_NOHANDLE;
    }

    if ((fp1 = open(ENGFONT_5x8,O_RDONLY)) < 0)
        return PRINT_NOHANDLE;

    //**************************************************************************************
    // Start the graphics mode of printing the data
    //ESC g is the command for going to the graphicsa mode
    //**************************************************************************************
    cPrintMode[0]=0x1b;
    cPrintMode[1]=0x67;

    inPrint_WaitPrinter(inPrint_iPrinterHandle);

    iRet = inPrint_Write_Vx805(inPrint_iPrinterHandle, cPrintMode,2);
    if (iRet != 2)
    {
        close(fp);
        close(fp1);
        return WRITE_FAIL;
    }

    //**************************************************************************************
    //Now thw bitmap will have the data in the reverse hence the last data of the bitmap
    //will be the first data hnece get the data in reverse
    //the value of the buffer is memset to 0x0c 1100 0000 which will not print data
    //Container should have 1 1			0 0 0 0 0 0
    //						| |			| | | | | |
    //					Non printing	Printing data
    //**************************************************************************************

    //iLength = strlen(pPrintString);
    if (iLength > 30)	// ֻ��ӡһ��
        iLength = 30;

    memset( cBuffer1Line, 0, sizeof( cBuffer1Line ) );

    for (i = 0; i < 12; i ++)
    {
        memset(cBuffer, 0xC0, sizeof( cBuffer ) );

        for (j = 0; j < iLength; j ++ )
        {
            if (bIsGbkFont12 && (unsigned char)pPrintString[j] >= 0x81 && (unsigned char)pPrintString[j+1] >= 0x40)
            {
                lseek(fp, inPrint_GetGBKOffset(pPrintString[j], pPrintString[j+1])*24 + 128*12 + 16 + (i * 2), SEEK_SET);

                read(fp, cTmpBuf, 2);

                /* 12x12����ÿ����2���ֽ���ɣ�ʵ��ֻռ����12��BIT */
                cBuffer[j] |= cTmpBuf[0] >> 2;
                cBuffer[j + 1] |= (cTmpBuf[0] << 6) >> 2;
                cBuffer[j + 1] |= cTmpBuf[1] >> 4;
                j ++;
            }
            else if ((unsigned char)pPrintString[j] >= 0xA1 && (unsigned char)pPrintString[j+1] >= 0xA0)
            {
                lseek(fp, inPrint_GetGB2312Offset(pPrintString[j], pPrintString[j+1])*24 + (i * 2), SEEK_SET);

                read(fp, cTmpBuf, 2);

                /* 12x12����ÿ����2���ֽ���ɣ�ʵ��ֻռ����12��BIT */
                cBuffer[j] |= cTmpBuf[0] >> 2;
                cBuffer[j + 1] |= (cTmpBuf[0] << 6) >> 2;
                cBuffer[j + 1] |= cTmpBuf[1] >> 4;
                j ++;
            }
            else if (i > 3) //ʹ��5x8��Ӣ�ģ��¶���
            {
                lseek(fp1, (8 + pPrintString[j] * 9 + 1 + i - 4), SEEK_SET);
                read(fp1, cTmpBuf, 1);

                // 5x8����ÿ��1���ֽڣ�ʵ��ռ�ú�5��BIT
                cBuffer[j] |= cTmpBuf[0];
            }
        }
        cBuffer[j] = 0x21;	// ����

        if (j == 30)
            memcpy(cBuffer1Line + i * j, cBuffer, j);
        else
            memcpy(cBuffer1Line + i * (j + 1), cBuffer, j + 1);
    }

    //Avoid calling strlen two times
    iLength = strlen((char *)cBuffer1Line);
    cBuffer1Line[iLength++] = 0x21;	// �о�һ������

    inPrint_Write_Vx805( inPrint_iPrinterHandle,(char *)cBuffer1Line, iLength );

    //***********************************************************************************************
    // Exit from the graphics mode passing the 0x18 CAN command ie the 0001 0100 the fifth bit should be set to 1
    //***********************************************************************************************
    cPrintMode[0]=0x18;

    inPrint_WaitPrinter(inPrint_iPrinterHandle);

    inPrint_Write_Vx805(inPrint_iPrinterHandle, cPrintMode,1);

    close( fp );
    close( fp1 );
    return PRINT_OK;

}

// <-- @laikey_20130321


/*
static void inPrint_Compress_16x16_v_only( unsigned char* buf_zip, unsigned char* buf_pft)
{
    int i, k;
    char bmask[] = {0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80};
    char tmpbuf[ 32 ];

    memset( tmpbuf, 0, sizeof( tmpbuf ) );

    // Shrink vertical adjacent dots
    for(k = 0; k < 32; k += 2)
    {
        tmpbuf[k] = 0;
        tmpbuf[k+1] = 0;

        for(i = 7; i >= 0; i--)
        {
            tmpbuf[k+1] += (buf_pft[k] | buf_pft[k+1]) & bmask[i];
        }
    }

    memcpy( buf_zip, tmpbuf, 32 );
}*/

//�Ե����������������ѹ��
static void inPrint_Compress_16x16_h_only( unsigned char* buf_zip, unsigned char* buf_pft)
{
    int i, k;
    unsigned char tmp, bmask[] = {0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80};
    unsigned char tmpbuf[ 32 ];

    memset( tmpbuf, 0, sizeof( tmpbuf ) );

    // Shrink horizontal adjacent dots
    for(k = 0; k < 8; k++)
    {
        // Process from top left
        for(tmp = 0, i = 7; i >= 0; i--)
        {
            if(buf_pft[k] & bmask[i])
                tmp += bmask[i--];
        }

        tmpbuf[k] = tmp;

        // Process top right
        for(tmp = 0, i = (tmpbuf[k] & 0x01) ? 6 : 7; i >= 0; i--)
            if(buf_pft[k+8] & bmask[i])
                tmp += bmask[i--];

        tmpbuf[k+8] = tmp;

        // Process  bottom left
        for(tmp = 0, i = 7; i >= 0; i--)
            if(buf_pft[k+16] & bmask[i])
                tmp += bmask[i--];

        tmpbuf[k+16] = tmp;

        // Process bottom right
        for(tmp = 0, i = (tmpbuf[k+16] & 0x01) ? 6 : 7; i >= 0; i--)
            if(buf_pft[k+24] & bmask[i])
                tmp += bmask[i--];

        tmpbuf[k+24] = tmp;
    }

    memcpy( buf_zip, tmpbuf, 32 );
}


//�Ե��������������������ѹ��
static void inPrint_Compress_16x16_hv( unsigned char* buf_zip, unsigned char* buf_pft)
{
    int i, k;
    unsigned char bmask[] = {0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80};
    unsigned char tmpbuf[ 32 ];

    memset( tmpbuf, 0, sizeof( tmpbuf ) );

    // Shrink vertical adjacent dots
    for(k = 0; k < 32; k += 2)
    {
        tmpbuf[k] = 0;
        tmpbuf[k+1] = 0;

        for(i = 7; i >= 0; i--)
        {
            tmpbuf[k+1] += (buf_pft[k] | buf_pft[k+1]) & bmask[i];
        }
    }

    // Shrink horizontal adjacent dots
    inPrint_Compress_16x16_h_only(buf_zip, tmpbuf);
}


// ����Ӣ�ĵ����ֿ�(������Ƶ�ѹ���ֿ�), ������ʽ��ӡ���ӿ��ӡ�ٶ�
static int inPrint_Download_EnglishFont_8x14(void)
{
    int i, j, retry, code, cnt;
    int fp;
    unsigned char buf[2048], scmd[128];
    long file_size = 0;

    // Added by laikey_20151209 -->
    if( inPrint_GetStatus() != PRINT_OK )
    {
        inPrint_Log( __LINE__, "english font download but printer is not ready" );
        return -5;
    }

    if( inPrint_iDownloadEnglishFontFlag == 1 )
    {
        inPrint_Log( __LINE__, "english font has already been download" );
        return 0;
    }
    // <--

    if((fp = open( ENGFONT_8x14, O_RDONLY)) <= 0)
    {
        MmiUtil_Warning( "Ӣ��8X14�ļ�δ�ҵ�" );
        return -1;
    }

    file_size = lseek(fp, 0L, SEEK_END);

    if(file_size > sizeof(buf))
        file_size = sizeof(buf);

    lseek(fp, 0L, SEEK_SET);
    read(fp, (char *)buf, file_size);

    // Check the font file is with correct format
    if(strcmp((char *)buf, "I\x1b\x6c") != 0)
    {
        close( fp ); // Added by laikey_20151209
        return -2;
    }

    //<ESC>l31; Select 8x14 font table 1
    inPrint_WriteStr(inPrint_iPrinterHandle, (unsigned char *)"\x1bl41;");

    inPrint_Log( __LINE__, "english download fontsize=4,table id=1" );

    memset(scmd, 0, sizeof(scmd));
    scmd[0] = 0x1b;
    scmd[1] = 'm';
    scmd[17] = ';';
    i = 8;
    code = 0x21;
    cnt = 0;

    while(i < file_size  &&  code < 0x7f)
    {
        scmd[2] = buf[i++];

        for(j = 3; j < 16; j += 2)
        {
            if(buf[i] == 0x7f)
                buf[i] = 0;

            scmd[j] = buf[i++];
        }

        retry = 0;
        SVC_WAIT(5);
        if( PRN_VX820DUET != 1 )
        {

            while(write(inPrint_iPrinterHandle, (char *)scmd, 18) != 18 && retry < 6)
            {
                retry++;
            }
        }
        else
        {
            write_check_print(inPrint_iPrinterHandle, (char *)scmd, 18);
        }
        inPrint_Log( __LINE__, "english font download char=[%c=%d]",code,code );

        i++;
        code = buf[i];
        cnt++;
    }

    close( fp ); // Added by laikey_20151209

    inPrint_Log( __LINE__, "download english font 8x14 OK!" );
    SVC_WAIT( 200 );

    // Added by laikey_20151209 -->
    inPrint_iDownloadEnglishFontFlag = 1;
    //<--

    return cnt;
}

//��ӡ����
static void inPrint_Print_Hz( char *str, unsigned char attrib )
{
    int i, j;
    int scLen, hzLen, ccode, index;
    int iDflag;
    char attribuf[ 16 ];
    char cmdTable[ 16 ];
    char scmd[ 2048 ];
    char cTmpBuf[ 16 ];
    int  idTable = 0, newTab;

    memset( attribuf, 0, sizeof( attribuf ) );
    if( (attrib & DH) || (attrib & DW) || (attrib & INV) )
    {
        i = 0;

        if( attrib & INV )
            attribuf[ i++ ] = 0x12;

        if( attrib & DH )
        {
            memcpy( attribuf + i, "\x1b\x66\x30\x31\x3b", 5 );
            i += 5;
        }

        if( attrib & DW )
            attribuf[ i ++ ] = 0x1e;

        //inPrint_WriteStr( inPrint_iPrinterHandle, (unsigned char *)attribuf );
    }

    memset( scmd, 0, sizeof( scmd ) );
    hzLen = strlen(str);
    strcpy(scmd, "\x1bH");
    scLen = 2;

    for( i = 0; i < hzLen; scLen += 2)
    {
        memset( cTmpBuf, 0, sizeof( cTmpBuf ) );
        ccode = inPrint_SearchHZ( &str[ i ], &index, cTmpBuf, &iDflag );

        j = i;
        if( iDflag == 0 )
            i ++;
        else
            i += 2;

        if( ccode < 0 )
        {
            inPrint_Log( __LINE__, "search_hz:%2.2s not found in cache stings", &str[ j ] );
            continue;
        }
        else
            inPrint_Log( __LINE__, "search_hz:%2.2s found in cache index:%d", &str[ j ], ccode );

        if( inPrint_bNewSprocketMode == 0 )
        {
            inPrint_Log( __LINE__, ".........................." );

            if( inPrint_GetFontSize() == PRINT_FONT24 )
                newTab = (ccode >> 7) * 9 + 24;
            else
                newTab = (ccode >> 7) * 4 + 3;
        }
        else
        {
            if( (attrib & DH) || (attrib & DW ) )
                newTab = (ccode >> 7) * 4 + 3;	// h only
            else
                newTab = (ccode >> 7) * 4 + 43;	// hv both
        }

        if( newTab != idTable )
        {
            // before switch new table, write out previous string
            if( scLen > 2)
            {
                strcat( scmd, ";" );
                inPrint_WriteStr( inPrint_iPrinterHandle, (unsigned char *)scmd );
                scmd[2] = '\0';
                scLen = 2;
            }

            idTable = newTab;
            if( inPrint_GetFontSize( ) == PRINT_FONT24 )
                sprintf(cmdTable, "\x1bl%d%d;", 5, idTable);
            else
                sprintf(cmdTable, "\x1bl%d%d;", 1, idTable);

            inPrint_WriteStr(inPrint_iPrinterHandle, (unsigned char *)cmdTable);

            inPrint_WriteStr( inPrint_iPrinterHandle, (unsigned char *)attribuf );
        }

        sprintf(scmd + scLen, "%02X", (ccode & 0x7f));
    }

    strcat (scmd, ";");
    inPrint_WriteStr( inPrint_iPrinterHandle, (unsigned char *)scmd );
    return;
}

// ��ӡӢ��
static void inPrint_Print_English( unsigned char attrib, unsigned char *txtenglish )
{
    int i = 0;
    int ret = 0;
    unsigned char attribuf[ 16 ];

    if( inPrint_bNewSprocketMode == 0 )
    {
        if( inPrint_GetFontSize() == PRINT_FONT24
                && inPrint_is_12_24_font_ok  )  // ����ڴ˴��жϣ���û������12*24����ʱ�����ӡС����
        {
            // 9:��Ӧ12*24�ַ�, �ڵ�59��table��
            // ע�⣬��ҪOS�汾240������
            // inPrint_Log(0, "set size[9] @ table[59]" );
            if( PRN_VX820DUET == 1 )
            {
                inPrint_Log( __LINE__, "p3700_select_font set table is ret = %d", ret );
                inPrint_select_font( inPrint_iPrinterHandle, 0x09, TBID_FOR_12_24 );
            }
            else
            {
                ret = p3700_select_font( inPrint_iPrinterHandle, 0x09, TBID_FOR_12_24 );
                if (ret <= 0)
                {
                    SVC_WAIT(50);
                    inPrint_Log( __LINE__, "p3700_select_font set table is ret = %d", ret );
                    ret = p3700_select_font( inPrint_iPrinterHandle, 0x09, TBID_FOR_12_24 );
                }
            }

        }
        else
        {
            // ԭ�д��� p3700_select_font( inPrint_iPrinterHandle, 0x04, 0 );   // 8*14 @ 42��
            if( PRN_VX820DUET == 1 )
            {
                inPrint_Log( __LINE__, "p3700_select_font set table is ret = %d", ret );
                inPrint_select_font( inPrint_iPrinterHandle, 0x03, 0 );   // 8*14  @ 32��

            }
            else
            {
                ret = p3700_select_font( inPrint_iPrinterHandle, 0x03, 0 );   // 8*14  @ 32��
                if (ret <= 0)
                {
                    SVC_WAIT(50);
                    inPrint_Log( __LINE__, "p3700_select_font set table is ret = %d", ret );
                    p3700_select_font( inPrint_iPrinterHandle, 0x03, 0  );

                }


            }
        }

        if( (attrib & DH) || (attrib & DW) || (attrib & INV) )
        {
            i = 0;
            memset( attribuf, 0, sizeof( attribuf ) );

            if( attrib & INV )
                attribuf[ i++ ] = 0x12;

            if( attrib & DH )
            {
                memcpy( attribuf + i, "\x1b\x66\x30\x31\x3b", 5 );
                i += 5;
            }

            if( attrib & DW )
                attribuf[ i ++ ] = 0x1e;

            inPrint_WriteStr( inPrint_iPrinterHandle, attribuf );
        }

        inPrint_WriteStr( inPrint_iPrinterHandle, txtenglish );
        return;
    }

    // for spt new printer mode
    if( (attrib & DH) || (attrib & DW) || (attrib & INV) )
    {
        if( stprinter_parm.trailer.bytes.b[ 0 ] == 1 )	// 360 dot mode
            inPrint_WriteStr(inPrint_iPrinterHandle, (unsigned char *)"\x1bl40;");	// tall alpha/numeric
        else
            inPrint_WriteStr(inPrint_iPrinterHandle, (unsigned char *)"\x1bl20;");	// short alpha/numeric

        i = 0;
        memset( attribuf, 0, sizeof( attribuf ) );

        if( attrib & INV )
            attribuf[ i++ ] = 0x12;	// INVERSE;

        if( attrib & DH )
        {
            memcpy( attribuf + i, "\x1b\x66\x30\x31\x3b", 5 );	// DBL_HEIGHT;
            i += 5;
        }

        if( attrib & DW )
            attribuf[ i ++ ] = 0x1e;	// DBL_WIDTH;

        inPrint_WriteStr( inPrint_iPrinterHandle, attribuf );
    }
    else
    {
        // Added by laikey_20151209 -->
        if( inPrint_iDownloadEnglishFontFlag != 1 )
            inPrint_Download_EnglishFont_8x14();
        //<--

        if( stprinter_parm.trailer.bytes.b[0] == 1 )	// 360 dot mode
            inPrint_WriteStr( inPrint_iPrinterHandle, (unsigned char *)"\x1bl41;");
        else
            inPrint_WriteStr( inPrint_iPrinterHandle, (unsigned char *)"\x1bl20;");
    }

    inPrint_WriteStr( inPrint_iPrinterHandle, txtenglish );

    return;
}


static int inPrint_GetFontSize( void )
{
    inPrint_Log( __LINE__, "inPrint_GetFontSize! inPrint_bNewSprocketMode = %d inPrint_iFontSize = %d",inPrint_bNewSprocketMode,inPrint_iFontSize );
    if( inPrint_bNewSprocketMode == 1)
        return PRINT_FONT16;

    return inPrint_iFontSize;
}

static int inPrint_GetUIScheme( void )
{
    return inPrint_iUIScheme;
}

// ��ӡbmpͼƬ
static int inPrint_Bitmap(int handle, int offset, char *filename)
{
    short bmp_file;
    short retVal;
    unsigned char fileheader[14];
    unsigned char infoheader[48];
    unsigned short BitsPerPixel = 0;
    short mod = 0;
    unsigned int height, width, widthActual = 0;
    int padding = 0;
    int m_size = 0;
    unsigned char  *bitmapData;
    unsigned char  *bitmapConv;
    unsigned char  *LineData;
    int i, j = 0;
    short offsetwidth = 0;
    unsigned short ReqSize;
    char Printmode[4] = {0};
    char ioctl_status[4];
    short heightIndex = 0;
    int bitcount, bitset;
    unsigned char DataBuf[1] = {0};
    unsigned char TransBuf[1] = {0};
    unsigned int counter[8] = {1, 2, 4, 8, 16, 32, 64, 128};
    char *filextn = ".bmp";
    char *position;
    short bits = 0;
    static int count = 0;

    //**********************************************************************************
    //  check whether the file is bmp
    //**********************************************************************************

    position = strstr(filename, filextn);
    if(position == NULL)
        return PRINT_OPENFAIL;

    //**********************************************************************************
    //  offset if it is less than 0 will be treated as 0 and more than 60 will be treated as 60
    //**********************************************************************************

    if(offset <= 0)
        offset = 0;
    else if(offset > 60)
        offset = 60;

    //**********************************************************************************
    //		Open the bmp file passed as the second paramter and read the header
    //**********************************************************************************
    bmp_file = open(filename, O_RDONLY);
    if(bmp_file < 0)
        return PRINT_OPENFAIL;
    else //Read the header of the bmp file
    {
        retVal = read(bmp_file, (char*)fileheader, sizeof(fileheader)); //file header
        if(retVal < 0)
        {
            close(bmp_file);
            return PRINT_READFAIL;
        }

        retVal = read(bmp_file, (char*)infoheader, sizeof(infoheader)); //informaton header
        if(retVal < 0)
        {
            close(bmp_file);
            return PRINT_READFAIL;
        }
    }

    //Read the 2 bytes of the bits per pixel data
    BitsPerPixel = infoheader[15] << 8 | infoheader[14] << 0;
    if(BitsPerPixel != 1)
    {
        close(bmp_file);
        return PRINT_FAIL;
    }

    // width is 4 bytes
    width = infoheader[7] << 24 | infoheader[6] << 16 | infoheader[5] << 8 | infoheader[4] << 0;
    // width is 4 bytes
    height = infoheader[11] << 24 | infoheader[10] << 16 | infoheader[9] << 8 | infoheader[8] << 0;

    if((width || height) <= 0)
    {
        close(bmp_file);
        return PRINT_FAIL;
    }

    if((width % 8) > 0)
    {
        mod = width % 8;
        widthActual = (width / 8) + 1;
    }
    else
    {
        widthActual = (width / 8);
        mod = 7;
    }

    padding = 4 - (widthActual % 4);
    if(padding == 4)
        padding = 0;

    m_size = height * widthActual;
    bitmapData = (unsigned char*)malloc(m_size);
    if(bitmapData == NULL)
    {
        close(bmp_file);
        return PRINT_FAIL;
    }

    memset(bitmapData, 0, m_size);
    ReqSize = ((widthActual * 8) + (offset * 6)) / 6 * height;
    bitmapConv = (unsigned char*)malloc(ReqSize + height);
    if(bitmapConv == NULL)
    {
        close(bmp_file);
        return PRINT_FAIL;
    }

    memset(bitmapConv, 0xC0, ReqSize);
    LineData = (unsigned char*)malloc(widthActual);
    if(LineData == NULL)
    {
        close(bmp_file);
        return PRINT_FAIL;
    }

    for(i = 0; i < height; ++i)
    {
        memset(LineData, 0, widthActual);
        //Reac the complete width required
        retVal = read(bmp_file, (char*)LineData, widthActual);

        //get each byte to the required pixel
        for(j = 0; j < widthActual; ++j)
            bitmapData[(i * widthActual) + j] = ~LineData[j];

        //omit the unrequired data at the the end
        retVal = lseek(bmp_file, padding, SEEK_CUR);
    }

    offsetwidth = (384 - ((offset * 6) + 12));
    if((offsetwidth % 8) > 0)
        width = (offsetwidth / 8) + 1;
    else
        width = (offsetwidth / 8);

    // if the width is less than widthActual then widthActual is taken as the actual value
    if(widthActual <= width)
        width = widthActual;
    else //the pixels of the lasr column has to be calculated to no of bits the last column has to print
        mod = offsetwidth % 8;

    memset(Printmode, 0, 4);
    memset(ioctl_status, 0, 4);
    Printmode[0] = 0x1b;
    Printmode[1] = 0x67;
    if( PRN_VX820DUET != 1 )
    {
        while(get_port_status(handle, ioctl_status) != 0)
        {
            SVC_WAIT(2);
        }
        retVal = write(handle, Printmode, 2);
        if(retVal < 0)
        {
            close(bmp_file);
            return PRINT_WRITEFAIL;
        }
    }
    else
    {
        write_check_print(handle, Printmode, 2);
    }
    count = 0;
    for(i = height - 1; i >= 0; --i)
    {
        bitset = 5; // only 6 bits of data has to be read in the 8 bits and rest will go into another byte
        count = count + offset; // offset the value with buffer of the offset for each row

        for(j = 0; j < width; ++j)
        {
            if( j == (width - 1) )
                bits = 7 - (mod - 1);
            else
                bits = 0;

            DataBuf[0] = bitmapData[(i * widthActual) + j];
            for(bitcount = 7; bitcount >= bits; bitcount--)
            {
                TransBuf[0] = 0;
                TransBuf[0] = DataBuf[0] & counter[bitcount]; // Get the bit data
                TransBuf[0] = TransBuf[0] >> bitcount; // right shift to the 0th position
                TransBuf[0] = TransBuf[0] << bitset; //left shift to the required bit position
                bitmapConv[count] |= TransBuf[0]; // Or the value of the bit
                bitset--; //decrese the bit position

                if(bitset < 0) // if bit are filled then move to the other container
                {
                    bitset = 5;
                    count++;
                }
            }
        }

        ++heightIndex; // go the next row
        count++; //increase the count
        bitmapConv[count++] = 0x21; //new line

        // Once the count of the row is 50 then send the data to the printer
        if(count > 3000)
        {
            if( PRN_VX820DUET != 1 )
            {
                do
                {
                    retVal = write(handle, (char *)bitmapConv, count); // write
                }
                while((retVal < 0) && (errno == ENOSPC || errno == ENXIO));
            }
            else
            {
                write_check_print(handle, (char *)bitmapConv, count);
            }
            count = 0; // reset the counter and the buffer
            memset(bitmapConv, 0xC0, ReqSize);
        }
    } // end of for loop

    // Print the remaining data

    if( PRN_VX820DUET != 1 )
    {
        do
        {
            retVal = write(handle, (char *)bitmapConv, count);
        }
        while((retVal < 0) && (errno == ENOSPC || errno == ENXIO));
    }
    else
    {
        write_check_print(handle, (char *)bitmapConv, count);
    }
    memset(Printmode, 0, 4);
    Printmode[0] = 0x18;
    if( PRN_VX820DUET != 1 )
    {
        while(get_port_status(handle, ioctl_status) != 0)
        {
            SVC_WAIT(0);
        }

        retVal = write(handle, Printmode, 1);
        if(retVal < 0)
        {
            close(bmp_file);
            return PRINT_WRITEFAIL;
        }
    }
    else
    {
        write_check_print(handle, Printmode, 1);
    }
    //**************************************************************************************
    // Free the dynamic data buffer allocated
    //**************************************************************************************

    free(bitmapConv);
    free(bitmapData);
    free(LineData);
    bitmapConv = NULL;
    bitmapData = NULL;
    LineData = NULL;
    SVC_WAIT(100);

    close(bmp_file);
    return PRINT_OK;
}


static int inPrint_ChkVx820DuetVer( void )
{
    int ret;
    int retry;
    int len;
    char * p;
    char scmd[192];

    inPrint_Log(__LINE__, "try get version" );

    scmd[0] = 0x1b;
    scmd[1] = 'C';
    scmd[2] = 'S';
    scmd[3] = ';';
    scmd[4] = 0;
    inPrint_WriteStr(inPrint_iPrinterHandle, (unsigned char *)scmd);

    SVC_WAIT( 5 );

    retry = 0;
    len = 0;
    while( retry < 100 )
    {
        ret = read(inPrint_iPrinterHandle, (char *)scmd+len, 128);

        if( ret > 0 )
        {
            len+=ret;
        }
        else if( ret == 0 && len > 0 )
        {
            break;
        }
        else if( ret < 0 )
        {
            // break;
        }
        retry++;
        SVC_WAIT(10);
    }

    scmd[len] = 0;
    inPrint_Log(__LINE__, "get version[%s]", scmd );

    if( len > 0 )
    {
        /*
        get version[ID  ACT  CAL
        01  xxxx xxxx

        SW Version: 4.0,282-04010804
        SW Build Date : Mar  4 2014
        SW Build Time : 15:47:53

        **/
        p = strstr( scmd, "Version:" );
        if( p )
        {
            p += 9;
            ret = strcmp( p, "4.0,282-04010804" );
        }
    }
    else
    {
        ret = -1;
    }
    return ret;
}

